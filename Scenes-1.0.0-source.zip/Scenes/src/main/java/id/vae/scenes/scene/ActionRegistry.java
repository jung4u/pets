package id.vae.scenes.scene;

import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;

/** Registry of action handlers, filled by the engines at startup. */
public final class ActionRegistry {

    private final Map<String, ActionHandler> handlers = new TreeMap<>();

    public synchronized void register(ActionHandler handler) {
        String type = handler.type().toUpperCase(Locale.ROOT);
        if (handlers.containsKey(type)) {
            throw new IllegalStateException("Action type already registered: " + type);
        }
        handlers.put(type, handler);
    }

    public synchronized Optional<ActionHandler> get(String type) {
        return Optional.ofNullable(handlers.get(type));
    }

    public synchronized Set<String> types() {
        return Collections.unmodifiableSet(new java.util.TreeSet<>(handlers.keySet()));
    }
}
