package id.vae.scenes.camera;

import id.vae.scenes.util.Easing;

import java.util.ArrayList;
import java.util.List;

/** Builders for the common camera movements. */
public final class CameraPaths {

    private CameraPaths() {
    }

    /** Static camera: holds one pose. */
    public static CameraPath hold(CameraPose pose, long millis) {
        return new CameraPath(List.of(new Waypoint("", pose.position(), pose.yaw(), pose.pitch(), 0,
                Easing.LINEAR, null, millis)), false);
    }

    /** Point-to-point and dolly movement between two poses. */
    public static CameraPath pointToPoint(CameraPose from, CameraPose to, long millis, Easing easing) {
        return new CameraPath(List.of(Waypoint.at(from),
                new Waypoint("", to.position(), to.yaw(), to.pitch(), millis, easing, null, 0)), false);
    }

    /** Pan: turns in place to a new yaw and pitch along the shortest turn. */
    public static CameraPath rotate(CameraPose from, float yaw, float pitch, long millis, Easing easing) {
        return new CameraPath(List.of(Waypoint.at(from),
                new Waypoint("", from.position(), yaw, pitch, millis, easing, null, 0)), false);
    }

    /** Turns in place until the camera faces the target (camera focus). */
    public static CameraPath focus(CameraPose from, Vec3 target, long millis, Easing easing) {
        return new CameraPath(List.of(Waypoint.at(from),
                new Waypoint("", from.position(), 0, 0, millis, easing, target, 0)), false);
    }

    /**
     * Orbit around a center at a fixed radius and height offset, always facing the center. The easing
     * shapes the angular speed over time (EASE_IN starts slow). Angles are in degrees; 0 degrees is +X.
     */
    public static CameraPath orbit(Vec3 center, double radius, double heightOffset, double startDegrees,
                                   double endDegrees, long totalMillis, Easing easing, int segments) {
        int n = Math.max(4, segments);
        List<Waypoint> points = new ArrayList<>();
        long previousTime = 0;
        for (int i = 0; i <= n; i++) {
            double progress = (double) i / n;
            double angle = Math.toRadians(startDegrees + (endDegrees - startDegrees) * easing.apply(progress));
            Vec3 position = new Vec3(center.x() + radius * Math.cos(angle), center.y() + heightOffset,
                    center.z() + radius * Math.sin(angle));
            long time = Math.round(totalMillis * progress);
            points.add(new Waypoint("", position, 0, 0, i == 0 ? 0 : time - previousTime, Easing.LINEAR, center, 0));
            previousTime = time;
        }
        return new CameraPath(points, true);
    }
}
