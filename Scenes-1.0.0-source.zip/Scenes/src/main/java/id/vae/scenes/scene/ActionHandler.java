package id.vae.scenes.scene;

import java.util.List;

/** Implements one action type. Handlers run on the server main thread. */
public interface ActionHandler {

    /** Upper-case action type, for example CAMERA_MOVE. */
    String type();

    /** Returns configuration problems for the action; empty when valid. */
    default List<String> validate(ActionDefinition action) {
        return List.of();
    }

    ActionResult execute(ActionContext context, ActionDefinition action) throws Exception;
}
