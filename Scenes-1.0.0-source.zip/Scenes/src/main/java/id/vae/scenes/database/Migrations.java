package id.vae.scenes.database;

import java.util.List;

/** Ordered schema migrations. Never edit an applied migration; append a new one. */
final class Migrations {

    record Migration(int version, String description, List<String> statements) {
    }

    private Migrations() {
    }

    static List<Migration> all() {
        return List.of(new Migration(1, "Initial schema", List.of(
                """
                CREATE TABLE players (
                    uuid       TEXT PRIMARY KEY,
                    name       TEXT NOT NULL,
                    first_seen INTEGER NOT NULL,
                    last_seen  INTEGER NOT NULL
                )
                """,
                """
                CREATE TABLE player_progress (
                    uuid            TEXT NOT NULL,
                    scene_id        TEXT NOT NULL,
                    completed_count INTEGER NOT NULL DEFAULT 0,
                    first_completed INTEGER NOT NULL DEFAULT 0,
                    last_played     INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (uuid, scene_id),
                    FOREIGN KEY (uuid) REFERENCES players(uuid) ON DELETE CASCADE
                )
                """,
                "CREATE INDEX idx_progress_scene ON player_progress(scene_id)",
                "CREATE INDEX idx_progress_last_played ON player_progress(uuid, last_played)",
                """
                CREATE TABLE scenes (
                    id              TEXT PRIMARY KEY,
                    name            TEXT NOT NULL,
                    description     TEXT NOT NULL DEFAULT '',
                    enabled         INTEGER NOT NULL DEFAULT 1,
                    priority        INTEGER NOT NULL DEFAULT 0,
                    cooldown_ms     INTEGER NOT NULL DEFAULT 0,
                    trigger_json    TEXT NOT NULL DEFAULT '{}',
                    conditions_json TEXT NOT NULL DEFAULT '[]',
                    data_json       TEXT NOT NULL DEFAULT '{}',
                    created_at      INTEGER NOT NULL,
                    updated_at      INTEGER NOT NULL
                )
                """,
                """
                CREATE TABLE scene_actions (
                    id              TEXT PRIMARY KEY,
                    scene_id        TEXT NOT NULL,
                    type            TEXT NOT NULL,
                    ord             INTEGER NOT NULL,
                    delay_ms        INTEGER NOT NULL DEFAULT 0,
                    duration_ms     INTEGER NOT NULL DEFAULT 0,
                    easing          TEXT NOT NULL DEFAULT 'LINEAR',
                    enabled         INTEGER NOT NULL DEFAULT 1,
                    conditions_json TEXT NOT NULL DEFAULT '[]',
                    config_json     TEXT NOT NULL DEFAULT '{}',
                    FOREIGN KEY (scene_id) REFERENCES scenes(id) ON DELETE CASCADE
                )
                """,
                "CREATE INDEX idx_actions_scene_order ON scene_actions(scene_id, ord)",
                """
                CREATE TABLE web_admins (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    password_hash TEXT NOT NULL,
                    role          TEXT NOT NULL,
                    created_at    INTEGER NOT NULL,
                    last_login    INTEGER,
                    enabled       INTEGER NOT NULL DEFAULT 1
                )
                """,
                """
                CREATE TABLE web_sessions (
                    token_hash TEXT PRIMARY KEY,
                    admin_id   INTEGER NOT NULL,
                    csrf_token TEXT NOT NULL,
                    created_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL,
                    ip         TEXT,
                    FOREIGN KEY (admin_id) REFERENCES web_admins(id) ON DELETE CASCADE
                )
                """,
                "CREATE INDEX idx_sessions_expires ON web_sessions(expires_at)",
                """
                CREATE TABLE activity_logs (
                    id      INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts      INTEGER NOT NULL,
                    level   TEXT NOT NULL,
                    actor   TEXT NOT NULL,
                    action  TEXT NOT NULL,
                    details TEXT NOT NULL DEFAULT ''
                )
                """,
                "CREATE INDEX idx_activity_ts ON activity_logs(ts)",
                """
                CREATE TABLE settings (
                    key        TEXT PRIMARY KEY,
                    value      TEXT NOT NULL,
                    updated_at INTEGER NOT NULL
                )
                """
        )), new Migration(2, "Scope action ids per scene", List.of(
                "DROP TABLE scene_actions",
                """
                CREATE TABLE scene_actions (
                    id              TEXT NOT NULL,
                    scene_id        TEXT NOT NULL,
                    type            TEXT NOT NULL,
                    ord             INTEGER NOT NULL,
                    delay_ms        INTEGER NOT NULL DEFAULT 0,
                    duration_ms     INTEGER NOT NULL DEFAULT 0,
                    easing          TEXT NOT NULL DEFAULT 'LINEAR',
                    enabled         INTEGER NOT NULL DEFAULT 1,
                    conditions_json TEXT NOT NULL DEFAULT '[]',
                    config_json     TEXT NOT NULL DEFAULT '{}',
                    PRIMARY KEY (scene_id, id),
                    FOREIGN KEY (scene_id) REFERENCES scenes(id) ON DELETE CASCADE
                )
                """,
                "CREATE INDEX idx_actions_scene_order ON scene_actions(scene_id, ord)"
        )));
    }
}
