package id.vae.scenes.sound;

import id.vae.scenes.camera.CameraPose;
import id.vae.scenes.camera.FakeCameraControl;
import id.vae.scenes.camera.Vec3;
import id.vae.scenes.scene.EngineHarness;
import id.vae.scenes.scene.PresetLibrary;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static id.vae.scenes.scene.TestSupport.action;
import static id.vae.scenes.scene.TestSupport.scene;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SoundTest {

    private static final class FakeOutput implements SoundOutput {
        final List<String> events = new ArrayList<>();

        @Override
        public void play(UUID player, SoundSpec spec, Vec3 position) {
            events.add("play:" + spec.key() + "@" + (position == null ? "player" : position.x() + "," + position.y()
                    + "," + position.z()) + "|" + spec.volume() + "|" + spec.pitch() + "|" + spec.category());
        }

        @Override
        public void stop(UUID player, String key, String category) {
            events.add("stop:" + key);
        }
    }

    private EngineHarness h;
    private FakeOutput output;
    private FakeCameraControl camera;
    private SoundService service;
    private PresetLibrary library;

    @BeforeEach
    void setUp() {
        h = new EngineHarness();
        output = new FakeOutput();
        camera = new FakeCameraControl();
        service = new SoundService(output, camera, h.clock, h.log);
        library = new PresetLibrary(Map.of("soft_breathing",
                Map.of("key", "entity.player.breath", "volume", 0.6, "pitch", 0.8, "category", "PLAYERS")));
        SoundActions.registerAll(h.registry, service, library);
    }

    private static SoundSpec spec(String key, SoundSpec.Location location, Vec3 point, int repeat, long interval,
                                  boolean stopOnEnd) {
        return new SoundSpec(key, 1f, 1f, "MASTER", location, point, false, repeat, interval, stopOnEnd);
    }

    @Test
    void soundPlaysAtOnceAndRepeatsOnSchedule() {
        service.play(h.alice, spec("a.b", SoundSpec.Location.PLAYER, null, 2, 500, false));
        assertEquals(1, output.events.size());

        h.clock.advance(1000);

        assertEquals(3, output.events.size());
    }

    @Test
    void cameraAndWorldLocationsAreResolved() {
        camera.begin(h.alice, new CameraPose(10, 70, 20, 0, 0));

        service.play(h.alice, spec("a.b", SoundSpec.Location.CAMERA, null, 0, 0, false));
        service.play(h.alice, spec("c.d", SoundSpec.Location.WORLD, new Vec3(1, 2, 3), 0, 0, false));

        assertTrue(output.events.get(0).startsWith("play:a.b@10.0,70.0,20.0"));
        assertTrue(output.events.get(1).startsWith("play:c.d@1.0,2.0,3.0"));
    }

    @Test
    void endSceneStopsOnlyStopOnEndSoundsAndCancelsRepeats() {
        service.play(h.alice, spec("loop", SoundSpec.Location.PLAYER, null, 5, 1000, true));
        service.play(h.alice, spec("keep", SoundSpec.Location.PLAYER, null, 0, 0, false));

        service.endScene(h.alice);
        h.clock.advance(10_000);

        assertEquals(List.of("play:loop", "play:keep", "stop:loop"),
                output.events.stream().map(e -> e.split("@|\\|")[0]).toList());
    }

    @Test
    void stopWithoutKeyStopsEverythingStarted() {
        service.play(h.alice, spec("one", SoundSpec.Location.PLAYER, null, 0, 0, false));
        service.play(h.alice, spec("two", SoundSpec.Location.PLAYER, null, 3, 1000, false));

        service.stop(h.alice, null);
        h.clock.advance(5000);

        long stops = output.events.stream().filter(e -> e.startsWith("stop:")).count();
        assertEquals(2, stops);
        assertEquals(2, output.events.stream().filter(e -> e.startsWith("play:")).count());
    }

    @Test
    void soundActionResolvesPresetsAndOverrides() {
        h.run(scene("intro", 0, action("s", "SOUND_PLAY", 0, 0, Map.of("preset", "soft_breathing", "volume", 0.3))));

        assertEquals("play:entity.player.breath@player|0.3|0.8|PLAYERS", output.events.get(0));
    }

    @Test
    void playerPlaySoundIsAnAlias() {
        h.run(scene("intro", 0, action("s", "PLAYER_PLAY_SOUND", 0, 0, Map.of("key", "block.portal.travel"))));

        assertTrue(output.events.get(0).startsWith("play:block.portal.travel"));
    }

    @Test
    void cancellingTheSceneStopsMarkedSoundsAndRepeats() {
        h.run(scene("intro", 0, action("s", "SOUND_PLAY", 0, 0,
                Map.of("key", "ambient.cave", "repeat", 5, "repeat-interval-ms", 1000, "stop-on-end", true))));

        h.engine.stop(h.alice, "test");
        h.clock.advance(10_000);

        assertEquals(1, output.events.stream().filter(e -> e.startsWith("play:")).count());
        assertTrue(output.events.contains("stop:ambient.cave"));
    }

    @Test
    void soundStopActionStopsByKeyOrEverything() {
        h.run(scene("intro", 0,
                action("a", "SOUND_PLAY", 0, 0, Map.of("key", "one.sound")),
                action("b", "SOUND_PLAY", 0, 0, Map.of("key", "two.sound")),
                action("stop", "SOUND_STOP", 100, 0, Map.of("key", "one.sound")),
                action("stopAll", "SOUND_STOP", 200, 0, Map.of())));

        h.clock.advance(300);

        assertTrue(output.events.contains("stop:one.sound"));
        assertTrue(output.events.contains("stop:two.sound"));
    }

    @Test
    void validationReportsBadSoundSettings() {
        assertTrue(h.errors(action("a", "SOUND_PLAY", 0, 0, Map.of())).contains("key"));
        assertTrue(h.errors(action("a", "SOUND_PLAY", 0, 0, Map.of("key", "Bad Key!"))).contains("invalid sound key"));
        assertTrue(h.errors(action("a", "SOUND_PLAY", 0, 0, Map.of("preset", "nope"))).contains("preset"));
        assertTrue(h.errors(action("a", "SOUND_PLAY", 0, 0, Map.of("key", "a.b", "volume", 50))).contains("volume"));
        assertTrue(h.errors(action("a", "SOUND_PLAY", 0, 0, Map.of("key", "a.b", "pitch", 3))).contains("pitch"));
        assertTrue(h.errors(action("a", "SOUND_PLAY", 0, 0, Map.of("key", "a.b", "category", "LOUD")))
                .contains("category"));
        assertTrue(h.errors(action("a", "SOUND_PLAY", 0, 0, Map.of("key", "a.b", "location", "WORLD")))
                .contains("position"));
        assertTrue(h.errors(action("a", "SOUND_PLAY", 0, 0, Map.of("key", "a.b", "repeat", 2))).contains("repeat-interval"));
        assertEquals("", h.errors(action("a", "SOUND_PLAY", 0, 0, Map.of("key", "minecraft:entity.player.breath"))));
        assertEquals("", h.errors(action("a", "SOUND_PLAY", 0, 0, Map.of("preset", "soft_breathing"))));
        assertEquals("", h.errors(action("a", "SOUND_STOP", 0, 0, Map.of())));
    }
}
