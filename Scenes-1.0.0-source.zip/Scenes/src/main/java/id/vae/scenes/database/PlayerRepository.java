package id.vae.scenes.database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public final class PlayerRepository {

    public record PlayerRecord(UUID uuid, String name, long firstSeen, long lastSeen) {
    }

    private final DatabaseManager db;

    public PlayerRepository(DatabaseManager db) {
        this.db = db;
    }

    public void upsert(UUID uuid, String name, long nowMillis) throws SQLException {
        db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO players(uuid, name, first_seen, last_seen) VALUES(?, ?, ?, ?) "
                            + "ON CONFLICT(uuid) DO UPDATE SET name = excluded.name, last_seen = excluded.last_seen")) {
                ps.setString(1, uuid.toString());
                ps.setString(2, name);
                ps.setLong(3, nowMillis);
                ps.setLong(4, nowMillis);
                return ps.executeUpdate();
            }
        });
    }

    public Optional<PlayerRecord> find(UUID uuid) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT uuid, name, first_seen, last_seen FROM players WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? Optional.of(read(rs)) : Optional.<PlayerRecord>empty();
                }
            }
        });
    }

    public List<PlayerRecord> list(int limit, int offset) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT uuid, name, first_seen, last_seen FROM players ORDER BY last_seen DESC LIMIT ? OFFSET ?")) {
                ps.setInt(1, limit);
                ps.setInt(2, offset);
                try (ResultSet rs = ps.executeQuery()) {
                    List<PlayerRecord> out = new ArrayList<>();
                    while (rs.next()) {
                        out.add(read(rs));
                    }
                    return out;
                }
            }
        });
    }

    private static PlayerRecord read(ResultSet rs) throws SQLException {
        return new PlayerRecord(UUID.fromString(rs.getString(1)), rs.getString(2), rs.getLong(3), rs.getLong(4));
    }
}
