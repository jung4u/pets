package id.vae.scenes.core;

/** Thrown when a service fails to start. */
public final class ServiceStartException extends Exception {

    private static final long serialVersionUID = 1L;

    private final String serviceName;

    public ServiceStartException(String serviceName, Throwable cause) {
        super("Service '" + serviceName + "' failed to start: " + cause.getMessage(), cause);
        this.serviceName = serviceName;
    }

    public String serviceName() {
        return serviceName;
    }
}
