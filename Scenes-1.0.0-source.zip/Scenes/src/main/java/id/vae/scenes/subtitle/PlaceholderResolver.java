package id.vae.scenes.subtitle;

import java.util.UUID;

@FunctionalInterface
public interface PlaceholderResolver {

    /** Replaces placeholders; values taken from players must already be escaped for MiniMessage. */
    String apply(UUID player, String text);
}
