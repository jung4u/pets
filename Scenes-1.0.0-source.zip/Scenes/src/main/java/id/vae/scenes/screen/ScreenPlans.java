package id.vae.scenes.screen;

import id.vae.scenes.util.Easing;

import java.util.function.DoubleFunction;

/** Builds the timelines of the screen effects. Intensity scales every channel (0..1). */
public final class ScreenPlans {

    private static final long FLASH_MILLIS = 100;

    private ScreenPlans() {
    }

    public static boolean holdsByDefault(ScreenEffectType type) {
        return type == ScreenEffectType.FADE_OUT || type == ScreenEffectType.EYE_CLOSE;
    }

    public static ScreenPlan create(ScreenEffectType type, long durationMillis, double intensity, Easing easing,
                                    int repeat, long repeatGapMillis, boolean hold) {
        double i = Math.max(0, Math.min(1, intensity));
        long duration = Math.max(type == ScreenEffectType.FLASH ? FLASH_MILLIS : 1, durationMillis);
        DoubleFunction<ScreenFrame> shape = shape(type, i, easing);
        ScreenFrame end = shape.apply(1.0);
        int times = Math.max(1, repeat);
        long gap = Math.max(0, repeatGapMillis);
        long cycle = duration + gap;
        long total = times * duration + (times - 1) * gap;

        return new ScreenPlan(channelOf(type), total, hold, end, "", elapsed -> {
            long index = Math.min(times - 1, elapsed / cycle);
            long within = elapsed - index * cycle;
            if (within >= duration) {
                return ScreenFrame.ZERO;
            }
            return type == ScreenEffectType.FLASH
                    ? new ScreenFrame(0, 0, 0, 0, within < FLASH_MILLIS ? i : 0)
                    : shape.apply((double) within / duration);
        });
    }

    public static ScreenChannel channelOf(ScreenEffectType type) {
        return switch (type) {
            case FLASH -> ScreenChannel.FLASH;
            case BLUR -> ScreenChannel.BLUR;
            case VIGNETTE -> ScreenChannel.VIGNETTE;
            case DARKNESS -> ScreenChannel.DARKNESS;
            default -> ScreenChannel.BLACK;
        };
    }

    private static DoubleFunction<ScreenFrame> shape(ScreenEffectType type, double i, Easing easing) {
        return switch (type) {
            case FADE_OUT -> u -> new ScreenFrame(i * easing.apply(u), 0, 0, 0, 0);
            case FADE_IN -> u -> new ScreenFrame(i * (1 - easing.apply(u)), 0, 0, 0, 0);
            case BLACK_SCREEN -> u -> new ScreenFrame(i, 0, 0, 0, 0);
            case EYE_CLOSE -> u -> new ScreenFrame(i * easing.apply(u), 0, i * easing.apply(Math.min(1, u * 1.5)), 0, 0);
            case EYE_OPEN -> u -> new ScreenFrame(i * (1 - easing.apply(u)), 0, i * (1 - easing.apply(u)), 0, 0);
            case BLINK -> blink(i, easing, 1);
            case DOUBLE_BLINK -> blink(i, easing, 2);
            case TRIPLE_BLINK -> blink(i, easing, 3);
            case FLASH -> u -> new ScreenFrame(0, 0, 0, 0, i);
            case BLUR -> u -> new ScreenFrame(0, 0, 0, i * trapezoid(u, easing), 0);
            case VIGNETTE -> u -> new ScreenFrame(0, 0, i * trapezoid(u, easing), 0, 0);
            case DARKNESS -> u -> new ScreenFrame(0, i * trapezoid(u, easing), 0, 0, 0);
        };
    }

    /** Each blink: close 30%, hold shut 10%, open 40%, rest 20% of its slot. */
    private static DoubleFunction<ScreenFrame> blink(double i, Easing easing, int count) {
        return u -> {
            double p = (u * count) % 1.0;
            if (u >= 1.0) {
                p = 0;
            }
            double closed;
            if (p < 0.3) {
                closed = easing.apply(p / 0.3);
            } else if (p < 0.4) {
                closed = 1;
            } else if (p < 0.8) {
                closed = 1 - easing.apply((p - 0.4) / 0.4);
            } else {
                closed = 0;
            }
            return new ScreenFrame(i * closed, 0, i * closed * 0.8, 0, 0);
        };
    }

    /** Rises over the first quarter, holds, falls over the last quarter. */
    private static double trapezoid(double u, Easing easing) {
        if (u < 0.25) {
            return easing.apply(u / 0.25);
        }
        if (u > 0.75) {
            return easing.apply((1 - u) / 0.25);
        }
        return 1;
    }
}
