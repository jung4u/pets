package id.vae.scenes.bukkit;

import id.vae.scenes.scene.PlayerGateway;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.UUID;

/** Bukkit-backed player lookups. Call from the main thread only. */
public final class BukkitPlayerGateway implements PlayerGateway {

    @Override
    public boolean isOnline(UUID player) {
        Player p = Bukkit.getPlayer(player);
        return p != null && p.isOnline();
    }

    @Override
    public boolean hasPermission(UUID player, String permission) {
        Player p = Bukkit.getPlayer(player);
        return p != null && p.hasPermission(permission);
    }

    @Override
    public String worldOf(UUID player) {
        Player p = Bukkit.getPlayer(player);
        return p == null ? null : p.getWorld().getName();
    }

    @Override
    public String nameOf(UUID player) {
        Player p = Bukkit.getPlayer(player);
        return p == null ? null : p.getName();
    }
}
