package id.vae.scenes.bukkit;

import id.vae.scenes.config.ConfigService;
import id.vae.scenes.core.Service;
import id.vae.scenes.database.SettingsRepository;
import id.vae.scenes.scene.SceneDefinition;
import id.vae.scenes.scene.SceneManager;
import id.vae.scenes.scene.SceneMapper;
import id.vae.scenes.scene.SceneResult;
import id.vae.scenes.util.ScenesLogger;
import org.bukkit.configuration.InvalidConfigurationException;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Imports scenes from {@code plugins/Scenes/scenes/*.yml}. Each scene id is imported once: after that the
 * database is the source of truth (the web panel edits it), so a reload never overwrites admin changes
 * and never brings back a scene an admin deleted. A broken file is reported and skipped.
 */
public final class SceneSeeder implements Service {

    public static final List<String> BUNDLED = List.of("first_join.yml", "nether.yml", "the_end.yml", "rtp.yml",
            "death.yml");
    private static final String MARKER = "seeded.";

    public record Result(int imported, List<String> problems) {
    }

    private final SceneManager scenes;
    private final SettingsRepository settings;
    private final Path folder;
    private final ConfigService.ResourceLoader resources;
    private final ScenesLogger log;

    public SceneSeeder(SceneManager scenes, SettingsRepository settings, Path dataFolder,
                       ConfigService.ResourceLoader resources, ScenesLogger log) {
        this.scenes = scenes;
        this.settings = settings;
        this.folder = dataFolder.resolve("scenes");
        this.resources = resources;
        this.log = log;
    }

    @Override
    public String name() {
        return "scene-seeder";
    }

    @Override
    public void start() throws Exception {
        Files.createDirectories(folder);
        for (String name : BUNDLED) {
            Path target = folder.resolve(name);
            if (Files.notExists(target)) {
                try (InputStream in = resources.open("scenes/" + name)) {
                    if (in != null) {
                        Files.copy(in, target);
                    }
                }
            }
        }
        Result result = importNew();
        if (result.imported() > 0) {
            log.info("Imported " + result.imported() + " scene(s) from the scenes folder.");
        }
    }

    @Override
    public void stop() {
        // Nothing to release.
    }

    public synchronized Result importNew() {
        List<String> problems = new ArrayList<>();
        int imported = 0;
        List<Path> files;
        try (Stream<Path> list = Files.list(folder)) {
            files = list.filter(p -> p.getFileName().toString().endsWith(".yml")).sorted().toList();
        } catch (IOException e) {
            problems.add("could not read the scenes folder: " + e.getMessage());
            return new Result(0, problems);
        }
        for (Path file : files) {
            String label = file.getFileName().toString();
            try {
                Map<String, Object> raw = YamlMaps.load(file);
                SceneMapper.Parsed parsed = SceneMapper.fromMap(raw);
                if (!parsed.errors().isEmpty()) {
                    problems.add(label + ": " + String.join("; ", parsed.errors()));
                    continue;
                }
                SceneDefinition scene = parsed.scene();
                if (scenes.find(scene.id()).isPresent()) {
                    markSeeded(scene.id());
                    continue;
                }
                if (isSeeded(scene.id())) {
                    continue;
                }
                SceneResult result = scenes.create(scene);
                if (result.ok()) {
                    markSeeded(scene.id());
                    imported++;
                } else {
                    problems.add(label + ": " + String.join("; ", result.errors()));
                }
            } catch (IOException | InvalidConfigurationException | SQLException e) {
                problems.add(label + ": " + e.getMessage());
            }
        }
        problems.forEach(p -> log.warn("Scene file not imported: " + p));
        return new Result(imported, problems);
    }

    private static final java.util.regex.Pattern FILE_NAME = java.util.regex.Pattern.compile("[a-z0-9_-]{1,64}");

    public List<String> fileNames() {
        try (Stream<Path> list = Files.list(folder)) {
            return list.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".yml"))
                    .map(n -> n.substring(0, n.length() - 4)).sorted().toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    /**
     * Imports one file from the scenes folder (given without ".yml"). An existing scene with the same id is
     * only replaced when {@code replace} is set. Nothing changes unless the scene is valid. Returns the
     * problems found; an empty list means the scene was imported.
     */
    public synchronized List<String> importFile(String name, boolean replace) {
        if (!FILE_NAME.matcher(name).matches()) {
            return List.of("file names use lower case letters, digits, '-' and '_'");
        }
        Path file = folder.resolve(name + ".yml");
        if (Files.notExists(file)) {
            return List.of("no file scenes/" + name + ".yml");
        }
        try {
            SceneMapper.Parsed parsed = SceneMapper.fromMap(YamlMaps.load(file));
            if (!parsed.errors().isEmpty()) {
                return parsed.errors();
            }
            SceneDefinition scene = parsed.scene();
            boolean exists = scenes.find(scene.id()).isPresent();
            if (exists && !replace) {
                return List.of("scene '" + scene.id() + "' already exists; add 'replace' to overwrite it");
            }
            SceneResult result = exists ? scenes.update(scene) : scenes.create(scene);
            if (!result.ok()) {
                return result.errors();
            }
            markSeeded(scene.id());
            return List.of();
        } catch (IOException | InvalidConfigurationException | SQLException e) {
            return List.of(e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    /** Writes a scene to scenes/&lt;id&gt;.yml so it can be edited and imported again. Returns an error message or null. */
    public synchronized String exportScene(String id, boolean overwrite) {
        SceneDefinition scene = scenes.find(id).orElse(null);
        if (scene == null) {
            return "unknown scene '" + id + "'";
        }
        Path file = folder.resolve(id + ".yml");
        if (Files.exists(file) && !overwrite) {
            return "scenes/" + id + ".yml already exists; add 'overwrite' to replace it";
        }
        try {
            Files.createDirectories(folder);
            Files.writeString(file, YamlMaps.toYaml(SceneMapper.toMap(scene)), java.nio.charset.StandardCharsets.UTF_8);
            return null;
        } catch (IOException e) {
            return e.getMessage();
        }
    }

    private boolean isSeeded(String id) throws SQLException {
        return settings.get(MARKER + id).isPresent();
    }

    private void markSeeded(String id) throws SQLException {
        if (!isSeeded(id)) {
            settings.set(MARKER + id, "1", System.currentTimeMillis());
        }
    }
}
