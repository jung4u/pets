package id.vae.scenes.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EasingTest {

    @Test
    void everyCurveStartsAtZeroAndEndsAtOne() {
        for (Easing easing : Easing.values()) {
            assertEquals(0.0, easing.apply(0.0), 1e-9);
            assertEquals(1.0, easing.apply(1.0), 1e-9);
        }
    }

    @Test
    void inputsOutsideTheRangeAreClamped() {
        for (Easing easing : Easing.values()) {
            assertEquals(0.0, easing.apply(-3.0), 1e-9);
            assertEquals(1.0, easing.apply(7.0), 1e-9);
        }
    }

    @Test
    void curvesNeverDecrease() {
        for (Easing easing : Easing.values()) {
            double previous = 0;
            for (int i = 1; i <= 100; i++) {
                double value = easing.apply(i / 100.0);
                assertTrue(value >= previous - 1e-9);
                previous = value;
            }
        }
    }

    @Test
    void knownMidpoints() {
        assertEquals(0.5, Easing.LINEAR.apply(0.5), 1e-9);
        assertEquals(0.25, Easing.EASE_IN.apply(0.5), 1e-9);
        assertEquals(0.75, Easing.EASE_OUT.apply(0.5), 1e-9);
        assertEquals(0.5, Easing.SMOOTHSTEP.apply(0.5), 1e-9);
        assertEquals(0.5, Easing.SINE.apply(0.5), 1e-9);
    }

    @Test
    void parseFallsBackOnUnknownNames() {
        assertEquals(Easing.CUBIC, Easing.parse(" cubic ", Easing.LINEAR));
        assertEquals(Easing.LINEAR, Easing.parse("wobble", Easing.LINEAR));
        assertEquals(Easing.SINE, Easing.parse(null, Easing.SINE));
    }
}
