package id.vae.scenes.bukkit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RestoreStoreTest {

    private static final RestoreStore.Saved STATE =
            new RestoreStore.Saved("SURVIVAL", true, true, "world_nether", 12.5, 70.0, -33.25, 90.5f, -12.0f);

    @Test
    void savedStateComesBackExactly(@TempDir Path dir) throws Exception {
        RestoreStore store = new RestoreStore(dir.resolve("pending"));
        UUID id = UUID.randomUUID();

        store.save(id, STATE);

        assertEquals(STATE, store.load(id).orElseThrow());
    }

    @Test
    void deletingForgetsTheStateAndUnknownPlayersHaveNone(@TempDir Path dir) throws Exception {
        RestoreStore store = new RestoreStore(dir);
        UUID id = UUID.randomUUID();
        assertTrue(store.load(id).isEmpty());

        store.save(id, STATE);
        store.delete(id);
        store.delete(id);

        assertTrue(store.load(id).isEmpty());
    }

    @Test
    void savingAgainReplacesTheOldState(@TempDir Path dir) throws Exception {
        RestoreStore store = new RestoreStore(dir);
        UUID id = UUID.randomUUID();
        store.save(id, STATE);

        store.save(id, new RestoreStore.Saved("CREATIVE", false, false, "world", 1, 2, 3, 0f, 0f));

        assertEquals("CREATIVE", store.load(id).orElseThrow().gameMode());
        assertFalse(Files.exists(dir.resolve(id + ".tmp")));
    }

    @Test
    void aCorruptFileIsTreatedAsNoState(@TempDir Path dir) throws Exception {
        RestoreStore store = new RestoreStore(dir);
        UUID id = UUID.randomUUID();
        Files.writeString(dir.resolve(id + ".properties"), "x=not-a-number\ny=1\n");

        assertTrue(store.load(id).isEmpty());
    }
}
