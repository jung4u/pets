package id.vae.scenes.sound;

import id.vae.scenes.camera.Vec3;

import java.util.UUID;

/** Plays sounds to real players. A null position means the player's own location. */
public interface SoundOutput {

    void play(UUID player, SoundSpec spec, Vec3 position);

    /** Stops the sound key for the player. */
    void stop(UUID player, String key, String category);
}
