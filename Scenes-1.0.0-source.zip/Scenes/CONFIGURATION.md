# Configuration

Everything lives in `plugins/Scenes/`:

    config.yml          general settings, limits, camera, join, AuthMe and RTP hooks
    database.yml        SQLite file and backups
    scenes/*.yml        scene files (the five built-in scenes, and any you add)
    sounds/presets.yml  sound library
    particles/presets.yml  particle library
    data/scenes.db      the database (scenes, player progress, settings)
    data/pending/       crash-recovery files (normally empty)
    backups/            database backups

Run `/scenes reload` after editing. A file with a mistake is reported and the previous settings stay
active; your files are never overwritten or deleted by the plugin.

## config.yml

| Key | Default | Meaning |
| --- | --- | --- |
| `debug` | `false` | verbose logging |
| `limits.max-concurrent-scenes` | `10` | scenes running at once on the whole server |
| `limits.max-camera-sessions` | `10` | cameras running at once; further camera shots are skipped |
| `limits.max-particles-per-action` | `200` | most particles in one emission |
| `camera.backend` | `AUTO` | `AUTO`, `PROTOCOLLIB`, `SPECTATOR` or `NONE` |
| `camera.bedrock-backend` | `NONE` | `SPECTATOR` or `NONE` for Bedrock players (Geyser/Floodgate) |
| `camera.max-distance` | `96` | farthest a camera shot may be from the player, in blocks |
| `camera.eye-height` | `0.0` | calibrates the camera height |
| `join.spawn-delay-ticks` | `40` | wait after joining or logging in before scenes may start |
| `integrations.authme` | `true` | wait for AuthMe login/register before login and first-join scenes |
| `rtp.enabled` | `true` | hold back RTP commands and play the RTP scene |
| `rtp.commands` | `[rtp, wild, randomtp]` | commands treated as RTP |
| `rtp.timeout-ms` | `15000` | how long a teleport may take before it counts as failed |
| `rtp.min-distance` | `16` | smallest move that counts as the RTP teleport |

## database.yml

| Key | Default | Meaning |
| --- | --- | --- |
| `file` | `data/scenes.db` | database file, relative to the plugin folder |
| `backup.enabled` | `true` | scheduled backups into `backups/` |
| `backup.on-startup` | `true` | also back up when the server starts |
| `backup.interval-minutes` | `360` | time between backups |
| `backup.keep` | `10` | how many backups to keep |

## Scenes

A scene is a list of actions. Scenes are stored in the database and read from `scenes/*.yml` once, by scene id:

- The five built-in scenes are imported the first time the plugin runs.
- To change a scene: `/scenes export <id>`, edit `scenes/<id>.yml`, then `/scenes import <id> replace`. Nothing changes unless the edited scene is valid.
- To add a scene: put a new `.yml` in `scenes/` and run `/scenes reload` (or `/scenes import <file>`).
- A scene you delete does not come back on reload.

Scene file format:

    id: my_scene                 # a-z, 0-9, underscore
    name: My Scene
    description: Optional text
    enabled: true
    priority: 50                 # a higher priority preempts a lower one
    cooldown-ms: 0               # per player, after the scene ends
    duration-ms: 0               # minimum length (the scene ends after its last action anyway)
    trigger: {type: MANUAL, once-per-player: false, permission: "", world: "", argument: ""}
    conditions: []               # all must match for the scene to start
    actions:
      - id: lock
        type: PLAYER_LOCK
        delay-ms: 0              # start time, from the beginning of the scene
        duration-ms: 0           # how long the action itself lasts
        easing: LINEAR           # LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, SMOOTHSTEP, CUBIC, SINE
        enabled: true
        conditions: []
        config: {}               # settings of the action type

Actions start at their `delay-ms`. A failing action is logged (scene, action and cause) and the scene
carries on. One scene runs per player; a higher priority preempts a lower one. Everything an action
changed is undone when the scene ends, is stopped, or the player leaves.

### Triggers

`MANUAL` (only from commands), `FIRST_JOIN`, `LOGIN_SUCCESS`, `REGISTER_SUCCESS`, `WORLD_CHANGE`,
`NETHER_ENTER`, `END_ENTER`, `RTP_START`, `RTP_SUCCESS`, `PLAYER_DEATH`, `PLAYER_RESPAWN`, `COMMAND`,
`PERMISSION`, `CUSTOM`. A trigger can require a `permission` and a `world`, and be `once-per-player`.
`COMMAND` and `CUSTOM` also need an `argument`. Of these, `FIRST_JOIN`, `LOGIN_SUCCESS`, `REGISTER_SUCCESS`,
`WORLD_CHANGE`, `NETHER_ENTER`, `END_ENTER`, `RTP_START`, `RTP_SUCCESS`, `PLAYER_DEATH` and `PLAYER_RESPAWN` are fired
by the plugin itself.

### Conditions

`PERMISSION` (`permission`), `WORLD` (`world`), `VARIABLE_EQUALS` (`key`, `value`) and `PLAYER_ONLINE`.
Any condition accepts `negate: true`.

### Control actions

| Action | Settings |
| --- | --- |
| `DELAY` | pauses the timeline for the action's duration |
| `WAIT_FOR_CONDITION` | `condition`, `timeout-ms` (10000), `on-timeout` (`continue` or `abort`) |
| `END_SCENE` | ends the scene |
| `SKIP` | `actions`: ids not to run |
| `BRANCH` | `condition`, `then-skip`, `else-skip`, `then-end`, `else-end` |
| `SET_VARIABLE` | `key`, `value` |
| `PLAYER_LOCK`, `PLAYER_UNLOCK` | freeze and release the player (always released when the scene ends) |

A `condition` setting is written like `{type: WORLD, world: world_nether}`.

## Camera

The camera is an invisible marker armor stand that only the viewing player can see. The player never
moves, keeps their game mode, inventory and health, and nothing is left behind: the camera is removed
when the scene ends or is cancelled, and when the player quits, dies, changes world or the plugin stops.

Backends (`camera.backend` in `config.yml`; copy the `camera:` block from the bundled config if your
`config.yml` is old):

| Backend | How it works |
| --- | --- |
| `AUTO` (default) | ProtocolLib camera packet if ProtocolLib is installed, otherwise `SPECTATOR` |
| `PROTOCOLLIB` | Vanilla camera packet; the player stays in their own game mode, movement is frozen by `MovementLock` |
| `SPECTATOR` | Temporary spectator mode on the camera entity; game mode, flight state and exact location are saved and restored |
| `NONE` | Camera actions are skipped; the rest of the scene still plays |

Bedrock players (detected by their Floodgate UUID) use `camera.bedrock-backend` (`NONE` or `SPECTATOR`).

Limits to know:

- With the ProtocolLib backend the client only has chunks near the player, so shots must stay within
  `camera.max-distance` blocks (default 96); farther waypoints fail that action and the scene carries on.
  The `SPECTATOR` backend does not have this limit because the server follows the camera.
- The camera stays in the player's world.
- Camera height is calibrated by `camera.eye-height` if shots look slightly high or low.

### Camera actions

Every camera action starts a camera session on demand and registers its own cleanup. An action's
`duration` is how long its movement lasts, `easing` shapes it, and `speed` (default 1.0) scales the times.

| Action | Settings |
| --- | --- |
| `CAMERA_SPAWN` | optional `position` {x, y, z, yaw, pitch}; default is the player's eyes |
| `CAMERA_MOVE` | `mode`: `PATH` (default), `ORBIT` or `FOLLOW` |
| `CAMERA_ROTATE` | `yaw` and/or `pitch` (shortest turn) |
| `CAMERA_FOCUS` | `look-at` {x, y, z} |
| `CAMERA_SHAKE` | `intensity` (default 1.0), `frequency` (default 12 Hz) |
| `CAMERA_RESTORE` | none |
| `PLAYER_LOCK` / `PLAYER_UNLOCK` | none; a lock is always released when the scene ends |

`CAMERA_MOVE` modes:

- `PATH`: `waypoints` (a list of x, y, z, yaw, pitch, `duration-ms`, `easing`, `look-at`, `pause-ms`, `world`),
  `smooth` (spline through the waypoints), `from-current` (default true: start from where the camera is)
- `ORBIT`: `center` {x, y, z}, `radius`, `height`, `start-angle`, `end-angle`, `segments`, `from-current`
- `FOLLOW`: `offset` {x, y, z}, `smoothing-ms`; follows the player and faces them

The action `duration` must be at least as long as the path; validation rejects shorter ones.
Easings: LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, SMOOTHSTEP, CUBIC, SINE.

## Screen effects, subtitles, sounds and particles

No resource pack is needed. Everything below is cleaned up automatically when a scene ends, is
cancelled, or the player quits.

### Screen effects

Common settings: `intensity` (0-1), `speed` (divides the duration), `repeat` (1-20), `repeat-delay-ms`,
`hold` (keep the last look until `SCREEN_CLEAR` or the next effect), `color` (flash only). The action
duration is the effect length, `easing` shapes it.

| Action | What it does |
| --- | --- |
| `SCREEN_FADE` | `direction: OUT` fades to black and holds, `IN` fades from black |
| `SCREEN_BLACKOUT` | solid black for the duration |
| `SCREEN_EYE` | `state: CLOSE` (holds shut) or `OPEN` |
| `SCREEN_BLINK` | `count` 1, 2 or 3 blinks |
| `SCREEN_FLASH` | one bright flash; optional `color` |
| `SCREEN_BLUR`, `SCREEN_VIGNETTE`, `SCREEN_DARKNESS` | rise, hold, fall |
| `SCREEN_SHAKE` | camera shake (uses the camera engine) |
| `SCREEN_CLEAR` | removes every effect and restores the player's own potion effects |

How they are drawn with vanilla features only:

- Black screen uses the Blindness effect. When the screen opens, vanilla fades that effect out over about one second, so the open is smooth but not as long as a very long `FADE_IN` duration.
- Darkness uses the Darkness effect.
- **Blur is a simulation**: a light Nausea wobble, not a blur shader.
- **Vignette is a simulation**: a per-player world-border warning that tints the screen edges red. A black vignette needs a resource pack.
- Flash is a flash particle at the player's eyes.
- Colour is only applied to the flash. Black stays black without a resource pack.

### Subtitles

`SUBTITLE_SHOW`, `SUBTITLE_QUEUE` (a `lines` list, ordered by `order`, each with `delay-ms` and `duration-ms`), `SUBTITLE_HIDE`.
Settings: `text` (MiniMessage; `%player_name%`, `%player_world%` and PlaceholderAPI work), `color`,
`gradient` (two or more hex colours), `bold`, `italic`, `underline`, `position` (`TOP` = title line,
`CENTER` = subtitle line, `BOTTOM` = action bar), `fade-in-ms`, `fade-out-ms`, `priority`, `order`,
`repeat`, `repeat-interval-ms`, `enabled`, `sound`, `volume`, `pitch`. The action duration includes the fades
(default 3000 ms). A subtitle never replaces a higher-priority one that is still showing in the same area.

### Sounds

`SOUND_PLAY` (alias `PLAYER_PLAY_SOUND`) and `SOUND_STOP` (`key` or `all`). Settings: `preset` or `key`,
`volume` (0-10), `pitch` (0-2), `category`, `location` (`PLAYER`, `CAMERA`, `WORLD` with `position`),
`audience` (`PLAYER` or `NEARBY`), `repeat`, `repeat-interval-ms`, `stop-on-end`.
Presets live in `plugins/Scenes/sounds/presets.yml` (soft_breathing, awakening, ambient_atmosphere,
nether_ambient, portal_sound, transition_sound, end_ambient, dragon_growl, cinematic_sound, teleport,
resurrection). Keys are checked for format only; a key that does not exist is silent on the client.

### Particles

`PARTICLE_SPAWN`, `PARTICLE_FOLLOW` (follow is on by default), `PARTICLE_STOP` (`tag` or `all`).
Settings: `preset` or `type`, `shape` (`POINT`, `RING`, `SPHERE`, `SPIRAL`), `amount`, `offset`, `speed`,
`radius`, `height` (up from the player's feet), `direction`, `color` (hex, for DUST and ENTITY_EFFECT),
`interval-ms` (default 250, minimum 50), `anchor` (`PLAYER`, `CAMERA`, `WORLD` with `position`), `audience`.
No per-tick task runs: each effect schedules its own next emission, and `limits.max-particles-per-action`
in `config.yml` caps every emission. Presets live in `plugins/Scenes/particles/presets.yml` (purple_portal,
magical_aura, resurrection, nether_atmosphere, ender_energy, teleportation). `/scenes reload` re-reads both preset files.

## Built-in scenes and hooks

Five scenes ship in `plugins/Scenes/scenes/` and are imported into the database once (by scene id). After
that the database is the source of truth, so a reload never overwrites your edits and never brings back
a scene you deleted. Drop a new `.yml` file in that folder and run `/scenes reload` to import it.
A file with a mistake is reported and skipped; the rest keep working.

| Scene id | Trigger | What happens |
| --- | --- | --- |
| `first_join` | `FIRST_JOIN`, once per player | Eyes closed, camera finds the player, two blinks, the camera rises like someone standing, "Where am I?", "Was I just summoned here?", camera returns, movement unlocked |
| `nether_intro` | `NETHER_ENTER`, once per player | Camera lifts and shows the Nether for 2 seconds, returns, "I think this is what they call the Nether Dimension." |
| `the_end_intro` | `END_ENTER`, once per player | Camera looks to the sky, growl, purple flash, shake, ender particles, "Have I finally reached the end?" |
| `rtp_cinematic` | `RTP_START` | Purple particles, teleport sound, eyes close, the real RTP command runs, eyes open |
| `death_resurrection` | `PLAYER_RESPAWN` | Black screen with purple resurrection particles, eyes open through a blur, "Ancient One has brought you back to life.", double blink |

Notes:

- Camera coordinates in these files use `relative: FACING` (x right, y up, z forward of the player), so the scenes work anywhere. Use `relative: WORLD` for offsets along the world axes, or leave `relative` out for absolute coordinates. Relative offsets work on `CAMERA_SPAWN` (with `look-at`), `CAMERA_MOVE`, `CAMERA_ROTATE` and `CAMERA_FOCUS`.
- **The End:** no dragon entity is spawned, so the real boss fight can never be disturbed. The dragon's arrival is suggested with sound, flash, shake, darkness and particles.
- **Death:** the vanilla death screen cannot be changed, so the scene starts at the moment the player has respawned.
- **First join with AuthMe:** with AuthMe installed (and `integrations.authme: true`), nothing plays until AuthMe reports a login or register. Scenes never play on the login screen. "New" means the server has never seen the player; this is remembered until the scene has been completed, so a player who disconnects halfway gets it again.
- **RTP hook:** the commands in `rtp.commands` are held back for players who may use them, the `RTP_START` scene plays, and its `RTP_EXECUTE` action runs the real command and waits for the teleport. A teleport counts when the player changes world or moves at least `rtp.min-distance` blocks within `rtp.timeout-ms`. If the teleport fails or times out, the scene is aborted and everything is restored. If no RTP scene starts, the command runs as normal. It works with any RTP plugin that teleports the player; it has not been tried against a specific one.
- Trigger `RTP_START` starts the cinematic. `RTP_SUCCESS` fires after a successful teleport, for your own scenes.
- `RTP_EXECUTE` (setting: `timeout-ms`) runs the held-back command and waits for the teleport.
- Screen effects on different channels run together (for example eyes opening while the screen is blurred); a new effect replaces the running one on its own channel.
