package id.vae.scenes.camera;

import id.vae.scenes.util.Easing;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CameraPathTest {

    private static Waypoint wp(double x, double y, double z, float yaw, float pitch, long duration, Easing easing,
                               Vec3 lookAt, long pause) {
        return new Waypoint("", new Vec3(x, y, z), yaw, pitch, duration, easing, lookAt, pause);
    }

    @Test
    void linearPathInterpolatesPositionAndAngles() {
        CameraPath path = new CameraPath(List.of(
                wp(0, 64, 0, 0, 0, 0, Easing.LINEAR, null, 0),
                wp(10, 74, 20, 90, 30, 1000, Easing.LINEAR, null, 0)), false);

        CameraPose mid = path.poseAt(500);

        assertEquals(5.0, mid.x(), 1e-9);
        assertEquals(69.0, mid.y(), 1e-9);
        assertEquals(10.0, mid.z(), 1e-9);
        assertEquals(45.0, mid.yaw(), 1e-4);
        assertEquals(15.0, mid.pitch(), 1e-4);
        assertEquals(1000, path.durationMillis());
    }

    @Test
    void cameraHoldsTheFinalPoseAfterThePathEnds() {
        CameraPath path = new CameraPath(List.of(
                wp(0, 0, 0, 0, 0, 0, Easing.LINEAR, null, 0),
                wp(4, 0, 0, 0, 0, 100, Easing.LINEAR, null, 0)), false);

        assertEquals(4.0, path.poseAt(100).x(), 1e-9);
        assertEquals(4.0, path.poseAt(99_999).x(), 1e-9);
        assertEquals(0.0, path.poseAt(-50).x(), 1e-9);
    }

    @Test
    void pausesHoldThePositionAndShiftTheTimeline() {
        CameraPath path = new CameraPath(List.of(
                wp(0, 0, 0, 0, 0, 0, Easing.LINEAR, null, 200),
                wp(10, 0, 0, 0, 0, 1000, Easing.LINEAR, null, 300)), false);

        assertEquals(0.0, path.poseAt(199).x(), 1e-9);
        assertEquals(5.0, path.poseAt(700).x(), 1e-9);
        assertEquals(10.0, path.poseAt(1200).x(), 1e-9);
        assertEquals(10.0, path.poseAt(1400).x(), 1e-9);
        assertEquals(1500, path.durationMillis());
    }

    @Test
    void easingShapesTheTravel() {
        CameraPath path = new CameraPath(List.of(
                wp(0, 0, 0, 0, 0, 0, Easing.LINEAR, null, 0),
                wp(100, 0, 0, 0, 0, 1000, Easing.EASE_IN, null, 0)), false);

        assertEquals(25.0, path.poseAt(500).x(), 1e-9);
    }

    @Test
    void yawTurnsAlongTheShortestWay() {
        CameraPath path = new CameraPath(List.of(
                wp(0, 0, 0, 350, 0, 0, Easing.LINEAR, null, 0),
                wp(0, 0, 0, 10, 0, 1000, Easing.LINEAR, null, 0)), false);

        float yaw = path.poseAt(500).yaw();

        assertEquals(0.0, ((yaw % 360) + 360) % 360, 1e-4);
    }

    @Test
    void lookAtFacesTheTarget() {
        Vec3 target = new Vec3(0, 0, 10);
        CameraPose ahead = CameraPose.lookAt(new Vec3(0, 0, 0), target);
        CameraPose east = CameraPose.lookAt(new Vec3(10, 0, 10), target);
        CameraPose above = CameraPose.lookAt(new Vec3(0, 10, 0), target);

        assertEquals(0.0, ahead.yaw(), 1e-4);
        assertEquals(0.0, ahead.pitch(), 1e-4);
        assertEquals(90.0, east.yaw(), 1e-4);
        assertEquals(45.0, above.pitch(), 1e-4);
    }

    @Test
    void lookAtWaypointsKeepFacingTheTargetWhileMoving() {
        Vec3 target = new Vec3(0, 64, 0);
        CameraPath path = new CameraPath(List.of(
                wp(10, 64, 0, 0, 0, 0, Easing.LINEAR, target, 0),
                wp(0, 64, 10, 0, 0, 1000, Easing.LINEAR, target, 0)), false);

        CameraPose pose = path.poseAt(400);
        CameraPose expected = CameraPose.lookAt(pose.position(), target);

        assertEquals(expected.yaw(), pose.yaw(), 1e-4);
        assertEquals(expected.pitch(), pose.pitch(), 1e-4);
    }

    @Test
    void smoothPathPassesThroughEveryWaypoint() {
        CameraPath path = new CameraPath(List.of(
                wp(0, 0, 0, 0, 0, 0, Easing.LINEAR, null, 0),
                wp(10, 5, 0, 0, 0, 1000, Easing.LINEAR, null, 0),
                wp(10, 5, 10, 0, 0, 1000, Easing.LINEAR, null, 0),
                wp(0, 0, 10, 0, 0, 1000, Easing.LINEAR, null, 0)), true);

        assertEquals(10.0, path.poseAt(1000).x(), 1e-9);
        assertEquals(5.0, path.poseAt(1000).y(), 1e-9);
        assertEquals(10.0, path.poseAt(2000).z(), 1e-9);
        assertEquals(0.0, path.poseAt(3000).x(), 1e-9);
        assertEquals(3000, path.durationMillis());
    }

    @Test
    void zeroLengthTravelJumpsStraightToTheWaypoint() {
        CameraPath path = new CameraPath(List.of(
                wp(0, 0, 0, 0, 0, 0, Easing.LINEAR, null, 0),
                wp(7, 0, 0, 0, 0, 0, Easing.LINEAR, null, 0)), false);

        assertEquals(7.0, path.poseAt(0).x(), 1e-9);
    }

    @Test
    void anEmptyPathIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new CameraPath(List.of(), false));
    }
}
