package id.vae.scenes.camera;

import id.vae.scenes.util.Easing;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CameraMathTest {

    @Test
    void orbitKeepsTheRadiusHeightAndFacesTheCenter() {
        Vec3 center = new Vec3(100, 64, -50);
        CameraPath orbit = CameraPaths.orbit(center, 8, 3, 0, 360, 6000, Easing.LINEAR, 24);

        for (int i = 0; i <= 24; i++) {
            CameraPose pose = orbit.poseAt(i * 250L);
            double horizontal = Math.hypot(pose.x() - center.x(), pose.z() - center.z());
            CameraPose facing = CameraPose.lookAt(pose.position(), center);

            assertEquals(8.0, horizontal, 0.01);
            assertEquals(67.0, pose.y(), 1e-9);
            assertEquals(facing.pitch(), pose.pitch(), 0.5);
        }
        assertEquals(6000, orbit.durationMillis(), 30);
    }

    @Test
    void orbitEasingChangesSpeedButNotTheEndpoints() {
        Vec3 center = new Vec3(0, 0, 0);
        CameraPath linear = CameraPaths.orbit(center, 5, 0, 0, 180, 4000, Easing.LINEAR, 24);
        CameraPath eased = CameraPaths.orbit(center, 5, 0, 0, 180, 4000, Easing.EASE_IN, 24);

        assertEquals(linear.poseAt(0).x(), eased.poseAt(0).x(), 1e-9);
        assertEquals(linear.poseAt(10_000).x(), eased.poseAt(10_000).x(), 1e-9);
        double linearProgress = Math.atan2(linear.poseAt(1000).z(), linear.poseAt(1000).x());
        double easedProgress = Math.atan2(eased.poseAt(1000).z(), eased.poseAt(1000).x());
        assertTrue(easedProgress < linearProgress);
    }

    @Test
    void rotateAndFocusEndFacingTheirTarget() {
        CameraPose start = new CameraPose(0, 64, 0, 0, 0);

        CameraPose rotated = CameraPaths.rotate(start, 90, -20, 1000, Easing.LINEAR).poseAt(1000);
        CameraPose focused = CameraPaths.focus(start, new Vec3(10, 64, 0), 1000, Easing.LINEAR).poseAt(1000);

        assertEquals(90.0, rotated.yaw(), 1e-4);
        assertEquals(-20.0, rotated.pitch(), 1e-4);
        assertEquals(-90.0, focused.yaw(), 1e-4);
        assertEquals(0.0, rotated.x(), 1e-9);
    }

    @Test
    void pointToPointMovesBetweenTwoPoses() {
        CameraPath path = CameraPaths.pointToPoint(new CameraPose(0, 0, 0, 0, 0), new CameraPose(0, 20, 0, 0, 0),
                2000, Easing.LINEAR);

        assertEquals(10.0, path.poseAt(1000).y(), 1e-9);
    }

    @Test
    void shakeDecaysAndEndsExactlyAtTheBasePose() {
        CameraShake shake = new CameraShake(2.0, 1000, 12);
        CameraPose base = new CameraPose(10, 64, 10, 30, 5);

        double early = 0;
        double late = 0;
        for (long t = 0; t < 100; t += 5) {
            early = Math.max(early, Math.abs(shake.apply(base, t).yaw() - base.yaw()));
        }
        for (long t = 900; t < 1000; t += 5) {
            late = Math.max(late, Math.abs(shake.apply(base, t).yaw() - base.yaw()));
        }

        assertTrue(early > late);
        assertTrue(early <= 2.0 + 1e-9);
        assertEquals(base, shake.apply(base, 1000));
        assertEquals(base, shake.apply(base, 5000));
    }

    @Test
    void shakeIsDeterministic() {
        CameraShake shake = new CameraShake(1.0, 500, 10);
        CameraPose base = new CameraPose(0, 0, 0, 0, 0);

        assertEquals(shake.apply(base, 123), shake.apply(base, 123));
    }

    @Test
    void followWithoutSmoothingSitsAtTheOffsetAndFacesTheTarget() {
        Vec3[] target = {new Vec3(0, 64, 0)};
        FollowSource follow = new FollowSource(() -> target[0], new Vec3(0, 2, -4), 0, 5000);

        CameraPose pose = follow.poseAt(0);

        assertEquals(0.0, pose.x(), 1e-9);
        assertEquals(66.0, pose.y(), 1e-9);
        assertEquals(-4.0, pose.z(), 1e-9);
        CameraPose facing = CameraPose.lookAt(pose.position(), target[0]);
        assertEquals(facing.yaw(), pose.yaw(), 1e-4);
    }

    @Test
    void followSmoothingLagsBehindAMovingTargetThenCatchesUp() {
        Vec3[] target = {new Vec3(0, 64, 0)};
        FollowSource follow = new FollowSource(() -> target[0], new Vec3(0, 0, 0), 500, 10_000);
        follow.poseAt(0);

        target[0] = new Vec3(10, 64, 0);
        double after100 = follow.poseAt(100).x();
        double after5000 = follow.poseAt(5000).x();

        assertTrue(after100 > 0 && after100 < 5);
        assertEquals(10.0, after5000, 0.01);
    }

    @Test
    void followKeepsTheLastKnownTargetWhenItDisappears() {
        Vec3[] target = {new Vec3(5, 64, 5)};
        FollowSource follow = new FollowSource(() -> target[0], new Vec3(0, 0, 0), 0, 1000);
        follow.poseAt(0);

        target[0] = null;

        assertEquals(5.0, follow.poseAt(50).x(), 1e-9);
    }
}
