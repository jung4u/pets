package id.vae.scenes.database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

/** Key/value settings stored in the database (editable from the web panel). */
public final class SettingsRepository {

    private final DatabaseManager db;

    public SettingsRepository(DatabaseManager db) {
        this.db = db;
    }

    public Optional<String> get(String key) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement("SELECT value FROM settings WHERE key = ?")) {
                ps.setString(1, key);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? Optional.of(rs.getString(1)) : Optional.<String>empty();
                }
            }
        });
    }

    public void set(String key, String value, long nowMillis) throws SQLException {
        db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO settings(key, value, updated_at) VALUES(?, ?, ?) "
                            + "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at")) {
                ps.setString(1, key);
                ps.setString(2, value);
                ps.setLong(3, nowMillis);
                return ps.executeUpdate();
            }
        });
    }

    public boolean delete(String key) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM settings WHERE key = ?")) {
                ps.setString(1, key);
                return ps.executeUpdate() > 0;
            }
        });
    }
}
