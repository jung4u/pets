package id.vae.scenes.config;

public record GeneralSettings(
        boolean debug,
        int maxConcurrentScenes,
        int maxCameraSessions,
        int maxParticlesPerAction) {
}
