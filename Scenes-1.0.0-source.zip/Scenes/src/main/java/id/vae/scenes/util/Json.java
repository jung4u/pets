package id.vae.scenes.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A small, strict JSON reader and writer (RFC 8259) with no dependencies.
 *
 * <p>Parsing gives {@code Map<String,Object>} (insertion ordered), {@code List<Object>}, {@code String},
 * {@code Long} (whole numbers that fit), {@code Double}, {@code Boolean} and null. Nesting deeper than 64 levels
 * is rejected. Writing escapes {@code < > &} and the line separators, so the output is also safe to embed in HTML.
 */
public final class Json {

    private static final int MAX_DEPTH = 64;

    public static final class JsonException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        public JsonException(String message) {
            super(message);
        }
    }

    private Json() {
    }

    // ------------------------------------------------------------------ writing

    public static String stringify(Object value) {
        StringBuilder out = new StringBuilder();
        write(out, value, 0);
        return out.toString();
    }

    private static void write(StringBuilder out, Object value, int depth) {
        if (depth > MAX_DEPTH) {
            throw new JsonException("Value is nested too deeply");
        }
        if (value == null) {
            out.append("null");
        } else if (value instanceof CharSequence text) {
            writeString(out, text.toString());
        } else if (value instanceof Boolean b) {
            out.append(b ? "true" : "false");
        } else if (value instanceof Double || value instanceof Float) {
            double d = ((Number) value).doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d)) {
                out.append("null");
            } else {
                out.append(BigDecimal.valueOf(d).stripTrailingZeros().toPlainString());
            }
        } else if (value instanceof Number n) {
            out.append(n instanceof BigDecimal big ? big.toPlainString() : n.toString());
        } else if (value instanceof Enum<?> e) {
            writeString(out, e.name());
        } else if (value instanceof Map<?, ?> map) {
            out.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                if (!first) {
                    out.append(',');
                }
                first = false;
                writeString(out, String.valueOf(entry.getKey()));
                out.append(':');
                write(out, entry.getValue(), depth + 1);
            }
            out.append('}');
        } else if (value instanceof Collection<?> collection) {
            out.append('[');
            boolean first = true;
            for (Object item : collection) {
                if (!first) {
                    out.append(',');
                }
                first = false;
                write(out, item, depth + 1);
            }
            out.append(']');
        } else if (value instanceof Object[] array) {
            write(out, java.util.Arrays.asList(array), depth);
        } else {
            writeString(out, value.toString());
        }
    }

    private static void writeString(StringBuilder out, String s) {
        out.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                case '\b' -> out.append("\\b");
                case '\f' -> out.append("\\f");
                case '<', '>', '&', '\u2028', '\u2029' -> out.append(String.format("\\u%04x", (int) c));
                default -> {
                    if (c < 0x20) {
                        out.append(String.format("\\u%04x", (int) c));
                    } else {
                        out.append(c);
                    }
                }
            }
        }
        out.append('"');
    }

    // ------------------------------------------------------------------ reading

    /** Parses one JSON value. Throws {@link JsonException} for anything that is not valid JSON. */
    public static Object parse(String text) {
        if (text == null) {
            throw new JsonException("Empty JSON");
        }
        Parser parser = new Parser(text);
        parser.skipWhitespace();
        Object value = parser.value(0);
        parser.skipWhitespace();
        if (!parser.atEnd()) {
            throw parser.error("Unexpected characters after the JSON value");
        }
        return value;
    }

    private static final class Parser {
        private final String s;
        private int i;

        Parser(String s) {
            this.s = s;
        }

        boolean atEnd() {
            return i >= s.length();
        }

        JsonException error(String message) {
            return new JsonException(message + " (at position " + i + ")");
        }

        void skipWhitespace() {
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                    i++;
                } else {
                    break;
                }
            }
        }

        Object value(int depth) {
            if (depth > MAX_DEPTH) {
                throw error("JSON is nested too deeply");
            }
            if (atEnd()) {
                throw error("Unexpected end of JSON");
            }
            char c = s.charAt(i);
            switch (c) {
                case '{':
                    return object(depth);
                case '[':
                    return array(depth);
                case '"':
                    return string();
                case 't':
                    return literal("true", Boolean.TRUE);
                case 'f':
                    return literal("false", Boolean.FALSE);
                case 'n':
                    return literal("null", null);
                default:
                    if (c == '-' || (c >= '0' && c <= '9')) {
                        return number();
                    }
                    throw error("Unexpected character '" + c + "'");
            }
        }

        Object literal(String word, Object result) {
            if (!s.startsWith(word, i)) {
                throw error("Invalid literal");
            }
            i += word.length();
            return result;
        }

        Map<String, Object> object(int depth) {
            Map<String, Object> map = new LinkedHashMap<>();
            i++;
            skipWhitespace();
            if (!atEnd() && s.charAt(i) == '}') {
                i++;
                return map;
            }
            while (true) {
                skipWhitespace();
                if (atEnd() || s.charAt(i) != '"') {
                    throw error("Expected a string key");
                }
                String key = string();
                skipWhitespace();
                if (atEnd() || s.charAt(i) != ':') {
                    throw error("Expected ':'");
                }
                i++;
                skipWhitespace();
                map.put(key, value(depth + 1));
                skipWhitespace();
                if (atEnd()) {
                    throw error("Unterminated object");
                }
                char c = s.charAt(i++);
                if (c == '}') {
                    return map;
                }
                if (c != ',') {
                    i--;
                    throw error("Expected ',' or '}'");
                }
            }
        }

        List<Object> array(int depth) {
            List<Object> list = new ArrayList<>();
            i++;
            skipWhitespace();
            if (!atEnd() && s.charAt(i) == ']') {
                i++;
                return list;
            }
            while (true) {
                skipWhitespace();
                list.add(value(depth + 1));
                skipWhitespace();
                if (atEnd()) {
                    throw error("Unterminated array");
                }
                char c = s.charAt(i++);
                if (c == ']') {
                    return list;
                }
                if (c != ',') {
                    i--;
                    throw error("Expected ',' or ']'");
                }
            }
        }

        String string() {
            i++;
            StringBuilder out = new StringBuilder();
            while (true) {
                if (atEnd()) {
                    throw error("Unterminated string");
                }
                char c = s.charAt(i++);
                if (c == '"') {
                    return out.toString();
                }
                if (c < 0x20) {
                    i--;
                    throw error("Control character in string");
                }
                if (c != '\\') {
                    out.append(c);
                    continue;
                }
                if (atEnd()) {
                    throw error("Unterminated escape");
                }
                char e = s.charAt(i++);
                switch (e) {
                    case '"' -> out.append('"');
                    case '\\' -> out.append('\\');
                    case '/' -> out.append('/');
                    case 'b' -> out.append('\b');
                    case 'f' -> out.append('\f');
                    case 'n' -> out.append('\n');
                    case 'r' -> out.append('\r');
                    case 't' -> out.append('\t');
                    case 'u' -> {
                        if (i + 4 > s.length()) {
                            throw error("Incomplete unicode escape");
                        }
                        try {
                            out.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                        } catch (NumberFormatException ex) {
                            throw error("Invalid unicode escape");
                        }
                        i += 4;
                    }
                    default -> {
                        i--;
                        throw error("Invalid escape");
                    }
                }
            }
        }

        Object number() {
            int start = i;
            if (s.charAt(i) == '-') {
                i++;
            }
            if (atEnd()) {
                throw error("Invalid number");
            }
            if (s.charAt(i) == '0') {
                i++;
            } else if (s.charAt(i) >= '1' && s.charAt(i) <= '9') {
                while (!atEnd() && Character.isDigit(s.charAt(i))) {
                    i++;
                }
            } else {
                throw error("Invalid number");
            }
            boolean integral = true;
            if (!atEnd() && s.charAt(i) == '.') {
                integral = false;
                i++;
                int digits = i;
                while (!atEnd() && Character.isDigit(s.charAt(i))) {
                    i++;
                }
                if (i == digits) {
                    throw error("Invalid number");
                }
            }
            if (!atEnd() && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
                integral = false;
                i++;
                if (!atEnd() && (s.charAt(i) == '+' || s.charAt(i) == '-')) {
                    i++;
                }
                int digits = i;
                while (!atEnd() && Character.isDigit(s.charAt(i))) {
                    i++;
                }
                if (i == digits) {
                    throw error("Invalid number");
                }
            }
            String text = s.substring(start, i);
            if (integral) {
                try {
                    return Long.parseLong(text);
                } catch (NumberFormatException e) {
                    return Double.parseDouble(text);
                }
            }
            return Double.parseDouble(text);
        }
    }
}
