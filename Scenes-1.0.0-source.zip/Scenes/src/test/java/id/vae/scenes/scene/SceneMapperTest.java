package id.vae.scenes.scene;

import id.vae.scenes.util.Easing;
import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SceneMapperTest {

    private static Map<String, Object> sample() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", "intro");
        m.put("name", "Intro");
        m.put("description", "text");
        m.put("enabled", true);
        m.put("priority", 7);
        m.put("cooldown-ms", 1500);
        m.put("duration-ms", 9000);
        m.put("trigger", Map.of("type", "nether_enter", "once-per-player", true, "permission", "p.x", "world", "w",
                "argument", ""));
        m.put("conditions", List.of(Map.of("type", "PERMISSION", "permission", "vip")));
        m.put("actions", List.of(
                Map.of("id", "a", "type", "SOUND_PLAY", "delay-ms", 0, "config", Map.of("key", "a.b")),
                Map.of("id", "b", "type", "DELAY", "delay-ms", 500, "duration-ms", 1000, "easing", "cubic",
                        "enabled", false, "conditions", List.of(Map.of("type", "WORLD", "world", "w")))));
        return m;
    }

    @Test
    void aFullSceneIsParsed() {
        SceneMapper.Parsed parsed = SceneMapper.fromMap(sample());

        assertTrue(parsed.ok());
        SceneDefinition scene = parsed.scene();
        assertEquals("intro", scene.id());
        assertEquals(7, scene.priority());
        assertEquals(1500, scene.cooldownMillis());
        assertEquals(9000, scene.durationMillis());
        assertEquals(TriggerType.NETHER_ENTER, scene.trigger().type());
        assertTrue(scene.trigger().oncePerPlayer());
        assertEquals("p.x", scene.trigger().permission());
        assertEquals("PERMISSION", scene.conditions().get(0).type());
        assertEquals(2, scene.actions().size());
        assertEquals(0, scene.actions().get(0).order());
        assertEquals(1, scene.actions().get(1).order());
        assertEquals(Easing.CUBIC, scene.actions().get(1).easing());
        assertFalse(scene.actions().get(1).enabled());
        assertEquals("a.b", scene.actions().get(0).config().get("key"));
        assertEquals("WORLD", scene.actions().get(1).conditions().get(0).type());
    }

    @Test
    void parsingThenWritingThenParsingGivesTheSameScene() {
        SceneDefinition scene = SceneMapper.fromMap(sample()).scene();

        SceneMapper.Parsed again = SceneMapper.fromMap(SceneMapper.toMap(scene));

        assertTrue(again.ok());
        assertEquals(scene, again.scene());
    }

    @Test
    void problemsAreReportedInsteadOfThrown() {
        Map<String, Object> bad = sample();
        bad.put("trigger", Map.of("type", "MOON_RISE"));
        bad.put("actions", List.of(Map.of("id", "x", "type", "DELAY", "easing", "wobbly"), "not a section"));

        SceneMapper.Parsed parsed = SceneMapper.fromMap(bad);

        assertFalse(parsed.ok());
        String all = String.join(" | ", parsed.errors());
        assertTrue(all.contains("unknown trigger type"));
        assertTrue(all.contains("unknown easing"));
        assertTrue(all.contains("must be a section"));
    }

    @Test
    void anActionsEntryThatIsNotAListIsReported() {
        Map<String, Object> bad = sample();
        bad.put("actions", "oops");

        assertTrue(String.join(" ", SceneMapper.fromMap(bad).errors()).contains("must be a list"));
    }

    @Test
    void missingOptionalPartsGetDefaults() {
        SceneDefinition scene = SceneMapper.fromMap(Map.of("id", "bare", "name", "Bare")).scene();

        assertTrue(scene.enabled());
        assertEquals(TriggerType.MANUAL, scene.trigger().type());
        assertTrue(scene.actions().isEmpty());
        assertEquals(0, scene.priority());
    }
}
