package id.vae.scenes.camera;

import id.vae.scenes.util.Easing;

/**
 * One stop of a camera path.
 *
 * @param world          world name, empty for the player's world
 * @param durationMillis time to travel here from the previous waypoint (ignored for the first one)
 * @param easing         easing of the travel towards this waypoint
 * @param lookAt         when set, the camera faces this point instead of using yaw and pitch
 * @param pauseMillis    how long the camera holds here after arriving
 */
public record Waypoint(String world, Vec3 position, float yaw, float pitch, long durationMillis, Easing easing,
                       Vec3 lookAt, long pauseMillis) {

    public Waypoint {
        world = world == null ? "" : world;
        easing = easing == null ? Easing.LINEAR : easing;
        durationMillis = Math.max(0, durationMillis);
        pauseMillis = Math.max(0, pauseMillis);
    }

    /** A waypoint that keeps a pose, reached instantly. */
    public static Waypoint at(CameraPose pose) {
        return new Waypoint("", pose.position(), pose.yaw(), pose.pitch(), 0, Easing.LINEAR, null, 0);
    }

    public CameraPose resolved() {
        if (lookAt != null) {
            return CameraPose.lookAt(position, lookAt);
        }
        return new CameraPose(position.x(), position.y(), position.z(), yaw, pitch);
    }
}
