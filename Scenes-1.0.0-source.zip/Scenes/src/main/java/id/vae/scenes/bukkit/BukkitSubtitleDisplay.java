package id.vae.scenes.bukkit;

import id.vae.scenes.subtitle.SubtitleDisplay;
import id.vae.scenes.subtitle.SubtitlePosition;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** TOP is the title line, CENTER the subtitle line, BOTTOM the action bar (re-sent while it should stay). */
public final class BukkitSubtitleDisplay implements SubtitleDisplay {

    private static final long ACTION_BAR_NATIVE_MILLIS = 2500;

    private final Plugin plugin;
    private final Map<UUID, BukkitTask> actionBars = new HashMap<>();

    public BukkitSubtitleDisplay(Plugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void show(UUID id, SubtitlePosition position, String miniMessage, long fadeIn, long stay, long fadeOut) {
        Player player = Bukkit.getPlayer(id);
        if (player == null) {
            return;
        }
        Component text = MiniMessage.miniMessage().deserialize(miniMessage);
        switch (position) {
            case TOP -> player.showTitle(Title.title(text, Component.empty(), times(fadeIn, stay, fadeOut)));
            case CENTER -> player.showTitle(Title.title(Component.empty(), text, times(fadeIn, stay, fadeOut)));
            case BOTTOM -> showActionBar(player, text, fadeIn + stay + fadeOut);
        }
    }

    @Override
    public void hide(UUID id, SubtitlePosition position) {
        Player player = Bukkit.getPlayer(id);
        boolean bar = position == null || position == SubtitlePosition.BOTTOM;
        boolean title = position == null || position != SubtitlePosition.BOTTOM;
        if (bar) {
            cancelBar(id);
        }
        if (player == null) {
            return;
        }
        if (title) {
            player.clearTitle();
        }
        if (bar) {
            player.sendActionBar(Component.empty());
        }
    }

    private void showActionBar(Player player, Component text, long totalMillis) {
        UUID id = player.getUniqueId();
        cancelBar(id);
        player.sendActionBar(text);
        if (totalMillis > ACTION_BAR_NATIVE_MILLIS) {
            long[] remainingTicks = {Math.max(1, totalMillis / 50)};
            actionBars.put(id, Bukkit.getScheduler().runTaskTimer(plugin, () -> {
                remainingTicks[0] -= 40;
                Player p = Bukkit.getPlayer(id);
                if (p == null || remainingTicks[0] <= 0) {
                    cancelBar(id);
                    return;
                }
                p.sendActionBar(text);
            }, 40L, 40L));
        }
    }

    private void cancelBar(UUID id) {
        BukkitTask task = actionBars.remove(id);
        if (task != null) {
            task.cancel();
        }
    }

    private static Title.Times times(long in, long stay, long out) {
        return Title.Times.times(Duration.ofMillis(in), Duration.ofMillis(stay), Duration.ofMillis(out));
    }
}
