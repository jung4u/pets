package id.vae.scenes.camera;

import id.vae.scenes.scene.ActionContext;
import id.vae.scenes.scene.ActionDefinition;
import id.vae.scenes.scene.ActionHandler;
import id.vae.scenes.scene.ActionRegistry;
import id.vae.scenes.scene.ActionResult;
import id.vae.scenes.scene.ConfigValues;
import id.vae.scenes.util.Easing;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Camera actions: CAMERA_SPAWN, CAMERA_MOVE, CAMERA_ROTATE, CAMERA_FOCUS, CAMERA_SHAKE, CAMERA_RESTORE.
 *
 * <p>All camera actions start a camera session on demand and register a cleanup that restores the
 * player, so a scene that is cancelled or fails never leaves a camera behind. When no camera backend is
 * usable for the player the actions log once and the scene carries on without the camera.
 *
 * <p>CAMERA_MOVE modes: PATH (waypoints, optional smooth and from-current), ORBIT (center, radius,
 * height, start-angle, end-angle, segments) and FOLLOW (offset, smoothing-ms). Every mode accepts
 * {@code speed} (default 1.0). The action's duration is the length of the movement.
 */
public final class CameraActions {

    private static final String UNSUPPORTED_KEY = "camera.unsupported";

    private CameraActions() {
    }

    public static void registerAll(ActionRegistry registry, CameraControl control) {
        registry.register(new Spawn(control));
        registry.register(new Move(control));
        registry.register(new Rotate(control));
        registry.register(new Focus(control));
        registry.register(new Shake(control));
        registry.register(new Restore(control));
    }

    // ---------------------------------------------------------------- relative coordinates

    /** How coordinates are read: absolute, or offsets from the player's eyes. */
    enum Relative { NONE, WORLD, FACING }

    static Relative relative(Map<String, Object> cfg) {
        Object v = cfg.get("relative");
        if (v == null) {
            return Relative.NONE;
        }
        if (v instanceof Boolean b) {
            return b ? Relative.WORLD : Relative.NONE;
        }
        return switch (String.valueOf(v).trim().toUpperCase(Locale.ROOT)) {
            case "TRUE", "WORLD" -> Relative.WORLD;
            case "FACING" -> Relative.FACING;
            case "FALSE", "NONE" -> Relative.NONE;
            default -> null;
        };
    }

    private static List<String> relativeErrors(Map<String, Object> cfg) {
        return relative(cfg) == null ? List.of("'relative' must be true, false, WORLD or FACING") : List.of();
    }

    /**
     * Converts an offset to a world position. WORLD adds it to the player's eyes along the world axes;
     * FACING reads x as right, y as up and z as forward of where the player looks.
     */
    static Vec3 toWorld(Vec3 offset, CameraPose eye, Relative mode) {
        if (mode == Relative.NONE) {
            return offset;
        }
        double x = offset.x();
        double z = offset.z();
        if (mode == Relative.FACING) {
            double yaw = Math.toRadians(eye.yaw());
            double forwardX = -Math.sin(yaw);
            double forwardZ = Math.cos(yaw);
            double rightX = -Math.cos(yaw);
            double rightZ = -Math.sin(yaw);
            x = offset.x() * rightX + offset.z() * forwardX;
            z = offset.x() * rightZ + offset.z() * forwardZ;
        }
        return new Vec3(eye.x() + x, eye.y() + offset.y(), eye.z() + z);
    }

    private static CameraPose eyeFor(CameraControl control, UUID player, Relative mode) {
        if (mode == Relative.NONE) {
            return null;
        }
        return control.playerEyePose(player)
                .orElseThrow(() -> new IllegalStateException("player is not available for relative coordinates"));
    }

    private static float yawOffset(CameraPose eye, Relative mode) {
        return mode == Relative.FACING ? eye.yaw() : 0f;
    }

    // ---------------------------------------------------------------- parsing helpers

    static boolean hasVec(Map<String, Object> m) {
        return isNumber(m.get("x")) && isNumber(m.get("y")) && isNumber(m.get("z"));
    }

    private static boolean isNumber(Object o) {
        return o instanceof Number;
    }

    static Vec3 vec(Map<String, Object> m) {
        return new Vec3(ConfigValues.doubleValue(m, "x", 0), ConfigValues.doubleValue(m, "y", 0),
                ConfigValues.doubleValue(m, "z", 0));
    }

    private static double speed(Map<String, Object> cfg) {
        double speed = ConfigValues.doubleValue(cfg, "speed", 1.0);
        return speed > 0 ? speed : 1.0;
    }

    private static String mode(Map<String, Object> cfg) {
        return ConfigValues.string(cfg, "mode", "PATH").trim().toUpperCase(Locale.ROOT);
    }

    static List<Waypoint> waypoints(ActionDefinition action) {
        Map<String, Object> cfg = action.config();
        double speed = speed(cfg);
        List<Waypoint> out = new ArrayList<>();
        for (Map<String, Object> m : ConfigValues.mapList(cfg, "waypoints")) {
            Map<String, Object> lookAt = ConfigValues.map(m, "look-at");
            out.add(new Waypoint(
                    ConfigValues.string(m, "world", ""),
                    vec(m),
                    (float) ConfigValues.doubleValue(m, "yaw", 0),
                    (float) ConfigValues.doubleValue(m, "pitch", 0),
                    Math.round(ConfigValues.longValue(m, "duration-ms", 1000) / speed),
                    Easing.parse(ConfigValues.string(m, "easing", ""), action.easing()),
                    hasVec(lookAt) ? vec(lookAt) : null,
                    Math.round(ConfigValues.longValue(m, "pause-ms", 0) / speed)));
        }
        return out;
    }

    // ---------------------------------------------------------------- session helper

    /** Makes sure the camera is running; returns false when the player cannot use a camera. */
    private static boolean ensureSession(CameraControl control, ActionContext ctx, CameraPose startPose) {
        UUID player = ctx.player();
        if (control.isActive(player)) {
            return true;
        }
        if (ctx.variables().containsKey(UNSUPPORTED_KEY)) {
            return false;
        }
        CameraPose start = startPose != null ? startPose : control.playerEyePose(player).orElse(null);
        if (start == null || !control.begin(player, start)) {
            ctx.variables().put(UNSUPPORTED_KEY, Boolean.TRUE);
            ctx.log().warn("Scene '" + ctx.sceneId() + "': camera is not available for this player; "
                    + "camera actions are skipped.");
            return false;
        }
        ctx.addCleanup(() -> control.end(player));
        return true;
    }

    private static CameraPose current(CameraControl control, UUID player) {
        return control.currentPose(player).or(() -> control.playerEyePose(player))
                .orElseThrow(() -> new IllegalStateException("player is not available"));
    }

    private static void checkDistance(CameraControl control, UUID player, Vec3 point, String what) {
        Optional<CameraPose> eye = control.playerEyePose(player);
        if (eye.isPresent() && eye.get().position().distance(point) > control.maxDistance()) {
            throw new IllegalArgumentException(what + " is more than " + (int) control.maxDistance()
                    + " blocks from the player; the client would not have those chunks loaded");
        }
    }

    private static void checkWorld(CameraControl control, UUID player, List<Waypoint> waypoints) {
        String world = control.playerWorld(player).orElse("");
        for (Waypoint w : waypoints) {
            if (!w.world().isEmpty() && !w.world().equalsIgnoreCase(world)) {
                throw new IllegalArgumentException("waypoint is in world '" + w.world()
                        + "' but the camera must stay in the player's world '" + world + "'");
            }
        }
    }

    // ---------------------------------------------------------------- handlers

    static final class Spawn implements ActionHandler {
        private final CameraControl control;

        Spawn(CameraControl control) {
            this.control = control;
        }

        @Override
        public String type() {
            return "CAMERA_SPAWN";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            return relativeErrors(action.config());
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            Map<String, Object> cfg = action.config();
            Map<String, Object> position = ConfigValues.map(cfg, "position");
            CameraPose start = null;
            if (hasVec(position)) {
                Relative mode = relative(cfg);
                CameraPose eye = eyeFor(control, ctx.player(), mode);
                Vec3 at = toWorld(vec(position), eye, mode);
                Map<String, Object> lookAt = ConfigValues.map(cfg, "look-at");
                if (hasVec(lookAt)) {
                    start = CameraPose.lookAt(at, toWorld(vec(lookAt), eye, mode));
                } else {
                    start = new CameraPose(at.x(), at.y(), at.z(),
                            (float) ConfigValues.doubleValue(position, "yaw", 0) + (eye == null ? 0f : yawOffset(eye, mode)),
                            (float) ConfigValues.doubleValue(position, "pitch", 0));
                }
                checkDistance(control, ctx.player(), start.position(), "camera spawn position");
            }
            ensureSession(control, ctx, start);
            return ActionResult.done();
        }
    }

    static final class Move implements ActionHandler {
        private final CameraControl control;

        Move(CameraControl control) {
            this.control = control;
        }

        @Override
        public String type() {
            return "CAMERA_MOVE";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            List<String> errors = new ArrayList<>(relativeErrors(action.config()));
            Map<String, Object> cfg = action.config();
            switch (mode(cfg)) {
                case "PATH" -> {
                    List<Map<String, Object>> raw = ConfigValues.mapList(cfg, "waypoints");
                    if (raw.isEmpty()) {
                        errors.add("CAMERA_MOVE PATH needs at least one waypoint");
                        break;
                    }
                    for (int i = 0; i < raw.size(); i++) {
                        if (!hasVec(raw.get(i))) {
                            errors.add("waypoint " + (i + 1) + " needs numeric x, y and z");
                        }
                        if (ConfigValues.longValue(raw.get(i), "duration-ms", 1000) < 0
                                || ConfigValues.longValue(raw.get(i), "pause-ms", 0) < 0) {
                            errors.add("waypoint " + (i + 1) + " has a negative duration or pause");
                        }
                    }
                    if (errors.isEmpty()) {
                        boolean fromCurrent = ConfigValues.bool(cfg, "from-current", true);
                        List<Waypoint> points = new ArrayList<>(waypoints(action));
                        int given = points.size();
                        if (fromCurrent) {
                            points.add(0, Waypoint.at(new CameraPose(0, 0, 0, 0, 0)));
                        }
                        long pathMillis = new CameraPath(points, false).durationMillis();
                        if (!fromCurrent && given < 2) {
                            errors.add("CAMERA_MOVE PATH without from-current needs at least two waypoints");
                        }
                        if (action.durationMillis() < pathMillis) {
                            errors.add("action duration (" + action.durationMillis()
                                    + " ms) is shorter than the camera path (" + pathMillis + " ms)");
                        }
                    }
                }
                case "ORBIT" -> {
                    if (!hasVec(ConfigValues.map(cfg, "center"))) {
                        errors.add("CAMERA_MOVE ORBIT needs a 'center' with x, y and z");
                    }
                    if (ConfigValues.doubleValue(cfg, "radius", 0) <= 0) {
                        errors.add("CAMERA_MOVE ORBIT needs a 'radius' greater than 0");
                    }
                    if (action.durationMillis() <= 0) {
                        errors.add("CAMERA_MOVE ORBIT needs an action duration greater than 0");
                    }
                }
                case "FOLLOW" -> {
                    if (action.durationMillis() <= 0) {
                        errors.add("CAMERA_MOVE FOLLOW needs an action duration greater than 0");
                    }
                }
                default -> errors.add("CAMERA_MOVE 'mode' must be PATH, ORBIT or FOLLOW");
            }
            return errors;
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            UUID player = ctx.player();
            if (!ensureSession(control, ctx, null)) {
                return ActionResult.done();
            }
            Map<String, Object> cfg = action.config();
            PoseSource source = switch (mode(cfg)) {
                case "ORBIT" -> orbit(player, action);
                case "FOLLOW" -> follow(player, action);
                default -> path(player, action);
            };
            control.play(player, source);
            return ActionResult.done();
        }

        private PoseSource path(UUID player, ActionDefinition action) {
            Map<String, Object> cfg = action.config();
            Relative mode = relative(cfg);
            CameraPose eye = eyeFor(control, player, mode);
            List<Waypoint> points = new ArrayList<>();
            for (Waypoint w : waypoints(action)) {
                points.add(mode == Relative.NONE ? w : new Waypoint(w.world(), toWorld(w.position(), eye, mode),
                        w.yaw() + yawOffset(eye, mode), w.pitch(), w.durationMillis(), w.easing(),
                        w.lookAt() == null ? null : toWorld(w.lookAt(), eye, mode), w.pauseMillis()));
            }
            checkWorld(control, player, points);
            for (Waypoint w : points) {
                checkDistance(control, player, w.position(), "waypoint");
            }
            if (ConfigValues.bool(cfg, "from-current", true)) {
                points.add(0, Waypoint.at(current(control, player)));
            }
            return new CameraPath(points, ConfigValues.bool(cfg, "smooth", false));
        }

        private PoseSource orbit(UUID player, ActionDefinition action) {
            Map<String, Object> cfg = action.config();
            Relative mode = relative(cfg);
            Vec3 center = toWorld(vec(ConfigValues.map(cfg, "center")), eyeFor(control, player, mode), mode);
            double radius = ConfigValues.doubleValue(cfg, "radius", 5);
            checkDistance(control, player, center, "orbit center");
            if (radius > control.maxDistance()) {
                throw new IllegalArgumentException("orbit radius is larger than the maximum camera distance");
            }
            long millis = Math.round(action.durationMillis() / speed(cfg));
            CameraPath orbit = CameraPaths.orbit(center, radius, ConfigValues.doubleValue(cfg, "height", 2),
                    ConfigValues.doubleValue(cfg, "start-angle", 0), ConfigValues.doubleValue(cfg, "end-angle", 360),
                    millis, action.easing(), (int) ConfigValues.longValue(cfg, "segments", 24));
            if (!ConfigValues.bool(cfg, "from-current", false)) {
                return orbit;
            }
            List<Waypoint> points = new ArrayList<>();
            points.add(Waypoint.at(current(control, player)));
            points.addAll(orbit.waypoints());
            return new CameraPath(points, true);
        }

        private PoseSource follow(UUID player, ActionDefinition action) {
            Map<String, Object> cfg = action.config();
            Map<String, Object> offset = ConfigValues.map(cfg, "offset");
            Vec3 delta = hasVec(offset) ? vec(offset) : new Vec3(3, 2, 3);
            return new FollowSource(
                    () -> control.playerEyePose(player).map(CameraPose::position).orElse(null),
                    delta, ConfigValues.doubleValue(cfg, "smoothing-ms", 300), action.durationMillis());
        }
    }

    static final class Rotate implements ActionHandler {
        private final CameraControl control;

        Rotate(CameraControl control) {
            this.control = control;
        }

        @Override
        public String type() {
            return "CAMERA_ROTATE";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            Map<String, Object> cfg = action.config();
            List<String> errors = new ArrayList<>(relativeErrors(cfg));
            if (!cfg.containsKey("yaw") && !cfg.containsKey("pitch")) {
                errors.add("CAMERA_ROTATE needs 'yaw' and/or 'pitch'");
            }
            return errors;
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            if (!ensureSession(control, ctx, null)) {
                return ActionResult.done();
            }
            CameraPose from = current(control, ctx.player());
            Map<String, Object> cfg = action.config();
            Relative mode = relative(cfg);
            float yawBase = cfg.containsKey("yaw") && mode == Relative.FACING
                    ? yawOffset(eyeFor(control, ctx.player(), mode), mode) : 0f;
            float yaw = (float) ConfigValues.doubleValue(cfg, "yaw", from.yaw()) + yawBase;
            float pitch = (float) ConfigValues.doubleValue(cfg, "pitch", from.pitch());
            long millis = Math.round(action.durationMillis() / speed(cfg));
            control.play(ctx.player(), CameraPaths.rotate(from, yaw, pitch, millis, action.easing()));
            return ActionResult.done();
        }
    }

    static final class Focus implements ActionHandler {
        private final CameraControl control;

        Focus(CameraControl control) {
            this.control = control;
        }

        @Override
        public String type() {
            return "CAMERA_FOCUS";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            List<String> errors = new ArrayList<>(relativeErrors(action.config()));
            if (!hasVec(ConfigValues.map(action.config(), "look-at"))) {
                errors.add("CAMERA_FOCUS needs 'look-at' with x, y and z");
            }
            return errors;
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            if (!ensureSession(control, ctx, null)) {
                return ActionResult.done();
            }
            Relative mode = relative(action.config());
            Vec3 target = toWorld(vec(ConfigValues.map(action.config(), "look-at")),
                    eyeFor(control, ctx.player(), mode), mode);
            long millis = Math.round(action.durationMillis() / speed(action.config()));
            control.play(ctx.player(),
                    CameraPaths.focus(current(control, ctx.player()), target, millis, action.easing()));
            return ActionResult.done();
        }
    }

    static final class Shake implements ActionHandler {
        private final CameraControl control;

        Shake(CameraControl control) {
            this.control = control;
        }

        @Override
        public String type() {
            return "CAMERA_SHAKE";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            List<String> errors = new ArrayList<>();
            if (action.durationMillis() <= 0) {
                errors.add("CAMERA_SHAKE needs an action duration greater than 0");
            }
            if (ConfigValues.doubleValue(action.config(), "intensity", 1.0) <= 0) {
                errors.add("CAMERA_SHAKE 'intensity' must be greater than 0");
            }
            return errors;
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            if (!ensureSession(control, ctx, null)) {
                return ActionResult.done();
            }
            control.shake(ctx.player(), new CameraShake(
                    ConfigValues.doubleValue(action.config(), "intensity", 1.0), action.durationMillis(),
                    ConfigValues.doubleValue(action.config(), "frequency", 12.0)));
            return ActionResult.done();
        }
    }

    static final class Restore implements ActionHandler {
        private final CameraControl control;

        Restore(CameraControl control) {
            this.control = control;
        }

        @Override
        public String type() {
            return "CAMERA_RESTORE";
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            control.end(ctx.player());
            return ActionResult.done();
        }
    }
}
