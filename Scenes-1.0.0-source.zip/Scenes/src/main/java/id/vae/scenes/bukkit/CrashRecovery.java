package id.vae.scenes.bukkit;

import id.vae.scenes.util.ScenesLogger;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;

import java.util.Optional;
import java.util.UUID;

/**
 * If the server stopped in the middle of a scene that had put a player in spectator mode, the saved game
 * mode, flight state and location are put back as soon as the player joins again.
 */
public final class CrashRecovery implements Listener {

    private final Plugin plugin;
    private final RestoreStore store;
    private final CameraManager camera;
    private final ScenesLogger log;

    public CrashRecovery(Plugin plugin, RestoreStore store, CameraManager camera, ScenesLogger log) {
        this.plugin = plugin;
        this.store = store;
        this.camera = camera;
        this.log = log;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        if (store.load(id).isEmpty()) {
            return;
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> restore(id), 5L);
    }

    private void restore(UUID id) {
        Player player = Bukkit.getPlayer(id);
        Optional<RestoreStore.Saved> saved = store.load(id);
        if (player == null || saved.isEmpty() || camera.isActive(id)) {
            return;
        }
        RestoreStore.Saved s = saved.get();
        try {
            player.setSpectatorTarget(null);
            player.setGameMode(GameMode.valueOf(s.gameMode()));
            World world = Bukkit.getWorld(s.world());
            if (world != null) {
                player.teleport(new Location(world, s.x(), s.y(), s.z(), s.yaw(), s.pitch()));
            }
            player.setAllowFlight(s.allowFlight());
            if (s.flying() && s.allowFlight()) {
                player.setFlying(true);
            }
            log.info("Restored " + player.getName() + " after a scene that was interrupted.");
        } catch (IllegalArgumentException e) {
            log.error("Could not restore " + player.getName() + " (saved game mode " + s.gameMode() + ")", e);
        } finally {
            store.delete(id);
        }
    }
}
