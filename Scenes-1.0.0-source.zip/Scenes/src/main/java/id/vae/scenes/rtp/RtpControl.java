package id.vae.scenes.rtp;

import java.util.UUID;

/** The random-teleport hook as seen by scene actions. */
public interface RtpControl {

    enum Status { NONE, PENDING, EXECUTING, SUCCEEDED, FAILED }

    Status status(UUID player);

    /** Runs the teleport command the hook held back for this player. Returns false when there is none. */
    boolean execute(UUID player);

    /** Forgets the request. Call when the scene run ends. */
    void finish(UUID player);

    /** How long a teleport may take before it counts as failed. */
    long timeoutMillis();
}
