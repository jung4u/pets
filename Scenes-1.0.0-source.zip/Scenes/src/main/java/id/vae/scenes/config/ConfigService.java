package id.vae.scenes.config;

import id.vae.scenes.core.Service;
import id.vae.scenes.util.ScenesLogger;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Loads and validates the plugin configuration files. Reloading validates
 * everything first and only swaps the active settings when all files are
 * valid. Admin-edited files are never overwritten or deleted.
 */
public final class ConfigService implements Service {

    /** Opens a bundled default resource; returns null when it does not exist. */
    @FunctionalInterface
    public interface ResourceLoader {
        InputStream open(String name) throws IOException;
    }

    public record ReloadResult(boolean ok, List<String> errors) {
    }

    private record Snapshot(
            GeneralSettings general,
            DatabaseSettings database,
            CameraSettings camera,
            HookSettings hooks) {
    }

    private static final List<String> FILES = List.of("config.yml", "database.yml");

    private final Path dataFolder;
    private final ResourceLoader resources;
    private final ScenesLogger log;
    private volatile Snapshot snapshot;

    public ConfigService(Path dataFolder, ResourceLoader resources, ScenesLogger log) {
        this.dataFolder = dataFolder;
        this.resources = resources;
        this.log = log;
    }

    @Override
    public String name() {
        return "config";
    }

    @Override
    public void start() throws Exception {
        Files.createDirectories(dataFolder);
        ReloadResult result = reload();
        if (!result.ok()) {
            throw new IllegalStateException("Invalid configuration: " + String.join("; ", result.errors()));
        }
        log.info("Configuration loaded.");
    }

    @Override
    public void stop() {
        // Nothing to release.
    }

    public GeneralSettings general() {
        return current().general();
    }

    public DatabaseSettings database() {
        return current().database();
    }

    public CameraSettings camera() {
        return current().camera();
    }

    public HookSettings hooks() {
        return current().hooks();
    }

    /** Validates all files; on success swaps the active settings, on failure keeps the old ones. */
    public synchronized ReloadResult reload() {
        List<String> errors = new ArrayList<>();

        YamlConfiguration general = load("config.yml", errors);
        YamlConfiguration database = load("database.yml", errors);

        if (general != null && database != null) {
            GeneralSettings g = parseGeneral(general, errors);
            DatabaseSettings d = parseDatabase(database, errors);
            CameraSettings cam = parseCamera(general, errors);
            HookSettings hooks = parseHooks(general, errors);
            if (errors.isEmpty()) {
                snapshot = new Snapshot(g, d, cam, hooks);
                return new ReloadResult(true, List.of());
            }
        }

        for (String error : errors) {
            log.warn("Config error: " + error);
        }
        return new ReloadResult(false, List.copyOf(errors));
    }

    private Snapshot current() {
        Snapshot s = snapshot;
        if (s == null) {
            throw new IllegalStateException("Configuration has not been loaded");
        }
        return s;
    }

    private YamlConfiguration load(String name, List<String> errors) {
        Path path = dataFolder.resolve(name);
        try {
            if (Files.notExists(path)) {
                copyDefault(name, path);
            }
            YamlConfiguration yaml = new YamlConfiguration();
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                yaml.load(reader);
            }
            return yaml;
        } catch (IOException | InvalidConfigurationException e) {
            errors.add(name + ": " + e.getMessage());
            return null;
        }
    }

    private void copyDefault(String name, Path target) throws IOException {
        if (!FILES.contains(name)) {
            throw new IOException("Unknown config file: " + name);
        }
        Files.createDirectories(target.getParent());
        try (InputStream in = resources.open(name)) {
            if (in == null) {
                throw new IOException("Missing bundled resource: " + name);
            }
            Files.copy(in, target);
        }
    }

    private static GeneralSettings parseGeneral(YamlConfiguration c, List<String> errors) {
        String f = "config.yml";
        return new GeneralSettings(
                readBool(c, f, "debug", false, errors),
                readInt(c, f, "limits.max-concurrent-scenes", 10, 1, 1000, errors),
                readInt(c, f, "limits.max-camera-sessions", 10, 1, 1000, errors),
                readInt(c, f, "limits.max-particles-per-action", 200, 1, 5000, errors));
    }

    private static HookSettings parseHooks(YamlConfiguration c, List<String> errors) {
        String f = "config.yml";
        List<String> commands = new ArrayList<>();
        if (c.contains("rtp.commands")) {
            for (String raw : c.getStringList("rtp.commands")) {
                String command = raw.trim().toLowerCase(Locale.ROOT);
                if (command.startsWith("/")) {
                    command = command.substring(1);
                }
                if (command.matches("[a-z0-9_:.-]+")) {
                    commands.add(command);
                } else {
                    errors.add(f + ": 'rtp.commands' contains an invalid command '" + raw + "'");
                }
            }
        } else {
            commands.addAll(List.of("rtp", "wild", "randomtp"));
        }
        return new HookSettings(
                readBool(c, f, "integrations.authme", true, errors),
                readInt(c, f, "join.spawn-delay-ticks", 40, 0, 1200, errors),
                readBool(c, f, "rtp.enabled", true, errors),
                List.copyOf(commands),
                readInt(c, f, "rtp.timeout-ms", 15_000, 1000, 120_000, errors),
                readInt(c, f, "rtp.min-distance", 16, 1, 100_000, errors));
    }

    private static CameraSettings parseCamera(YamlConfiguration c, List<String> errors) {
        String f = "config.yml";
        String backend = c.getString("camera.backend", "AUTO").trim().toUpperCase(Locale.ROOT);
        if (!Set.of("AUTO", "PROTOCOLLIB", "SPECTATOR", "NONE").contains(backend)) {
            errors.add(f + ": 'camera.backend' must be AUTO, PROTOCOLLIB, SPECTATOR or NONE");
            backend = "AUTO";
        }
        String bedrock = c.getString("camera.bedrock-backend", "NONE").trim().toUpperCase(Locale.ROOT);
        if (!Set.of("SPECTATOR", "NONE").contains(bedrock)) {
            errors.add(f + ": 'camera.bedrock-backend' must be SPECTATOR or NONE");
            bedrock = "NONE";
        }
        return new CameraSettings(backend, bedrock,
                readDouble(c, f, "camera.max-distance", 96, 1, 1024, errors),
                readDouble(c, f, "camera.eye-height", 0, -2, 4, errors));
    }

    private static DatabaseSettings parseDatabase(YamlConfiguration c, List<String> errors) {
        String f = "database.yml";
        String file = c.getString("file", "data/scenes.db").trim();
        boolean validPath;
        try {
            Path p = Path.of(file);
            validPath = !file.isEmpty() && !p.isAbsolute() && !p.normalize().startsWith("..");
        } catch (InvalidPathException e) {
            validPath = false;
        }
        if (!validPath) {
            errors.add(f + ": 'file' must be a relative path inside the plugin folder");
            file = "data/scenes.db";
        }
        return new DatabaseSettings(
                file,
                readBool(c, f, "backup.enabled", true, errors),
                readBool(c, f, "backup.on-startup", true, errors),
                readInt(c, f, "backup.interval-minutes", 360, 1, 525_600, errors),
                readInt(c, f, "backup.keep", 10, 1, 1000, errors));
    }

    private static int readInt(YamlConfiguration c, String file, String path, int def, int min, int max,
                               List<String> errors) {
        if (c.contains(path) && !c.isInt(path)) {
            errors.add(file + ": '" + path + "' must be a whole number");
            return def;
        }
        int value = c.getInt(path, def);
        if (value < min || value > max) {
            errors.add(file + ": '" + path + "' must be between " + min + " and " + max + " (was " + value + ")");
            return def;
        }
        return value;
    }

    private static double readDouble(YamlConfiguration c, String file, String path, double def, double min,
                                     double max, List<String> errors) {
        if (c.contains(path) && !c.isInt(path) && !c.isDouble(path)) {
            errors.add(file + ": '" + path + "' must be a number");
            return def;
        }
        double value = c.getDouble(path, def);
        if (value < min || value > max) {
            errors.add(file + ": '" + path + "' must be between " + min + " and " + max + " (was " + value + ")");
            return def;
        }
        return value;
    }

    private static boolean readBool(YamlConfiguration c, String file, String path, boolean def,
                                    List<String> errors) {
        if (c.contains(path) && !c.isBoolean(path)) {
            errors.add(file + ": '" + path + "' must be true or false");
            return def;
        }
        return c.getBoolean(path, def);
    }
}
