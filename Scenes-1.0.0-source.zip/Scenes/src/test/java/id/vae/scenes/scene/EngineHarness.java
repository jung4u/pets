package id.vae.scenes.scene;

import id.vae.scenes.core.ServiceRegistry;
import id.vae.scenes.scene.TestSupport.FakePlayers;
import id.vae.scenes.scene.TestSupport.ManualScheduler;
import id.vae.scenes.scene.TestSupport.MapCatalog;
import id.vae.scenes.scene.TestSupport.Marker;
import id.vae.scenes.scene.TestSupport.MemoryProgress;
import id.vae.scenes.util.ScenesLogger;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

/** A ready-made engine with fakes, so module tests only register their own actions. */
public final class EngineHarness {

    public final ManualScheduler clock = new ManualScheduler();
    public final FakePlayers players = new FakePlayers();
    public final MapCatalog catalog = new MapCatalog();
    public final ActionRegistry registry = new ActionRegistry();
    public final List<String> events = new ArrayList<>();
    public final ScenesLogger log = new ScenesLogger(Logger.getLogger("test"), false);
    public final SceneValidator validator;
    public final SceneEngine engine;
    public final UUID alice;

    public EngineHarness() {
        ControlActions.registerAll(registry);
        registry.register(new Marker(events, clock));
        ConditionEvaluator conditions = new ConditionEvaluator(players);
        validator = new SceneValidator(registry, conditions);
        engine = new SceneEngine(catalog, registry, clock, players, new MemoryProgress(), new ServiceRegistry(log),
                conditions, () -> 10, log);
        alice = players.join("world");
    }

    public SceneEngine.StartResult run(SceneDefinition scene) {
        catalog.add(scene);
        return engine.start(alice, scene.id(), false);
    }

    /** Validation problems of a single action, joined into one string. */
    public String errors(ActionDefinition action) {
        return String.join(" | ", validator.validate(TestSupport.scene("check", 0, action)));
    }
}
