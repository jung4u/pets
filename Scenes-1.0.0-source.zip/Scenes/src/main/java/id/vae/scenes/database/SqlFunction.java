package id.vae.scenes.database;

import java.sql.SQLException;

@FunctionalInterface
public interface SqlFunction<T, R> {
    R apply(T input) throws SQLException;
}
