package id.vae.scenes.camera;

import id.vae.scenes.core.ServiceRegistry;
import id.vae.scenes.scene.ActionRegistry;
import id.vae.scenes.scene.ConditionEvaluator;
import id.vae.scenes.scene.ControlActions;
import id.vae.scenes.scene.PlayerActions;
import id.vae.scenes.scene.PlayerLocks;
import id.vae.scenes.scene.SceneDefinition;
import id.vae.scenes.scene.SceneEngine;
import id.vae.scenes.scene.SceneValidator;
import id.vae.scenes.scene.TestSupport.FakePlayers;
import id.vae.scenes.scene.TestSupport.ManualScheduler;
import id.vae.scenes.scene.TestSupport.MapCatalog;
import id.vae.scenes.scene.TestSupport.Marker;
import id.vae.scenes.scene.TestSupport.MemoryProgress;
import id.vae.scenes.util.ScenesLogger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;

import static id.vae.scenes.scene.TestSupport.action;
import static id.vae.scenes.scene.TestSupport.mark;
import static id.vae.scenes.scene.TestSupport.scene;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CameraActionsTest {

    private static final class FakeControl implements CameraControl {
        boolean supported = true;
        double maxDistance = 96;
        final Set<UUID> active = new HashSet<>();
        final Map<UUID, CameraPose> pose = new HashMap<>();
        final Map<UUID, PoseSource> source = new HashMap<>();
        final List<String> calls = new ArrayList<>();
        CameraPose eye = new CameraPose(0, 65.6, 0, 0, 0);

        @Override
        public boolean begin(UUID player, CameraPose start) {
            calls.add("begin");
            if (!supported) {
                return false;
            }
            active.add(player);
            pose.put(player, start);
            return true;
        }

        @Override
        public boolean isActive(UUID player) {
            return active.contains(player);
        }

        @Override
        public Optional<CameraPose> currentPose(UUID player) {
            return Optional.ofNullable(pose.get(player));
        }

        @Override
        public void play(UUID player, PoseSource s) {
            calls.add("play");
            source.put(player, s);
        }

        @Override
        public void shake(UUID player, CameraShake shake) {
            calls.add("shake");
        }

        @Override
        public void end(UUID player) {
            if (active.remove(player)) {
                calls.add("end");
            }
        }

        @Override
        public Optional<CameraPose> playerEyePose(UUID player) {
            return Optional.of(eye);
        }

        @Override
        public Optional<String> playerWorld(UUID player) {
            return Optional.of("world");
        }

        @Override
        public double maxDistance() {
            return maxDistance;
        }
    }

    private static final class FakeLocks implements PlayerLocks {
        int locked;
        int unlocked;

        @Override
        public void lock(UUID player) {
            locked++;
        }

        @Override
        public void unlock(UUID player) {
            unlocked++;
        }
    }

    private final ScenesLogger log = new ScenesLogger(Logger.getLogger("test"), false);
    private ManualScheduler clock;
    private FakePlayers players;
    private MapCatalog catalog;
    private FakeControl control;
    private FakeLocks locks;
    private List<String> events;
    private SceneEngine engine;
    private SceneValidator validator;
    private UUID alice;

    @BeforeEach
    void setUp() {
        clock = new ManualScheduler();
        players = new FakePlayers();
        catalog = new MapCatalog();
        control = new FakeControl();
        locks = new FakeLocks();
        events = new ArrayList<>();
        ActionRegistry registry = new ActionRegistry();
        ControlActions.registerAll(registry);
        CameraActions.registerAll(registry, control);
        PlayerActions.registerAll(registry, locks);
        registry.register(new Marker(events, clock));
        ConditionEvaluator conditions = new ConditionEvaluator(players);
        validator = new SceneValidator(registry, conditions);
        engine = new SceneEngine(catalog, registry, clock, players, new MemoryProgress(), new ServiceRegistry(log),
                conditions, () -> 10, log);
        alice = players.join("world");
    }

    private static Map<String, Object> point(double x, double y, double z, long durationMs) {
        return Map.of("x", x, "y", y, "z", z, "duration-ms", durationMs);
    }

    private static Map<String, Object> pathConfig(List<Map<String, Object>> waypoints) {
        return Map.of("waypoints", waypoints);
    }

    @Test
    void cameraMoveStartsASessionPlaysThePathAndRestoresWhenTheSceneEnds() {
        catalog.add(scene("intro", 0,
                action("move", "CAMERA_MOVE", 0, 2000, pathConfig(List.of(point(10, 70, 10, 2000))))));

        assertEquals(SceneEngine.StartResult.STARTED, engine.start(alice, "intro", false));

        assertEquals(List.of("begin", "play"), control.calls);
        PoseSource source = control.source.get(alice);
        assertEquals(2000, source.durationMillis());
        assertEquals(0.0, source.poseAt(0).x(), 1e-9);
        assertEquals(10.0, source.poseAt(2000).x(), 1e-9);

        clock.advance(2000);
        assertEquals(List.of("begin", "play", "end"), control.calls);
        assertFalse(control.isActive(alice));
    }

    @Test
    void cancellingTheSceneRestoresTheCamera() {
        catalog.add(scene("intro", 0,
                action("move", "CAMERA_MOVE", 0, 5000, pathConfig(List.of(point(10, 70, 10, 5000))))));

        engine.start(alice, "intro", false);
        engine.stop(alice, "test");

        assertFalse(control.isActive(alice));
        assertTrue(control.calls.contains("end"));
    }

    @Test
    void playerQuitDuringACameraShotCleansUp() {
        catalog.add(scene("intro", 0,
                action("move", "CAMERA_MOVE", 0, 5000, pathConfig(List.of(point(10, 70, 10, 5000))))));

        engine.start(alice, "intro", false);
        engine.onPlayerQuit(alice);

        assertFalse(control.isActive(alice));
    }

    @Test
    void sceneContinuesWithoutTheCameraWhenNoBackendIsAvailable() {
        control.supported = false;
        catalog.add(scene("intro", 0,
                action("move", "CAMERA_MOVE", 0, 1000, pathConfig(List.of(point(10, 70, 10, 1000)))),
                action("shake", "CAMERA_SHAKE", 100, 500, Map.of()),
                mark("after", 200)));

        engine.start(alice, "intro", false);
        clock.advance(1000);

        assertEquals(List.of("after@200"), events);
        assertEquals(List.of("begin"), control.calls);
    }

    @Test
    void waypointsBeyondTheMaximumDistanceAreRejectedAtRunTime() {
        catalog.add(scene("intro", 0,
                action("far", "CAMERA_MOVE", 0, 1000, pathConfig(List.of(point(500, 70, 0, 1000)))),
                mark("after", 100)));

        engine.start(alice, "intro", false);
        clock.advance(1000);

        assertFalse(control.calls.contains("play"));
        assertEquals(List.of("after@100"), events);
        assertFalse(control.isActive(alice));
    }

    @Test
    void waypointsInAnotherWorldAreRejected() {
        Map<String, Object> other = Map.of("x", 1, "y", 70, "z", 1, "world", "world_nether", "duration-ms", 500);
        catalog.add(scene("intro", 0, action("move", "CAMERA_MOVE", 0, 500, pathConfig(List.of(other)))));

        engine.start(alice, "intro", false);

        assertFalse(control.calls.contains("play"));
    }

    @Test
    void orbitFollowRotateFocusAndShakeAllDriveTheCamera() {
        Map<String, Object> center = Map.of("x", 0, "y", 64, "z", 0);
        catalog.add(scene("intro", 0,
                action("orbit", "CAMERA_MOVE", 0, 2000, Map.of("mode", "ORBIT", "center", center, "radius", 6)),
                action("rotate", "CAMERA_ROTATE", 100, 500, Map.of("yaw", 90)),
                action("focus", "CAMERA_FOCUS", 200, 500, Map.of("look-at", center)),
                action("shake", "CAMERA_SHAKE", 300, 500, Map.of("intensity", 2.0)),
                action("follow", "CAMERA_MOVE", 400, 1000, Map.of("mode", "FOLLOW")),
                action("restore", "CAMERA_RESTORE", 1500, 0, Map.of())));

        engine.start(alice, "intro", false);
        clock.advance(2000);

        assertEquals(List.of("begin", "play", "play", "play", "shake", "play", "end"), control.calls);
    }

    @Test
    void validationReportsBadCameraSettings() {
        assertTrue(errors(action("a", "CAMERA_MOVE", 0, 1000, Map.of())).contains("at least one waypoint"));
        assertTrue(errors(action("a", "CAMERA_MOVE", 0, 500, pathConfig(List.of(point(1, 2, 3, 2000)))))
                .contains("shorter than the camera path"));
        assertTrue(errors(action("a", "CAMERA_MOVE", 0, 1000, pathConfig(List.of(Map.of("x", 1)))))
                .contains("numeric x, y and z"));
        assertTrue(errors(action("a", "CAMERA_MOVE", 0, 1000, Map.of("mode", "ORBIT"))).contains("center"));
        assertTrue(errors(action("a", "CAMERA_MOVE", 0, 0, Map.of("mode", "FOLLOW"))).contains("duration"));
        assertTrue(errors(action("a", "CAMERA_MOVE", 0, 1000, Map.of("mode", "SPIN"))).contains("mode"));
        assertTrue(errors(action("a", "CAMERA_ROTATE", 0, 500, Map.of())).contains("yaw"));
        assertTrue(errors(action("a", "CAMERA_FOCUS", 0, 500, Map.of())).contains("look-at"));
        assertTrue(errors(action("a", "CAMERA_SHAKE", 0, 0, Map.of())).contains("duration"));
        assertEquals("", errors(action("a", "CAMERA_MOVE", 0, 2000, pathConfig(List.of(point(1, 2, 3, 2000))))));
        assertEquals("", errors(action("a", "CAMERA_RESTORE", 0, 0, Map.of())));
    }

    @Test
    void speedShortensTheWaypointDurations() {
        Map<String, Object> config = Map.of("waypoints", List.of(point(10, 65, 0, 2000)), "speed", 2.0);
        catalog.add(scene("intro", 0, action("move", "CAMERA_MOVE", 0, 1000, config)));

        assertEquals("", errors(action("move", "CAMERA_MOVE", 0, 1000, config)));
        engine.start(alice, "intro", false);

        assertEquals(1000, control.source.get(alice).durationMillis());
    }

    @Test
    void playerLocksAreReleasedExactlyOnce() {
        catalog.add(scene("a", 0, action("lock", "PLAYER_LOCK", 0, 0, Map.of()), mark("x", 5000)));
        catalog.add(scene("b", 0, action("lock", "PLAYER_LOCK", 0, 0, Map.of()),
                action("lock2", "PLAYER_LOCK", 10, 0, Map.of()),
                action("unlock", "PLAYER_UNLOCK", 100, 0, Map.of())));

        engine.start(alice, "a", false);
        assertEquals(1, locks.locked);
        engine.stop(alice, "test");
        assertEquals(1, locks.unlocked);

        engine.start(alice, "b", false);
        clock.advance(200);
        assertEquals(2, locks.locked);
        assertEquals(2, locks.unlocked);
    }

    private String errors(id.vae.scenes.scene.ActionDefinition action) {
        SceneDefinition scene = scene("check", 0, action);
        return String.join(" | ", validator.validate(scene));
    }
}
