package id.vae.scenes.config;

public record DatabaseSettings(
        String file,
        boolean backupEnabled,
        boolean backupOnStartup,
        int backupIntervalMinutes,
        int backupKeep) {
}
