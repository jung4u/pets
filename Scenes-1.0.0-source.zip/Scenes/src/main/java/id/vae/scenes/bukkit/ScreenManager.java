package id.vae.scenes.bukkit;

import id.vae.scenes.core.Service;
import id.vae.scenes.screen.ScreenChannel;
import id.vae.scenes.screen.ScreenControl;
import id.vae.scenes.screen.ScreenFrame;
import id.vae.scenes.screen.ScreenPlan;
import id.vae.scenes.util.ScenesLogger;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.WorldBorder;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Renders screen effects with vanilla features only, so no resource pack is needed:
 * <ul>
 *   <li>black: the Blindness effect. When the screen opens again the effect is replaced by a 1 second one,
 *       which vanilla fades out smoothly.</li>
 *   <li>darkness: the Darkness effect.</li>
 *   <li>blur: a light Nausea wobble. This is a simulation, not a blur shader.</li>
 *   <li>vignette: a per-player world border warning, which tints the screen edges red. This is a
 *       simulation; a black vignette needs a resource pack.</li>
 *   <li>flash: a flash particle at the player's eyes.</li>
 * </ul>
 * Effects on different channels run together (for example eyes opening while the screen is blurred); a new
 * effect replaces the running one on its own channel. The tick task runs only while an effect is active, and
 * potion effects the player already had are restored.
 */
public final class ScreenManager implements Service, ScreenControl, Listener {

    private static final double BORDER_WARNING_BLOCKS = 100;
    private static final int BLACK_TICKS = 40;
    private static final int BLACK_REFRESH_BELOW = 25;
    private static final int FADE_OUT_TICKS = 20;

    private record Saved(PotionEffect effect, long takenAt) {
    }

    private static final class Running {
        final ScreenPlan plan;
        final long start;
        boolean finished;
        ScreenFrame resting = ScreenFrame.ZERO;

        Running(ScreenPlan plan, long start) {
            this.plan = plan;
            this.start = start;
        }
    }

    private static final class Session {
        final Map<ScreenChannel, Running> running = new EnumMap<>(ScreenChannel.class);
        final Map<PotionEffectType, Saved> saved = new HashMap<>();
        String flashColor = "";
        boolean blackActive;
        boolean flashing;
        WorldBorder border;
    }

    private final Plugin plugin;
    private final ScenesLogger log;
    private final Map<UUID, Session> sessions = new HashMap<>();
    private BukkitTask ticker;

    public ScreenManager(Plugin plugin, ScenesLogger log) {
        this.plugin = plugin;
        this.log = log;
    }

    @Override
    public String name() {
        return "screen";
    }

    @Override
    public void start() {
        // The ticker starts when the first effect plays.
    }

    @Override
    public void stop() {
        for (UUID id : new ArrayList<>(sessions.keySet())) {
            clear(id);
        }
        cancelTicker();
    }

    @Override
    public void play(UUID id, ScreenPlan plan) {
        Player player = Bukkit.getPlayer(id);
        if (player == null || !player.isOnline()) {
            return;
        }
        Session session = sessions.computeIfAbsent(id, k -> new Session());
        long now = System.currentTimeMillis();
        session.running.put(plan.channel(), new Running(plan, now));
        if (plan.channel() == ScreenChannel.FLASH) {
            session.flashColor = plan.flashColor();
        }
        render(player, session, merged(session, now));
        if (ticker == null) {
            ticker = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
        }
    }

    @Override
    public void clear(UUID id) {
        Session session = sessions.remove(id);
        Player player = Bukkit.getPlayer(id);
        if (session != null && player != null) {
            release(player, session, true);
        }
        if (sessions.isEmpty()) {
            cancelTicker();
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        clear(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        clear(event.getEntity().getUniqueId());
    }

    private void tick() {
        long now = System.currentTimeMillis();
        for (UUID id : new ArrayList<>(sessions.keySet())) {
            Session session = sessions.get(id);
            Player player = Bukkit.getPlayer(id);
            if (session == null) {
                continue;
            }
            if (player == null || !player.isOnline()) {
                sessions.remove(id);
                continue;
            }
            try {
                ScreenFrame frame = merged(session, now);
                render(player, session, frame);
                session.running.values().removeIf(r -> r.finished && r.resting.isZero());
                if (session.running.isEmpty()) {
                    sessions.remove(id);
                    release(player, session, false);
                }
            } catch (RuntimeException e) {
                log.error("Screen effect failed for " + player.getName() + "; clearing it", e);
                clear(id);
            }
        }
        if (sessions.isEmpty()) {
            cancelTicker();
        }
    }

    /** The strongest value of every channel across the running effects. */
    private ScreenFrame merged(Session session, long now) {
        ScreenFrame frame = ScreenFrame.ZERO;
        for (Iterator<Running> it = session.running.values().iterator(); it.hasNext(); ) {
            Running r = it.next();
            ScreenFrame f;
            if (r.finished) {
                f = r.resting;
            } else {
                long elapsed = now - r.start;
                f = r.plan.frameAt(elapsed);
                if (elapsed >= r.plan.durationMillis()) {
                    r.finished = true;
                    r.resting = r.plan.finalFrame();
                    f = r.resting;
                }
            }
            frame = ScreenFrame.max(frame, f);
        }
        return frame;
    }

    private void render(Player player, Session s, ScreenFrame frame) {
        // Black screen
        if (frame.black() >= 0.5) {
            refresh(player, s, PotionEffectType.BLINDNESS, BLACK_TICKS, BLACK_REFRESH_BELOW);
            s.blackActive = true;
        } else if (s.blackActive) {
            s.blackActive = false;
            player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, FADE_OUT_TICKS, 0, false, false, false));
        }
        // Darkness and blur
        toggle(player, s, PotionEffectType.DARKNESS, frame.darkness() > 0.05, 60, 30);
        toggle(player, s, PotionEffectType.NAUSEA, frame.blur() > 0.05, 80, 40);
        // Vignette
        if (frame.vignette() > 0.02) {
            if (s.border == null) {
                s.border = Bukkit.createWorldBorder();
                s.border.setWarningTime(0);
                s.border.setWarningDistance((int) BORDER_WARNING_BLOCKS);
                s.border.setDamageAmount(0);
                s.border.setDamageBuffer(0);
            }
            Location at = player.getLocation();
            s.border.setCenter(at.getX(), at.getZ());
            s.border.setSize(Math.max(1, BORDER_WARNING_BLOCKS * (1 - Math.min(1, frame.vignette()))) * 2);
            player.setWorldBorder(s.border);
        } else if (s.border != null) {
            player.setWorldBorder(null);
            s.border = null;
        }
        // Flash
        if (frame.flash() >= 0.5 && !s.flashing) {
            s.flashing = true;
            flash(player, s.flashColor);
        } else if (frame.flash() < 0.5) {
            s.flashing = false;
        }
    }

    private void toggle(Player player, Session s, PotionEffectType type, boolean on, int ticks, int refreshBelow) {
        if (on) {
            refresh(player, s, type, ticks, refreshBelow);
        } else if (s.saved.containsKey(type)) {
            restore(player, s, type);
        }
    }

    private void refresh(Player player, Session s, PotionEffectType type, int ticks, int refreshBelow) {
        PotionEffect current = player.getPotionEffect(type);
        s.saved.putIfAbsent(type, new Saved(current, System.currentTimeMillis()));
        if (current == null || current.getDuration() < refreshBelow) {
            player.addPotionEffect(new PotionEffect(type, ticks, 0, false, false, false));
        }
    }

    /** Removes our effect and gives back the one the player had before, with its remaining time. */
    private void restore(Player player, Session s, PotionEffectType type) {
        Saved saved = s.saved.remove(type);
        player.removePotionEffect(type);
        if (saved == null || saved.effect() == null) {
            return;
        }
        PotionEffect before = saved.effect();
        int remaining = before.getDuration() < 0 ? before.getDuration()
                : before.getDuration() - (int) ((System.currentTimeMillis() - saved.takenAt()) / 50);
        if (remaining > 0 || before.getDuration() < 0) {
            player.addPotionEffect(new PotionEffect(type, remaining, before.getAmplifier(), before.isAmbient(),
                    before.hasParticles(), before.hasIcon()));
        }
    }

    /** Takes every effect off the player. When the screen is opening normally the fade-out blindness is left to expire. */
    private void release(Player player, Session s, boolean immediate) {
        for (PotionEffectType type : new ArrayList<>(s.saved.keySet())) {
            if (!immediate && type == PotionEffectType.BLINDNESS) {
                s.saved.remove(type);
                continue;
            }
            restore(player, s, type);
        }
        if (s.border != null) {
            player.setWorldBorder(null);
            s.border = null;
        }
    }

    private void flash(Player player, String hexColor) {
        Location eyes = player.getEyeLocation();
        Color color = hexColor == null || hexColor.isBlank() ? Color.WHITE
                : Color.fromRGB(Integer.parseInt(hexColor.replace("#", ""), 16));
        try {
            player.spawnParticle(Particle.FLASH, eyes, 1, 0, 0, 0, 0, color);
        } catch (IllegalArgumentException e) {
            player.spawnParticle(Particle.FLASH, eyes, 1);
        }
    }

    private void cancelTicker() {
        if (ticker != null) {
            ticker.cancel();
            ticker = null;
        }
    }
}
