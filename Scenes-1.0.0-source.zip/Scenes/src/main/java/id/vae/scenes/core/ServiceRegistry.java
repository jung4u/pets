package id.vae.scenes.core;

import id.vae.scenes.util.ScenesLogger;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Registers services by type, starts them in registration order and stops
 * them in reverse order. A failed start rolls back services already started.
 */
public final class ServiceRegistry {

    private final ScenesLogger log;
    private final Map<Class<?>, Service> services = new LinkedHashMap<>();
    private final Deque<Service> started = new ArrayDeque<>();
    private boolean running;

    public ServiceRegistry(ScenesLogger log) {
        this.log = log;
    }

    public synchronized <T extends Service> T register(Class<T> type, T service) {
        if (running) {
            throw new IllegalStateException("Cannot register services while running");
        }
        if (services.containsKey(type)) {
            throw new IllegalStateException("Service already registered: " + type.getName());
        }
        services.put(type, service);
        return service;
    }

    public synchronized <T extends Service> T get(Class<T> type) {
        Service service = services.get(type);
        if (service == null) {
            throw new IllegalStateException("Service not registered: " + type.getName());
        }
        return type.cast(service);
    }

    public synchronized void startAll() throws ServiceStartException {
        for (Service service : services.values()) {
            try {
                service.start();
                started.push(service);
                log.debug("Service started: " + service.name());
            } catch (Exception e) {
                log.error("Service '" + service.name() + "' failed to start", e);
                stopStarted();
                throw new ServiceStartException(service.name(), e);
            }
        }
        running = true;
    }

    public synchronized void stopAll() {
        stopStarted();
        running = false;
    }

    public synchronized boolean isRunning() {
        return running;
    }

    private void stopStarted() {
        while (!started.isEmpty()) {
            Service service = started.pop();
            try {
                service.stop();
                log.debug("Service stopped: " + service.name());
            } catch (RuntimeException e) {
                log.error("Service '" + service.name() + "' failed to stop cleanly", e);
            }
        }
    }
}
