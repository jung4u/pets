package id.vae.scenes.screen;

import id.vae.scenes.camera.CameraActions;
import id.vae.scenes.camera.CameraControl;
import id.vae.scenes.scene.ActionContext;
import id.vae.scenes.scene.ActionDefinition;
import id.vae.scenes.scene.ActionHandler;
import id.vae.scenes.scene.ActionHandlers;
import id.vae.scenes.scene.ActionRegistry;
import id.vae.scenes.scene.ActionResult;
import id.vae.scenes.scene.ConfigValues;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * Screen actions: SCREEN_FADE (direction IN|OUT), SCREEN_BLINK (count 1-3), SCREEN_BLACKOUT, SCREEN_EYE
 * (state CLOSE|OPEN), SCREEN_FLASH, SCREEN_BLUR, SCREEN_VIGNETTE, SCREEN_DARKNESS, SCREEN_CLEAR and
 * SCREEN_SHAKE (camera shake).
 *
 * <p>Settings: intensity (0-1, default 1), speed (default 1, divides the duration), repeat (1-20),
 * repeat-delay-ms, hold (keep the last look until SCREEN_CLEAR or the next effect), color (flash only).
 * The action duration is the effect length. Vignette and blur are simulations, not shaders.
 */
public final class ScreenActions {

    private static final String CLEANUP_KEY = "screen.cleanup";

    private ScreenActions() {
    }

    public static void registerAll(ActionRegistry registry, ScreenControl screen, CameraControl camera) {
        registry.register(plan("SCREEN_FADE", screen, a -> "IN".equalsIgnoreCase(ConfigValues.string(
                a.config(), "direction", "OUT")) ? ScreenEffectType.FADE_IN : ScreenEffectType.FADE_OUT,
                a -> oneOf(a, "direction", "IN", "OUT")));
        registry.register(plan("SCREEN_BLINK", screen, a -> switch ((int) ConfigValues.longValue(a.config(), "count", 1)) {
            case 2 -> ScreenEffectType.DOUBLE_BLINK;
            case 3 -> ScreenEffectType.TRIPLE_BLINK;
            default -> ScreenEffectType.BLINK;
        }, a -> {
            long count = ConfigValues.longValue(a.config(), "count", 1);
            return count >= 1 && count <= 3 ? List.of() : List.of("'count' must be 1, 2 or 3");
        }));
        registry.register(plan("SCREEN_BLACKOUT", screen, a -> ScreenEffectType.BLACK_SCREEN, a -> List.of()));
        registry.register(plan("SCREEN_EYE", screen, a -> "OPEN".equalsIgnoreCase(ConfigValues.string(
                a.config(), "state", "CLOSE")) ? ScreenEffectType.EYE_OPEN : ScreenEffectType.EYE_CLOSE,
                a -> oneOf(a, "state", "CLOSE", "OPEN")));
        registry.register(plan("SCREEN_FLASH", screen, a -> ScreenEffectType.FLASH, a -> List.of()));
        registry.register(plan("SCREEN_BLUR", screen, a -> ScreenEffectType.BLUR, a -> List.of()));
        registry.register(plan("SCREEN_VIGNETTE", screen, a -> ScreenEffectType.VIGNETTE, a -> List.of()));
        registry.register(plan("SCREEN_DARKNESS", screen, a -> ScreenEffectType.DARKNESS, a -> List.of()));
        registry.register(new Clear(screen));
        registry.register(ActionHandlers.alias("SCREEN_SHAKE", cameraShake(camera)));
    }

    private static ActionHandler cameraShake(CameraControl camera) {
        ActionRegistry scratch = new ActionRegistry();
        CameraActions.registerAll(scratch, camera);
        return scratch.get("CAMERA_SHAKE").orElseThrow();
    }

    private static List<String> oneOf(ActionDefinition action, String key, String... allowed) {
        if (!action.config().containsKey(key)) {
            return List.of();
        }
        String value = ConfigValues.string(action.config(), key, "");
        for (String option : allowed) {
            if (option.equalsIgnoreCase(value)) {
                return List.of();
            }
        }
        return List.of("'" + key + "' must be one of " + String.join(", ", allowed));
    }

    private static ActionHandler plan(String type, ScreenControl screen,
                                      Function<ActionDefinition, ScreenEffectType> resolver,
                                      Function<ActionDefinition, List<String>> extraValidation) {
        return new ActionHandler() {
            @Override
            public String type() {
                return type;
            }

            @Override
            public List<String> validate(ActionDefinition action) {
                List<String> errors = new ArrayList<>(extraValidation.apply(action));
                Map<String, Object> cfg = action.config();
                if (!type.equals("SCREEN_FLASH") && action.durationMillis() <= 0) {
                    errors.add(type + " needs an action duration greater than 0");
                }
                double intensity = ConfigValues.doubleValue(cfg, "intensity", 1.0);
                if (intensity <= 0 || intensity > 1) {
                    errors.add("'intensity' must be greater than 0 and at most 1");
                }
                if (ConfigValues.doubleValue(cfg, "speed", 1.0) <= 0) {
                    errors.add("'speed' must be greater than 0");
                }
                long repeat = ConfigValues.longValue(cfg, "repeat", 1);
                if (repeat < 1 || repeat > 20) {
                    errors.add("'repeat' must be between 1 and 20");
                }
                if (ConfigValues.longValue(cfg, "repeat-delay-ms", 0) < 0) {
                    errors.add("'repeat-delay-ms' must not be negative");
                }
                String color = ConfigValues.string(cfg, "color", "");
                if (!color.isEmpty() && !ActionHandlers.validHex(color)) {
                    errors.add("'color' must be a hex colour like #ffffff");
                }
                return errors;
            }

            @Override
            public ActionResult execute(ActionContext ctx, ActionDefinition action) {
                Map<String, Object> cfg = action.config();
                ScreenEffectType effect = resolver.apply(action);
                double speed = ConfigValues.doubleValue(cfg, "speed", 1.0);
                long duration = Math.round(action.durationMillis() / (speed > 0 ? speed : 1.0));
                ScreenPlan plan = ScreenPlans.create(effect, duration,
                        ConfigValues.doubleValue(cfg, "intensity", 1.0), action.easing(),
                        (int) ConfigValues.longValue(cfg, "repeat", 1),
                        ConfigValues.longValue(cfg, "repeat-delay-ms", 0),
                        ConfigValues.bool(cfg, "hold", ScreenPlans.holdsByDefault(effect)));
                String color = ConfigValues.string(cfg, "color", "");
                if (effect == ScreenEffectType.FLASH && ActionHandlers.validHex(color)) {
                    plan = plan.withFlashColor(ActionHandlers.normalizeHex(color));
                }
                var player = ctx.player();
                ActionHandlers.cleanupOnce(ctx, CLEANUP_KEY, () -> screen.clear(player));
                screen.play(player, plan);
                return ActionResult.done();
            }
        };
    }

    private static final class Clear implements ActionHandler {
        private final ScreenControl screen;

        Clear(ScreenControl screen) {
            this.screen = screen;
        }

        @Override
        public String type() {
            return "SCREEN_CLEAR";
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            screen.clear(ctx.player());
            return ActionResult.done();
        }
    }
}
