package id.vae.scenes.bukkit;

import id.vae.scenes.util.ScenesLogger;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Fallback: temporarily puts the player in spectator mode, spectating the camera entity. The game
 * mode, flight state and exact location are saved first (in memory and on disk, so a crash cannot leave
 * the player stuck in spectator) and restored when the camera ends. Movement is locked by the game itself
 * while spectating.
 */
final class SpectatorBackend implements CameraBackend {

    private record Saved(GameMode mode, boolean allowFlight, boolean flying, Location location) {
    }

    private final Map<UUID, Saved> saved = new HashMap<>();
    private final RestoreStore store;
    private final ScenesLogger log;

    SpectatorBackend(RestoreStore store, ScenesLogger log) {
        this.store = store;
        this.log = log;
    }

    @Override
    public String name() {
        return "spectator";
    }

    @Override
    public void attach(Player player, Entity camera) {
        Saved state = new Saved(player.getGameMode(), player.getAllowFlight(), player.isFlying(), player.getLocation());
        saved.put(player.getUniqueId(), state);
        try {
            Location at = state.location();
            store.save(player.getUniqueId(), new RestoreStore.Saved(state.mode().name(), state.allowFlight(),
                    state.flying(), at.getWorld() == null ? "" : at.getWorld().getName(), at.getX(), at.getY(),
                    at.getZ(), at.getYaw(), at.getPitch()));
        } catch (IOException e) {
            log.warn("Could not write the restore file for " + player.getName() + ": " + e.getMessage());
        }
        player.setGameMode(GameMode.SPECTATOR);
        player.setSpectatorTarget(camera);
    }

    @Override
    public void detach(Player player, Entity camera) {
        Saved state = saved.remove(player.getUniqueId());
        if (state == null) {
            return;
        }
        player.setSpectatorTarget(null);
        player.setGameMode(state.mode());
        player.teleport(state.location());
        player.setAllowFlight(state.allowFlight());
        if (state.flying() && state.allowFlight()) {
            player.setFlying(true);
        }
        store.delete(player.getUniqueId());
    }
}
