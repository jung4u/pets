package id.vae.scenes.trigger;

import id.vae.scenes.scene.TriggerType;

import java.util.UUID;

/**
 * Something that happened to a player.
 *
 * @param world    world the player is in
 * @param argument command or custom event name, empty for other triggers
 */
public record TriggerEvent(TriggerType type, UUID player, String world, String argument) {

    public TriggerEvent {
        world = world == null ? "" : world;
        argument = argument == null ? "" : argument;
    }

    public static TriggerEvent of(TriggerType type, UUID player, String world) {
        return new TriggerEvent(type, player, world, "");
    }
}
