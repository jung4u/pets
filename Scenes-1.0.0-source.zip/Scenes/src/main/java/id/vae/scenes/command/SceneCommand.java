package id.vae.scenes.command;

import id.vae.scenes.ScenesPlugin;
import id.vae.scenes.bukkit.SceneSeeder;
import id.vae.scenes.config.ConfigService;
import id.vae.scenes.database.DatabaseManager;
import id.vae.scenes.scene.SceneDefinition;
import id.vae.scenes.scene.SceneEngine;
import id.vae.scenes.scene.SceneManager;
import id.vae.scenes.scene.SceneResult;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * /scenes reload|enable|disable|delete|import|export and /scene start|stop|stopall|list|reset.
 * Tab completion returns nothing to senders without permission, so regular players never see admin arguments.
 */
public final class SceneCommand implements TabExecutor {

    private static final List<String> SCENES_SUBCOMMANDS =
            List.of("reload", "enable", "disable", "delete", "import", "export");
    private static final List<String> SCENE_SUBCOMMANDS = List.of("start", "stop", "stopall", "list", "reset");

    private final ScenesPlugin plugin;

    public SceneCommand(ScenesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("scenes")) {
            return handleScenes(sender, args);
        }
        return handleScene(sender, args);
    }

    // ------------------------------------------------------------------ /scenes

    private boolean handleScenes(CommandSender sender, String[] args) {
        if (args.length == 0) {
            send(sender, "Usage: /scenes <reload|enable|disable|delete|import|export>", NamedTextColor.YELLOW);
            return true;
        }
        SceneManager scenes = plugin.services().get(SceneManager.class);
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                if (!sender.hasPermission("scenes.reload")) {
                    return deny(sender);
                }
                reload(sender);
            }
            case "enable", "disable" -> {
                if (!sender.hasPermission("scenes.manage")) {
                    return deny(sender);
                }
                if (args.length != 2) {
                    send(sender, "Usage: /scenes " + args[0].toLowerCase(Locale.ROOT) + " <scene>", NamedTextColor.YELLOW);
                    return true;
                }
                boolean enable = args[0].equalsIgnoreCase("enable");
                SceneResult result = scenes.find(args[1]).isEmpty()
                        ? SceneResult.failure("unknown scene '" + args[1] + "'")
                        : scenes.setEnabled(args[1], enable);
                report(sender, result, "Scene " + args[1] + (enable ? " enabled." : " disabled."));
            }
            case "delete" -> {
                if (!sender.hasPermission("scenes.manage")) {
                    return deny(sender);
                }
                if (args.length != 3 || !args[2].equalsIgnoreCase("confirm")) {
                    send(sender, "Usage: /scenes delete <scene> confirm   (this cannot be undone; "
                            + "export the scene first if you want a copy)", NamedTextColor.YELLOW);
                    return true;
                }
                SceneResult result = scenes.find(args[1]).isEmpty()
                        ? SceneResult.failure("unknown scene '" + args[1] + "'")
                        : scenes.delete(args[1]);
                report(sender, result, "Scene " + args[1] + " deleted.");
            }
            case "import" -> {
                if (!sender.hasPermission("scenes.manage")) {
                    return deny(sender);
                }
                if (args.length < 2 || args.length > 3 || (args.length == 3 && !args[2].equalsIgnoreCase("replace"))) {
                    send(sender, "Usage: /scenes import <file> [replace]   (file in plugins/Scenes/scenes, "
                            + "without .yml)", NamedTextColor.YELLOW);
                    return true;
                }
                List<String> problems = plugin.services().get(SceneSeeder.class)
                        .importFile(args[1], args.length == 3);
                if (problems.isEmpty()) {
                    send(sender, "Imported " + args[1] + ".yml.", NamedTextColor.GREEN);
                } else {
                    send(sender, "Nothing was changed:", NamedTextColor.RED);
                    problems.forEach(p -> send(sender, " - " + p, NamedTextColor.RED));
                }
            }
            case "export" -> {
                if (!sender.hasPermission("scenes.manage")) {
                    return deny(sender);
                }
                if (args.length < 2 || args.length > 3 || (args.length == 3 && !args[2].equalsIgnoreCase("overwrite"))) {
                    send(sender, "Usage: /scenes export <scene> [overwrite]", NamedTextColor.YELLOW);
                    return true;
                }
                String error = plugin.services().get(SceneSeeder.class).exportScene(args[1], args.length == 3);
                if (error == null) {
                    send(sender, "Saved plugins/Scenes/scenes/" + args[1] + ".yml. Edit it, then run /scenes import "
                            + args[1] + " replace.", NamedTextColor.GREEN);
                } else {
                    send(sender, "Not exported: " + error, NamedTextColor.RED);
                }
            }
            default -> send(sender, "Usage: /scenes <reload|enable|disable|delete|import|export>", NamedTextColor.YELLOW);
        }
        return true;
    }

    private void reload(CommandSender sender) {
        ConfigService.ReloadResult result = plugin.reloadConfiguration();
        if (!result.ok()) {
            send(sender, "Configuration is invalid; the previous settings are still active:", NamedTextColor.RED);
            result.errors().forEach(e -> send(sender, " - " + e, NamedTextColor.RED));
            return;
        }
        try {
            List<String> problems = new ArrayList<>(plugin.services().get(SceneManager.class).reload());
            SceneSeeder.Result imported = plugin.services().get(SceneSeeder.class).importNew();
            problems.addAll(imported.problems());
            send(sender, "Scenes reloaded" + (imported.imported() > 0 ? " (" + imported.imported()
                    + " new scene file(s) imported)" : "") + ".", NamedTextColor.GREEN);
            problems.forEach(p -> send(sender, " - " + p, NamedTextColor.RED));
        } catch (SQLException e) {
            send(sender, "Could not reload scenes: " + e.getMessage(), NamedTextColor.RED);
        }
    }

    // ------------------------------------------------------------------ /scene

    private boolean handleScene(CommandSender sender, String[] args) {
        if (args.length == 0) {
            send(sender, "Usage: /scene <start|stop|stopall|list|reset>", NamedTextColor.YELLOW);
            return true;
        }
        SceneEngine engine = plugin.services().get(SceneEngine.class);
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "start" -> {
                if (!sender.hasPermission("scenes.play")) {
                    return deny(sender);
                }
                if (args.length != 3) {
                    send(sender, "Usage: /scene start <player> <scene>", NamedTextColor.YELLOW);
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    send(sender, "Player not found: " + args[1], NamedTextColor.RED);
                    return true;
                }
                SceneEngine.StartResult result = engine.start(target.getUniqueId(), args[2], true);
                send(sender, result == SceneEngine.StartResult.STARTED
                                ? "Started scene " + args[2] + " for " + target.getName() + "."
                                : "Could not start scene: " + result.name().toLowerCase(Locale.ROOT).replace('_', ' '),
                        result == SceneEngine.StartResult.STARTED ? NamedTextColor.GREEN : NamedTextColor.RED);
            }
            case "stop" -> {
                if (!sender.hasPermission("scenes.stop")) {
                    return deny(sender);
                }
                if (args.length != 2) {
                    send(sender, "Usage: /scene stop <player>", NamedTextColor.YELLOW);
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                boolean stopped = target != null && engine.stop(target.getUniqueId(), "stopped by command");
                send(sender, stopped ? "Scene stopped." : "No scene is running for that player.",
                        stopped ? NamedTextColor.GREEN : NamedTextColor.RED);
            }
            case "stopall" -> {
                if (!sender.hasPermission("scenes.stop")) {
                    return deny(sender);
                }
                send(sender, "Stopped " + engine.stopAll("stopped by command") + " scene(s).", NamedTextColor.GREEN);
            }
            case "list" -> {
                if (!sender.hasPermission("scenes.play")) {
                    return deny(sender);
                }
                List<SceneDefinition> scenes = new ArrayList<>(plugin.services().get(SceneManager.class).all());
                send(sender, "Scenes (" + scenes.size() + "):", NamedTextColor.GOLD);
                for (SceneDefinition scene : scenes) {
                    send(sender, " - " + scene.id() + "  [" + scene.trigger().type().name().toLowerCase(Locale.ROOT)
                                    + (scene.enabled() ? "" : ", disabled") + "]",
                            scene.enabled() ? NamedTextColor.WHITE : NamedTextColor.GRAY);
                }
            }
            case "reset" -> {
                if (!sender.hasPermission("scenes.manage")) {
                    return deny(sender);
                }
                resetProgress(sender, args);
            }
            default -> send(sender, "Usage: /scene <start|stop|stopall|list|reset>", NamedTextColor.YELLOW);
        }
        return true;
    }

    private void resetProgress(CommandSender sender, String[] args) {
        if (args.length < 2 || args.length > 3) {
            send(sender, "Usage: /scene reset <player|uuid> [scene]   (without a scene: everything)",
                    NamedTextColor.YELLOW);
            return;
        }
        UUID target = resolve(args[1]);
        if (target == null) {
            send(sender, "Unknown player. Use the name of an online player, or a UUID.", NamedTextColor.RED);
            return;
        }
        String sceneId = args.length == 3 ? args[2] : null;
        DatabaseManager db = plugin.services().get(DatabaseManager.class);
        db.async(c -> sceneId == null
                ? plugin.progressRepository().resetPlayer(target)
                : plugin.progressRepository().resetScene(target, sceneId))
                .whenComplete((removed, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
                    plugin.progressTracker().invalidate(target);
                    if (error != null) {
                        send(sender, "Could not reset progress: " + error.getMessage(), NamedTextColor.RED);
                    } else {
                        send(sender, "Reset " + removed + " progress entr" + (removed == 1 ? "y" : "ies")
                                + (sceneId == null ? "" : " for scene " + sceneId) + ".", NamedTextColor.GREEN);
                    }
                }));
    }

    private static UUID resolve(String text) {
        Player online = Bukkit.getPlayerExact(text);
        if (online != null) {
            return online.getUniqueId();
        }
        try {
            return UUID.fromString(text);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ tab completion

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("scenes")) {
            return completeScenes(sender, args);
        }
        if (!sender.hasPermission("scenes.play") && !sender.hasPermission("scenes.stop")
                && !sender.hasPermission("scenes.manage")) {
            return List.of();
        }
        if (args.length == 1) {
            return filter(SCENE_SUBCOMMANDS, args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2 && (sub.equals("start") || sub.equals("stop") || sub.equals("reset"))) {
            return filter(onlineNames(), args[1]);
        }
        if (args.length == 3 && (sub.equals("start") || sub.equals("reset"))) {
            return filter(sceneIds(), args[2]);
        }
        return List.of();
    }

    private List<String> completeScenes(CommandSender sender, String[] args) {
        if (!sender.hasPermission("scenes.reload") && !sender.hasPermission("scenes.manage")) {
            return List.of();
        }
        if (args.length == 1) {
            return filter(SCENES_SUBCOMMANDS, args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2) {
            return switch (sub) {
                case "enable", "disable", "delete", "export" -> filter(sceneIds(), args[1]);
                case "import" -> filter(plugin.services().get(SceneSeeder.class).fileNames(), args[1]);
                default -> List.of();
            };
        }
        if (args.length == 3) {
            return switch (sub) {
                case "delete" -> filter(List.of("confirm"), args[2]);
                case "import" -> filter(List.of("replace"), args[2]);
                case "export" -> filter(List.of("overwrite"), args[2]);
                default -> List.of();
            };
        }
        return List.of();
    }

    private List<String> onlineNames() {
        List<String> names = new ArrayList<>();
        Bukkit.getOnlinePlayers().forEach(p -> names.add(p.getName()));
        return names;
    }

    private List<String> sceneIds() {
        List<String> ids = new ArrayList<>();
        plugin.services().get(SceneManager.class).all().forEach(s -> ids.add(s.id()));
        return ids;
    }

    private static List<String> filter(List<String> options, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return options.stream().filter(o -> o.toLowerCase(Locale.ROOT).startsWith(lower)).toList();
    }

    // ------------------------------------------------------------------ output

    private static void report(CommandSender sender, SceneResult result, String success) {
        if (result.ok()) {
            send(sender, success, NamedTextColor.GREEN);
        } else {
            send(sender, "Nothing was changed:", NamedTextColor.RED);
            result.errors().forEach(e -> send(sender, " - " + e, NamedTextColor.RED));
        }
    }

    private static boolean deny(CommandSender sender) {
        send(sender, "You do not have permission to do that.", NamedTextColor.RED);
        return true;
    }

    private static void send(CommandSender sender, String message, NamedTextColor color) {
        sender.sendMessage(Component.text(message, color));
    }
}
