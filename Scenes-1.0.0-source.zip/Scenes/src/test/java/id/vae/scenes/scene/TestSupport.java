package id.vae.scenes.scene;

import id.vae.scenes.util.Easing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/** Fakes and builders shared by the scene tests. */
public final class TestSupport {

    private TestSupport() {
    }

    /** A scheduler with a virtual clock that only moves when the test advances it. */
    public static final class ManualScheduler implements SceneScheduler {
        private record Entry(long time, long seq, Runnable runnable, boolean[] cancelled) {
        }

        private final List<Entry> queue = new ArrayList<>();
        private long now;
        private long seq;

        @Override
        public long nowMillis() {
            return now;
        }

        @Override
        public Task runLater(long delayMillis, Runnable runnable) {
            boolean[] cancelled = new boolean[1];
            queue.add(new Entry(now + Math.max(0, delayMillis), seq++, runnable, cancelled));
            return () -> cancelled[0] = true;
        }

        /** Moves time forward, running everything that becomes due in order. */
        public void advance(long millis) {
            long target = now + millis;
            while (true) {
                Entry next = null;
                for (Entry e : queue) {
                    if (e.time() <= target && (next == null || e.time() < next.time()
                            || (e.time() == next.time() && e.seq() < next.seq()))) {
                        next = e;
                    }
                }
                if (next == null) {
                    break;
                }
                queue.remove(next);
                if (!next.cancelled()[0]) {
                    now = Math.max(now, next.time());
                    next.runnable().run();
                }
            }
            now = target;
        }
    }

    public static final class FakePlayers implements PlayerGateway {
        public final Set<UUID> online = new HashSet<>();
        public final Map<UUID, Set<String>> permissions = new HashMap<>();
        public final Map<UUID, String> worlds = new HashMap<>();

        public UUID join(String world) {
            UUID id = UUID.randomUUID();
            online.add(id);
            worlds.put(id, world);
            return id;
        }

        public void grant(UUID id, String permission) {
            permissions.computeIfAbsent(id, k -> new HashSet<>()).add(permission);
        }

        @Override
        public boolean isOnline(UUID player) {
            return online.contains(player);
        }

        @Override
        public boolean hasPermission(UUID player, String permission) {
            return permissions.getOrDefault(player, Set.of()).contains(permission);
        }

        @Override
        public String worldOf(UUID player) {
            return worlds.get(player);
        }

        @Override
        public String nameOf(UUID player) {
            return online.contains(player) ? "Player" : null;
        }
    }

    public static final class MapCatalog implements SceneCatalog {
        private final Map<String, SceneDefinition> scenes = new LinkedHashMap<>();

        public MapCatalog add(SceneDefinition scene) {
            scenes.put(scene.id(), scene);
            return this;
        }

        @Override
        public Optional<SceneDefinition> find(String id) {
            return Optional.ofNullable(scenes.get(id));
        }

        @Override
        public List<SceneDefinition> all() {
            return new ArrayList<>(scenes.values());
        }
    }

    public static final class MemoryProgress implements ProgressTracker {
        public final Set<String> completed = new HashSet<>();

        @Override
        public boolean hasCompleted(UUID player, String sceneId) {
            return completed.contains(player + ":" + sceneId);
        }

        @Override
        public void recordCompleted(UUID player, String sceneId) {
            completed.add(player + ":" + sceneId);
        }
    }

    /** Records "id@time" for every run; config fail=true throws, cleanup=true registers a cleanup. */
    public static final class Marker implements ActionHandler {
        private final List<String> events;
        private final SceneScheduler scheduler;

        public Marker(List<String> events, SceneScheduler scheduler) {
            this.events = events;
            this.scheduler = scheduler;
        }

        @Override
        public String type() {
            return "MARK";
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            if (ConfigValues.bool(action.config(), "fail", false)) {
                throw new IllegalStateException("boom");
            }
            events.add(action.id() + "@" + scheduler.nowMillis());
            if (ConfigValues.bool(action.config(), "cleanup", false)) {
                ctx.addCleanup(() -> events.add("cleanup:" + action.id()));
            }
            return ActionResult.done();
        }
    }

    public static ActionDefinition action(String id, String type, long delay, long duration,
                                          Map<String, Object> config) {
        return new ActionDefinition(id, type, 0, delay, duration, Easing.LINEAR, true, List.of(), config);
    }

    public static ActionDefinition mark(String id, long delay) {
        return action(id, "MARK", delay, 0, Map.of());
    }

    public static SceneDefinition scene(String id, int priority, ActionDefinition... actions) {
        List<ActionDefinition> ordered = new ArrayList<>();
        for (int i = 0; i < actions.length; i++) {
            ordered.add(actions[i].withOrder(i));
        }
        return new SceneDefinition(id, id, "", true, TriggerSpec.manual(), priority, 0, 0, List.of(), ordered);
    }
}
