package id.vae.scenes.scene;

import id.vae.scenes.core.Service;
import id.vae.scenes.core.ServiceRegistry;
import id.vae.scenes.util.ScenesLogger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.IntSupplier;

/**
 * Starts, tracks and stops scene runs. One scene runs per player; a higher-priority scene
 * preempts a lower one. All methods must be called from the server main thread.
 */
public final class SceneEngine implements Service {

    public enum StartResult {
        STARTED,
        UNKNOWN_SCENE,
        DISABLED,
        PLAYER_OFFLINE,
        ALREADY_RUNNING,
        LIMIT_REACHED,
        COOLDOWN,
        ALREADY_PLAYED,
        CONDITIONS_FAILED
    }

    private final SceneCatalog catalog;
    private final ActionRegistry actions;
    private final SceneScheduler scheduler;
    private final PlayerGateway players;
    private final ProgressTracker progress;
    private final ServiceRegistry services;
    private final ConditionEvaluator conditions;
    private final IntSupplier maxConcurrent;
    private final ScenesLogger log;

    private final Map<UUID, SceneRun> running = new HashMap<>();
    private final Map<String, Long> cooldownUntil = new HashMap<>();

    public SceneEngine(SceneCatalog catalog, ActionRegistry actions, SceneScheduler scheduler,
                       PlayerGateway players, ProgressTracker progress, ServiceRegistry services,
                       ConditionEvaluator conditions, IntSupplier maxConcurrent, ScenesLogger log) {
        this.catalog = catalog;
        this.actions = actions;
        this.scheduler = scheduler;
        this.players = players;
        this.progress = progress;
        this.services = services;
        this.conditions = conditions;
        this.maxConcurrent = maxConcurrent;
        this.log = log;
    }

    @Override
    public String name() {
        return "scene-engine";
    }

    @Override
    public void start() {
        // Runs are created on demand.
    }

    @Override
    public void stop() {
        stopAll("plugin disabled");
    }

    /**
     * Starts a scene for a player. With force, cooldown, play-once, conditions and the enabled
     * flag are ignored (used by admins and the web panel).
     */
    public StartResult start(UUID player, String sceneId, boolean force) {
        SceneDefinition scene = catalog.find(sceneId).orElse(null);
        if (scene == null) {
            return StartResult.UNKNOWN_SCENE;
        }
        return startScene(player, scene, force);
    }

    private StartResult startScene(UUID player, SceneDefinition scene, boolean force) {
        if (!players.isOnline(player)) {
            return StartResult.PLAYER_OFFLINE;
        }
        if (!force) {
            if (!scene.enabled()) {
                return StartResult.DISABLED;
            }
            if (scene.trigger().oncePerPlayer() && progress.hasCompleted(player, scene.id())) {
                return StartResult.ALREADY_PLAYED;
            }
            Long until = cooldownUntil.get(cooldownKey(player, scene.id()));
            if (until != null && scheduler.nowMillis() < until) {
                return StartResult.COOLDOWN;
            }
            if (!conditions.allMatch(scene.conditions(), player, Map.of())) {
                return StartResult.CONDITIONS_FAILED;
            }
        }

        SceneRun current = running.get(player);
        if (current != null) {
            if (scene.priority() > current.scene().priority()) {
                log.debug("Scene " + current.scene().id() + " preempted by " + scene.id());
                current.cancel("preempted by " + scene.id());
            } else {
                return StartResult.ALREADY_RUNNING;
            }
        }
        if (running.size() >= Math.max(1, maxConcurrent.getAsInt())) {
            return StartResult.LIMIT_REACHED;
        }

        ActionContext context = new ActionContext(player, scene.id(), services, conditions, log);
        SceneRun run = new SceneRun(scene, player, context, actions, scheduler, log, this::onFinished);
        running.put(player, run);
        log.info("Scene " + scene.id() + " started for " + displayName(player) + ".");
        run.start();
        return StartResult.STARTED;
    }

    /** Stops the player's scene, restoring everything it changed. Returns true when one was running. */
    public boolean stop(UUID player, String reason) {
        SceneRun run = running.get(player);
        if (run == null) {
            return false;
        }
        run.cancel(reason);
        return true;
    }

    /** Stops every running scene and returns how many were stopped. */
    public int stopAll(String reason) {
        List<SceneRun> runs = new ArrayList<>(running.values());
        for (SceneRun run : runs) {
            run.cancel(reason);
        }
        return runs.size();
    }

    /** Called when a player leaves: cancels their scene and forgets their cooldowns. */
    public void onPlayerQuit(UUID player) {
        stop(player, "player disconnected");
        cooldownUntil.keySet().removeIf(key -> key.startsWith(player + ":"));
    }

    public boolean isRunning(UUID player) {
        return running.containsKey(player);
    }

    public Optional<String> runningScene(UUID player) {
        SceneRun run = running.get(player);
        return run == null ? Optional.empty() : Optional.of(run.scene().id());
    }

    public int runningCount() {
        return running.size();
    }

    /** Who is watching which scene right now. */
    public Map<UUID, String> running() {
        Map<UUID, String> out = new java.util.LinkedHashMap<>();
        running.forEach((player, run) -> out.put(player, run.scene().id()));
        return out;
    }

    private void onFinished(SceneRun run, boolean completed, String reason) {
        UUID player = run.player();
        SceneDefinition scene = run.scene();
        if (running.get(player) == run) {
            running.remove(player);
        }
        if (scene.cooldownMillis() > 0) {
            cooldownUntil.put(cooldownKey(player, scene.id()), scheduler.nowMillis() + scene.cooldownMillis());
        }
        if (completed) {
            try {
                progress.recordCompleted(player, scene.id());
            } catch (RuntimeException e) {
                log.error("Could not record progress for scene " + scene.id(), e);
            }
            log.info("Scene " + scene.id() + " completed for " + displayName(player) + ".");
        } else {
            log.info("Scene " + scene.id() + " cancelled for " + displayName(player) + " (" + reason + ").");
        }
    }

    private String displayName(UUID player) {
        String name = players.nameOf(player);
        return name == null ? player.toString() : name;
    }

    private static String cooldownKey(UUID player, String sceneId) {
        return player + ":" + sceneId;
    }
}
