package id.vae.scenes.particle;

import id.vae.scenes.camera.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.SplittableRandom;

/** Computes where particles go for one emission. Pure and deterministic. */
public final class ParticleEmitter {

    private static final double GOLDEN_ANGLE = Math.PI * (3 - Math.sqrt(5));
    private static final double REVOLUTION_MILLIS = 4000;

    private ParticleEmitter() {
    }

    /**
     * @param anchor        centre of the effect
     * @param elapsedMillis time since the effect started (rotates rings and spirals)
     * @param maxPerEmission hard limit on particles in this emission
     */
    public static List<ParticleCall> emit(ParticleSpec spec, Vec3 anchor, long elapsedMillis, int maxPerEmission) {
        int n = Math.max(1, Math.min(spec.amount(), Math.max(1, maxPerEmission)));
        double spin = 2 * Math.PI * (elapsedMillis / REVOLUTION_MILLIS);
        List<ParticleCall> calls = new ArrayList<>();
        switch (spec.shape()) {
            case POINT -> emitPoint(spec, anchor, elapsedMillis, n, calls);
            case RING -> {
                for (int i = 0; i < n; i++) {
                    double angle = spin + 2 * Math.PI * i / n;
                    calls.add(single(spec, anchor.x() + spec.radius() * Math.cos(angle), anchor.y(),
                            anchor.z() + spec.radius() * Math.sin(angle)));
                }
            }
            case SPHERE -> {
                for (int i = 0; i < n; i++) {
                    double y = n == 1 ? 0 : 1 - 2.0 * i / (n - 1);
                    double ring = Math.sqrt(Math.max(0, 1 - y * y));
                    double angle = spin + i * GOLDEN_ANGLE;
                    calls.add(single(spec, anchor.x() + spec.radius() * ring * Math.cos(angle),
                            anchor.y() + spec.radius() * y, anchor.z() + spec.radius() * ring * Math.sin(angle)));
                }
            }
            case SPIRAL -> {
                for (int i = 0; i < n; i++) {
                    double t = (double) i / n;
                    double angle = spin + 4 * Math.PI * t;
                    calls.add(single(spec, anchor.x() + spec.radius() * Math.cos(angle), anchor.y() + spec.height() * t,
                            anchor.z() + spec.radius() * Math.sin(angle)));
                }
            }
        }
        return calls;
    }

    private static void emitPoint(ParticleSpec spec, Vec3 anchor, long elapsed, int n, List<ParticleCall> out) {
        Vec3 d = spec.direction();
        boolean directional = d.x() != 0 || d.y() != 0 || d.z() != 0;
        if (!directional) {
            out.add(new ParticleCall(spec.type(), anchor.x(), anchor.y(), anchor.z(), n, spec.offset().x(),
                    spec.offset().y(), spec.offset().z(), spec.speed(), spec.color()));
            return;
        }
        SplittableRandom random = new SplittableRandom(elapsed);
        for (int i = 0; i < n; i++) {
            out.add(new ParticleCall(spec.type(),
                    anchor.x() + (random.nextDouble() * 2 - 1) * spec.offset().x(),
                    anchor.y() + (random.nextDouble() * 2 - 1) * spec.offset().y(),
                    anchor.z() + (random.nextDouble() * 2 - 1) * spec.offset().z(),
                    0, d.x(), d.y(), d.z(), spec.speed(), spec.color()));
        }
    }

    private static ParticleCall single(ParticleSpec spec, double x, double y, double z) {
        return new ParticleCall(spec.type(), x, y, z, 1, spec.offset().x(), spec.offset().y(), spec.offset().z(),
                spec.speed(), spec.color());
    }
}
