package id.vae.scenes.scene;

import id.vae.scenes.core.ServiceRegistry;
import id.vae.scenes.util.ScenesLogger;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Per-run state handed to every action: the player, shared variables and cleanup hooks. */
public final class ActionContext {

    private final UUID player;
    private final String sceneId;
    private final ServiceRegistry services;
    private final ConditionEvaluator conditions;
    private final ScenesLogger log;
    private final Map<String, Object> variables = new ConcurrentHashMap<>();
    private final Set<String> skipped = ConcurrentHashMap.newKeySet();
    private final Deque<Runnable> cleanups = new ArrayDeque<>();

    public ActionContext(UUID player, String sceneId, ServiceRegistry services, ConditionEvaluator conditions,
                         ScenesLogger log) {
        this.player = player;
        this.sceneId = sceneId;
        this.services = services;
        this.conditions = conditions;
        this.log = log;
    }

    public UUID player() {
        return player;
    }

    public String sceneId() {
        return sceneId;
    }

    public ServiceRegistry services() {
        return services;
    }

    public ConditionEvaluator conditions() {
        return conditions;
    }

    public ScenesLogger log() {
        return log;
    }

    public Map<String, Object> variables() {
        return variables;
    }

    /** Prevents a not-yet-started action from running. */
    public void skip(String actionId) {
        skipped.add(actionId);
    }

    public boolean isSkipped(String actionId) {
        return skipped.contains(actionId);
    }

    /**
     * Registers undo work (restore camera, unlock movement, remove entities). Cleanups run in
     * reverse order when the scene finishes or is cancelled, even if it failed.
     */
    public synchronized void addCleanup(Runnable cleanup) {
        cleanups.push(cleanup);
    }

    synchronized void runCleanups() {
        while (!cleanups.isEmpty()) {
            Runnable cleanup = cleanups.pop();
            try {
                cleanup.run();
            } catch (RuntimeException e) {
                log.error("Scene '" + sceneId + "' cleanup failed", e);
            }
        }
    }
}
