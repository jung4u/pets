package id.vae.scenes.particle;

import id.vae.scenes.camera.CameraControl;
import id.vae.scenes.camera.CameraPose;
import id.vae.scenes.camera.Vec3;
import id.vae.scenes.core.Service;
import id.vae.scenes.scene.SceneScheduler;
import id.vae.scenes.util.ScenesLogger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.IntSupplier;

/**
 * Runs particle effects with a repeating emission. There is no per-tick task: each effect schedules
 * its next emission, and stops itself when its duration is over. Main thread only.
 */
public final class ParticleService implements Service, ParticleControl {

    private static final class Effect {
        final ParticleSpec spec;
        final String tag;
        final long startedAt;
        Vec3 fixedAnchor;
        SceneScheduler.Task task;
        boolean stopped;

        Effect(ParticleSpec spec, String tag, long startedAt) {
            this.spec = spec;
            this.tag = tag;
            this.startedAt = startedAt;
        }
    }

    private final ParticleOutput output;
    private final CameraControl camera;
    private final SceneScheduler scheduler;
    private final IntSupplier maxPerEmission;
    private final ScenesLogger log;
    private final Map<UUID, List<Effect>> effects = new HashMap<>();

    public ParticleService(ParticleOutput output, CameraControl camera, SceneScheduler scheduler,
                           IntSupplier maxPerEmission, ScenesLogger log) {
        this.output = output;
        this.camera = camera;
        this.scheduler = scheduler;
        this.maxPerEmission = maxPerEmission;
        this.log = log;
    }

    @Override
    public String name() {
        return "particle";
    }

    @Override
    public void start() {
        // Nothing to start.
    }

    @Override
    public void stop() {
        for (UUID player : new ArrayList<>(effects.keySet())) {
            endScene(player);
        }
    }

    @Override
    public void start(UUID player, ParticleSpec spec, String tag) {
        Effect effect = new Effect(spec, tag == null ? "" : tag, scheduler.nowMillis());
        effects.computeIfAbsent(player, k -> new ArrayList<>()).add(effect);
        emit(player, effect);
    }

    @Override
    public void stop(UUID player, String tagOrNull) {
        List<Effect> list = effects.get(player);
        if (list == null) {
            return;
        }
        for (Effect effect : new ArrayList<>(list)) {
            if (tagOrNull == null || effect.tag.equals(tagOrNull)) {
                cancel(effect);
                list.remove(effect);
            }
        }
        if (list.isEmpty()) {
            effects.remove(player);
        }
    }

    @Override
    public void endScene(UUID player) {
        stop(player, null);
    }

    private void emit(UUID player, Effect effect) {
        if (effect.stopped) {
            return;
        }
        long elapsed = scheduler.nowMillis() - effect.startedAt;
        Vec3 anchor = anchor(player, effect);
        if (anchor != null) {
            try {
                for (ParticleCall call : ParticleEmitter.emit(effect.spec, anchor, elapsed, maxPerEmission.getAsInt())) {
                    output.spawn(player, call, effect.spec.nearby());
                }
            } catch (RuntimeException e) {
                log.error("Particle effect " + effect.spec.type() + " failed and was stopped", e);
                finish(player, effect);
                return;
            }
        }
        long next = elapsed + effect.spec.intervalMillis();
        if (effect.spec.durationMillis() <= 0 || next >= effect.spec.durationMillis()) {
            finish(player, effect);
        } else {
            effect.task = scheduler.runLater(effect.spec.intervalMillis(), () -> emit(player, effect));
        }
    }

    private Vec3 anchor(UUID player, Effect effect) {
        ParticleSpec spec = effect.spec;
        if (spec.anchor() == ParticleSpec.Anchor.WORLD) {
            return spec.point();
        }
        if (!spec.follow() && effect.fixedAnchor != null) {
            return effect.fixedAnchor;
        }
        Vec3 anchor = switch (spec.anchor()) {
            case CAMERA -> camera.currentPose(player).map(CameraPose::position).orElse(null);
            default -> camera.playerEyePose(player)
                    .map(eye -> new Vec3(eye.x(), eye.y() - 1.62 + spec.height(), eye.z())).orElse(null);
        };
        if (!spec.follow()) {
            effect.fixedAnchor = anchor;
        }
        return anchor;
    }

    private void finish(UUID player, Effect effect) {
        effect.stopped = true;
        List<Effect> list = effects.get(player);
        if (list != null) {
            list.remove(effect);
            if (list.isEmpty()) {
                effects.remove(player);
            }
        }
    }

    private void cancel(Effect effect) {
        effect.stopped = true;
        if (effect.task != null) {
            effect.task.cancel();
        }
    }
}
