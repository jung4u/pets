package id.vae.scenes.scene;

import id.vae.scenes.util.Easing;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * One step of a scene.
 *
 * @param delayMillis    start time measured from the beginning of the scene
 * @param durationMillis how long the action itself lasts
 */
public record ActionDefinition(
        String id,
        String type,
        int order,
        long delayMillis,
        long durationMillis,
        Easing easing,
        boolean enabled,
        List<ConditionSpec> conditions,
        Map<String, Object> config) {

    public ActionDefinition {
        id = id == null ? "" : id.trim();
        type = type == null ? "" : type.trim().toUpperCase(Locale.ROOT);
        easing = easing == null ? Easing.LINEAR : easing;
        conditions = conditions == null ? List.of() : List.copyOf(conditions);
        config = config == null ? Map.of() : Collections.unmodifiableMap(new LinkedHashMap<>(config));
    }

    public ActionDefinition withOrder(int newOrder) {
        return new ActionDefinition(id, type, newOrder, delayMillis, durationMillis, easing, enabled,
                conditions, config);
    }

    public ActionDefinition withTiming(long newDelayMillis, long newDurationMillis) {
        return new ActionDefinition(id, type, order, newDelayMillis, newDurationMillis, easing, enabled,
                conditions, config);
    }
}
