package id.vae.scenes.particle;

import id.vae.scenes.camera.CameraPose;
import id.vae.scenes.camera.FakeCameraControl;
import id.vae.scenes.camera.Vec3;
import id.vae.scenes.scene.EngineHarness;
import id.vae.scenes.scene.PresetLibrary;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static id.vae.scenes.scene.TestSupport.action;
import static id.vae.scenes.scene.TestSupport.scene;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ParticleTest {

    private static final class FakeOutput implements ParticleOutput {
        final List<ParticleCall> calls = new ArrayList<>();

        @Override
        public void spawn(UUID player, ParticleCall call, boolean nearby) {
            calls.add(call);
        }
    }

    private EngineHarness h;
    private FakeOutput output;
    private FakeCameraControl camera;
    private ParticleService service;
    private int cap;

    @BeforeEach
    void setUp() {
        h = new EngineHarness();
        output = new FakeOutput();
        camera = new FakeCameraControl();
        cap = 200;
        service = new ParticleService(output, camera, h.clock, () -> cap, h.log);
        PresetLibrary library = new PresetLibrary(Map.of("purple_portal",
                Map.of("type", "PORTAL", "shape", "SPIRAL", "amount", 24, "radius", 1.2, "interval-ms", 100)));
        ParticleActions.registerAll(h.registry, service, library);
    }

    private static ParticleSpec spec(ParticleSpec.Shape shape, int amount, double radius, long duration,
                                     long interval, boolean follow) {
        return new ParticleSpec("PORTAL", shape, amount, null, 0, radius, 2.0, null, "", ParticleSpec.Anchor.PLAYER,
                null, follow, false, duration, interval);
    }

    @Test
    void ringPointsSitOnTheRadiusAtTheAnchorHeight() {
        List<ParticleCall> calls = ParticleEmitter.emit(spec(ParticleSpec.Shape.RING, 12, 3, 0, 100, false),
                new Vec3(10, 64, -5), 0, 200);

        assertEquals(12, calls.size());
        for (ParticleCall c : calls) {
            assertEquals(3.0, Math.hypot(c.x() - 10, c.z() + 5), 1e-9);
            assertEquals(64.0, c.y(), 1e-9);
            assertEquals(1, c.count());
        }
    }

    @Test
    void sphereAndSpiralStayWithinTheirBounds() {
        Vec3 anchor = new Vec3(0, 64, 0);
        for (ParticleCall c : ParticleEmitter.emit(spec(ParticleSpec.Shape.SPHERE, 40, 2, 0, 100, false), anchor, 0, 200)) {
            assertEquals(2.0, Math.sqrt(c.x() * c.x() + (c.y() - 64) * (c.y() - 64) + c.z() * c.z()), 1e-9);
        }
        double highest = 0;
        for (ParticleCall c : ParticleEmitter.emit(spec(ParticleSpec.Shape.SPIRAL, 30, 1, 0, 100, false), anchor, 0, 200)) {
            assertEquals(1.0, Math.hypot(c.x(), c.z()), 1e-9);
            assertTrue(c.y() >= 64);
            highest = Math.max(highest, c.y() - 64);
        }
        assertTrue(highest > 1.5 && highest < 2.0);
    }

    @Test
    void ringsAndSpiralsRotateOverTime() {
        ParticleSpec ring = spec(ParticleSpec.Shape.RING, 4, 1, 0, 100, false);
        ParticleCall early = ParticleEmitter.emit(ring, new Vec3(0, 0, 0), 0, 200).get(0);
        ParticleCall later = ParticleEmitter.emit(ring, new Vec3(0, 0, 0), 1000, 200).get(0);

        assertTrue(Math.abs(early.x() - later.x()) > 0.1 || Math.abs(early.z() - later.z()) > 0.1);
    }

    @Test
    void amountIsClampedByTheLimit() {
        List<ParticleCall> ring = ParticleEmitter.emit(spec(ParticleSpec.Shape.RING, 500, 2, 0, 100, false),
                new Vec3(0, 0, 0), 0, 50);
        List<ParticleCall> point = ParticleEmitter.emit(spec(ParticleSpec.Shape.POINT, 500, 2, 0, 100, false),
                new Vec3(0, 0, 0), 0, 50);

        assertEquals(50, ring.size());
        assertEquals(50, point.get(0).count());
    }

    @Test
    void directionalPointParticlesUseCountZero() {
        ParticleSpec up = new ParticleSpec("END_ROD", ParticleSpec.Shape.POINT, 5, new Vec3(1, 0, 1), 0.2, 1, 1,
                new Vec3(0, 1, 0), "", ParticleSpec.Anchor.PLAYER, null, false, false, 0, 100);

        List<ParticleCall> calls = ParticleEmitter.emit(up, new Vec3(0, 64, 0), 7, 200);

        assertEquals(5, calls.size());
        assertEquals(0, calls.get(0).count());
        assertEquals(1.0, calls.get(0).offsetY(), 1e-9);
        assertEquals(calls, ParticleEmitter.emit(up, new Vec3(0, 64, 0), 7, 200));
    }

    @Test
    void effectEmitsEveryIntervalUntilItsDurationEnds() {
        service.start(h.alice, spec(ParticleSpec.Shape.RING, 4, 1, 1000, 250, true), "ring");

        h.clock.advance(5000);

        assertEquals(4 * 4, output.calls.size());
    }

    @Test
    void zeroDurationEmitsOnce() {
        service.start(h.alice, spec(ParticleSpec.Shape.RING, 4, 1, 0, 250, true), "ring");
        h.clock.advance(5000);

        assertEquals(4, output.calls.size());
    }

    @Test
    void followingEffectsTrackThePlayerAndFixedOnesDoNot() {
        service.start(h.alice, spec(ParticleSpec.Shape.POINT, 1, 1, 1000, 250, true), "follow");
        service.start(h.alice, spec(ParticleSpec.Shape.POINT, 1, 1, 1000, 250, false), "fixed");
        camera.eye = new CameraPose(100, 65.62, 0, 0, 0);

        h.clock.advance(250);

        ParticleCall followed = output.calls.get(output.calls.size() - 2);
        ParticleCall fixed = output.calls.get(output.calls.size() - 1);
        assertEquals(100.0, followed.x(), 1e-9);
        assertEquals(0.0, fixed.x(), 1e-9);
    }

    @Test
    void anchorHeightIsMeasuredFromThePlayersFeet() {
        service.start(h.alice, spec(ParticleSpec.Shape.POINT, 1, 1, 0, 250, true), "p");

        // Eyes at 65.62 put the feet at 64.0; the spec's height of 2.0 is measured up from there.
        assertEquals(66.0, output.calls.get(0).y(), 1e-6);
    }

    @Test
    void stopByTagAndEndSceneCancelEmissions() {
        service.start(h.alice, spec(ParticleSpec.Shape.POINT, 1, 1, 10_000, 100, true), "a");
        service.start(h.alice, spec(ParticleSpec.Shape.POINT, 1, 1, 10_000, 100, true), "b");

        service.stop(h.alice, "a");
        int afterStop = output.calls.size();
        h.clock.advance(100);
        assertEquals(afterStop + 1, output.calls.size());

        service.endScene(h.alice);
        int atEnd = output.calls.size();
        h.clock.advance(5000);
        assertEquals(atEnd, output.calls.size());
    }

    @Test
    void presetsSupplyDefaultsThatTheActionCanOverride() {
        h.run(scene("intro", 0, action("p", "PARTICLE_SPAWN", 0, 0, Map.of("preset", "purple_portal", "amount", 8))));

        assertEquals(8, output.calls.size());
        assertEquals("PORTAL", output.calls.get(0).type());
    }

    @Test
    void cancellingTheSceneStopsRunningEffects() {
        h.run(scene("intro", 0, action("p", "PARTICLE_FOLLOW", 0, 10_000, Map.of("type", "END_ROD", "interval-ms", 100))));
        h.clock.advance(300);
        int before = output.calls.size();

        h.engine.stop(h.alice, "test");
        h.clock.advance(5000);

        assertEquals(before, output.calls.size());
    }

    @Test
    void validationReportsBadParticleSettings() {
        assertTrue(h.errors(action("a", "PARTICLE_SPAWN", 0, 0, Map.of())).contains("type"));
        assertTrue(h.errors(action("a", "PARTICLE_SPAWN", 0, 0, Map.of("type", "portal!"))).contains("invalid particle type"));
        assertTrue(h.errors(action("a", "PARTICLE_SPAWN", 0, 0, Map.of("preset", "nope"))).contains("preset"));
        assertTrue(h.errors(action("a", "PARTICLE_SPAWN", 0, 0, Map.of("type", "PORTAL", "shape", "CUBE"))).contains("shape"));
        assertTrue(h.errors(action("a", "PARTICLE_SPAWN", 0, 0, Map.of("type", "PORTAL", "anchor", "WORLD")))
                .contains("position"));
        assertTrue(h.errors(action("a", "PARTICLE_SPAWN", 0, 0, Map.of("type", "PORTAL", "amount", 0))).contains("amount"));
        assertTrue(h.errors(action("a", "PARTICLE_SPAWN", 0, 0, Map.of("type", "PORTAL", "interval-ms", 10)))
                .contains("interval"));
        assertTrue(h.errors(action("a", "PARTICLE_SPAWN", 0, 0, Map.of("type", "DUST", "color", "purple"))).contains("color"));
        assertEquals("", h.errors(action("a", "PARTICLE_SPAWN", 0, 0, Map.of("type", "PORTAL"))));
        assertEquals("", h.errors(action("a", "PARTICLE_FOLLOW", 0, 2000, Map.of("preset", "purple_portal"))));
        assertEquals("", h.errors(action("a", "PARTICLE_STOP", 0, 0, Map.of())));
    }
}
