package id.vae.scenes.camera;

/** Produces the camera pose for a given time since the movement started. */
public interface PoseSource {

    CameraPose poseAt(long elapsedMillis);

    /** Total length; the camera holds the final pose afterwards. */
    long durationMillis();
}
