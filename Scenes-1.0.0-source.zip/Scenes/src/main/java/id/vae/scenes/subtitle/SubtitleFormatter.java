package id.vae.scenes.subtitle;

/** Turns a subtitle spec into a MiniMessage string. */
public final class SubtitleFormatter {

    private SubtitleFormatter() {
    }

    /** Wraps the (already placeholder-resolved) text with the colour, gradient and style tags. */
    public static String toMiniMessage(SubtitleSpec spec, String text) {
        StringBuilder open = new StringBuilder();
        StringBuilder close = new StringBuilder();
        if (spec.gradient().size() >= 2) {
            open.append("<gradient:").append(String.join(":", spec.gradient().stream().map(SubtitleFormatter::hex)
                    .toList())).append('>');
            close.insert(0, "</gradient>");
        } else if (!spec.color().isBlank()) {
            open.append("<color:").append(hex(spec.color())).append('>');
            close.insert(0, "</color>");
        }
        if (spec.bold()) {
            open.append("<bold>");
            close.insert(0, "</bold>");
        }
        if (spec.italic()) {
            open.append("<italic>");
            close.insert(0, "</italic>");
        }
        if (spec.underline()) {
            open.append("<underlined>");
            close.insert(0, "</underlined>");
        }
        return open + text + close;
    }

    /** Escapes MiniMessage tags in a value that comes from a placeholder, so it cannot inject formatting. */
    public static String escape(String value) {
        return value.replace("\\", "\\\\").replace("<", "\\<");
    }

    private static String hex(String value) {
        String v = value.trim();
        return v.startsWith("#") ? v : "#" + v;
    }
}
