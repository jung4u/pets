package id.vae.scenes.bukkit;

import id.vae.scenes.camera.CameraControl;
import id.vae.scenes.camera.CameraPose;
import id.vae.scenes.camera.CameraShake;
import id.vae.scenes.camera.PoseSource;
import id.vae.scenes.config.CameraSettings;
import id.vae.scenes.core.Service;
import id.vae.scenes.scene.PlayerLocks;
import id.vae.scenes.util.ScenesLogger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * The camera engine. Each camera is an invisible marker armor stand that only the viewing player can
 * see. The tick task runs only while at least one camera is active. Everything is restored when a
 * session ends, the player quits or dies, changes world, or the plugin stops.
 */
public final class CameraManager implements Service, CameraControl, Listener {

    static final String TAG = "scenes_camera";

    private final Plugin plugin;
    private final Supplier<CameraSettings> settings;
    private final IntSupplier maxSessions;
    private final PlayerLocks locks;
    private final ScenesLogger log;
    private final Map<UUID, CameraSession> sessions = new HashMap<>();
    private final CameraBackend spectatorBackend;
    private CameraBackend protocolBackend;
    private BukkitTask ticker;

    public CameraManager(Plugin plugin, Supplier<CameraSettings> settings, IntSupplier maxSessions,
                         PlayerLocks locks, RestoreStore restoreStore, ScenesLogger log) {
        this.plugin = plugin;
        this.settings = settings;
        this.maxSessions = maxSessions;
        this.locks = locks;
        this.log = log;
        this.spectatorBackend = new SpectatorBackend(restoreStore, log);
    }

    @Override
    public String name() {
        return "camera";
    }

    @Override
    public void start() {
        if (plugin.getServer().getPluginManager().isPluginEnabled("ProtocolLib")) {
            try {
                protocolBackend = new ProtocolLibBackend(plugin, locks, log);
            } catch (ReflectiveOperationException | RuntimeException e) {
                log.error("ProtocolLib is installed but its camera packet could not be prepared; "
                        + "using the configured fallback", e);
            }
        }
        removeLeftoverCameras();
        log.info("Camera engine initialized (ProtocolLib " + (protocolBackend != null ? "available" : "not available")
                + ").");
    }

    @Override
    public void stop() {
        endAll();
        cancelTicker();
    }

    // ------------------------------------------------------------------ CameraControl

    @Override
    public boolean begin(UUID id, CameraPose start) {
        Player player = Bukkit.getPlayer(id);
        if (player == null || !player.isOnline()) {
            return false;
        }
        if (sessions.containsKey(id)) {
            return true;
        }
        if (sessions.size() >= Math.max(1, maxSessions.getAsInt())) {
            log.warn("Camera limit reached (" + sessions.size() + " active); skipping the camera for "
                    + player.getName() + ".");
            return false;
        }
        CameraBackend backend = selectBackend(player);
        if (backend == null) {
            return false;
        }
        double eyeHeight = settings.get().eyeHeight();
        World world = player.getWorld();
        ArmorStand stand = null;
        try {
            Location at = new Location(world, start.x(), start.y() - eyeHeight, start.z(), start.yaw(), start.pitch());
            stand = world.spawn(at, ArmorStand.class, as -> {
                as.setVisible(false);
                as.setMarker(true);
                as.setSmall(true);
                as.setGravity(false);
                as.setInvulnerable(true);
                as.setSilent(true);
                as.setBasePlate(false);
                as.setPersistent(false);
                as.setVisibleByDefault(false);
                as.addScoreboardTag(TAG);
            });
            player.showEntity(plugin, stand);
            backend.attach(player, stand);
            sessions.put(id, new CameraSession(id, stand, backend, start));
            ensureTicker();
            log.debug("Camera started for " + player.getName() + " using " + backend.name() + ".");
            return true;
        } catch (Exception e) {
            log.error("Could not start the camera for " + player.getName(), e);
            if (stand != null) {
                try {
                    backend.detach(player, stand);
                } catch (RuntimeException ignored) {
                    // Best effort: the entity is removed below either way.
                }
                stand.remove();
            }
            return false;
        }
    }

    @Override
    public boolean isActive(UUID player) {
        return sessions.containsKey(player);
    }

    @Override
    public Optional<CameraPose> currentPose(UUID player) {
        CameraSession session = sessions.get(player);
        return session == null ? Optional.empty() : Optional.of(session.basePose);
    }

    @Override
    public void play(UUID player, PoseSource source) {
        CameraSession session = sessions.get(player);
        if (session != null) {
            session.source = source;
            session.sourceStart = System.currentTimeMillis();
        }
    }

    @Override
    public void shake(UUID player, CameraShake shake) {
        CameraSession session = sessions.get(player);
        if (session != null) {
            session.shake = shake;
            session.shakeStart = System.currentTimeMillis();
        }
    }

    @Override
    public void end(UUID id) {
        CameraSession session = sessions.remove(id);
        if (session == null) {
            return;
        }
        Player player = Bukkit.getPlayer(id);
        try {
            if (player != null) {
                session.backend.detach(player, session.entity);
            }
        } catch (RuntimeException e) {
            log.error("Could not restore the player after a camera session", e);
        } finally {
            session.entity.remove();
            if (sessions.isEmpty()) {
                cancelTicker();
            }
        }
        log.debug("Camera ended for " + id + ".");
    }

    @Override
    public Optional<CameraPose> playerEyePose(UUID id) {
        Player player = Bukkit.getPlayer(id);
        if (player == null) {
            return Optional.empty();
        }
        Location eye = player.getEyeLocation();
        return Optional.of(new CameraPose(eye.getX(), eye.getY(), eye.getZ(), eye.getYaw(), eye.getPitch()));
    }

    @Override
    public Optional<String> playerWorld(UUID id) {
        Player player = Bukkit.getPlayer(id);
        return player == null ? Optional.empty() : Optional.of(player.getWorld().getName());
    }

    @Override
    public double maxDistance() {
        return settings.get().maxDistance();
    }

    public int activeCount() {
        return sessions.size();
    }

    public void endAll() {
        for (UUID id : new ArrayList<>(sessions.keySet())) {
            end(id);
        }
    }

    // ------------------------------------------------------------------ events

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        end(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        end(event.getEntity().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorldChange(PlayerChangedWorldEvent event) {
        end(event.getPlayer().getUniqueId());
    }

    /** A teleport far away from the camera (another plugin moved the player) ends the camera, not the scene. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        CameraSession session = sessions.get(event.getPlayer().getUniqueId());
        Location to = event.getTo();
        if (session == null || to == null || event.getCause() == PlayerTeleportEvent.TeleportCause.SPECTATE) {
            return;
        }
        Location camera = session.entity.getLocation();
        if (to.getWorld() != camera.getWorld() || to.distance(camera) > settings.get().maxDistance()) {
            end(session.player);
        }
    }

    // ------------------------------------------------------------------ internals

    private CameraBackend selectBackend(Player player) {
        CameraSettings s = settings.get();
        boolean bedrock = player.getUniqueId().getMostSignificantBits() == 0;
        String choice = bedrock ? s.bedrockBackend() : s.backend();
        return switch (choice) {
            case "PROTOCOLLIB" -> protocolBackend;
            case "SPECTATOR" -> spectatorBackend;
            case "NONE" -> null;
            default -> protocolBackend != null ? protocolBackend : spectatorBackend;
        };
    }

    private void ensureTicker() {
        if (ticker == null) {
            ticker = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
        }
    }

    private void cancelTicker() {
        if (ticker != null) {
            ticker.cancel();
            ticker = null;
        }
    }

    private void tick() {
        long now = System.currentTimeMillis();
        double eyeHeight = settings.get().eyeHeight();
        for (CameraSession session : new ArrayList<>(sessions.values())) {
            Player player = Bukkit.getPlayer(session.player);
            Entity entity = session.entity;
            if (player == null || !player.isOnline() || !entity.isValid() || player.getWorld() != entity.getWorld()) {
                end(session.player);
                continue;
            }
            try {
                PoseSource source = session.source;
                if (source != null) {
                    long elapsed = now - session.sourceStart;
                    session.basePose = source.poseAt(elapsed);
                    if (elapsed >= source.durationMillis()) {
                        session.source = null;
                    }
                }
                CameraPose shown = session.basePose;
                if (session.shake != null) {
                    long elapsed = now - session.shakeStart;
                    if (elapsed >= session.shake.durationMillis()) {
                        session.shake = null;
                    } else {
                        shown = session.shake.apply(shown, elapsed);
                    }
                }
                entity.teleport(new Location(entity.getWorld(), shown.x(), shown.y() - eyeHeight, shown.z(),
                        shown.yaw(), shown.pitch()));
            } catch (RuntimeException e) {
                log.error("Camera tick failed for " + session.player + "; ending the camera", e);
                end(session.player);
            }
        }
        if (sessions.isEmpty()) {
            cancelTicker();
        }
    }

    private void removeLeftoverCameras() {
        for (World world : Bukkit.getWorlds()) {
            for (ArmorStand stand : world.getEntitiesByClass(ArmorStand.class)) {
                if (stand.getScoreboardTags().contains(TAG)) {
                    stand.remove();
                }
            }
        }
    }
}
