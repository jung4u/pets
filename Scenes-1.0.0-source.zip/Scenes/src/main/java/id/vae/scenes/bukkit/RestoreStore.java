package id.vae.scenes.bukkit;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;

/**
 * Remembers a player's game state while a scene temporarily changes it, in a small file per player. If the
 * server crashes in the middle of a scene, the state is restored when the player joins again.
 */
public final class RestoreStore {

    public record Saved(String gameMode, boolean allowFlight, boolean flying, String world, double x, double y,
                        double z, float yaw, float pitch) {
    }

    private final Path folder;

    public RestoreStore(Path folder) {
        this.folder = folder;
    }

    public void save(UUID player, Saved state) throws IOException {
        Files.createDirectories(folder);
        Properties p = new Properties();
        p.setProperty("gameMode", state.gameMode());
        p.setProperty("allowFlight", Boolean.toString(state.allowFlight()));
        p.setProperty("flying", Boolean.toString(state.flying()));
        p.setProperty("world", state.world() == null ? "" : state.world());
        p.setProperty("x", Double.toString(state.x()));
        p.setProperty("y", Double.toString(state.y()));
        p.setProperty("z", Double.toString(state.z()));
        p.setProperty("yaw", Float.toString(state.yaw()));
        p.setProperty("pitch", Float.toString(state.pitch()));
        Path target = file(player);
        Path temp = folder.resolve(player + ".tmp");
        try (OutputStream out = Files.newOutputStream(temp)) {
            p.store(out, "Scenes: state to restore after an interrupted scene");
        }
        Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
    }

    /** The saved state, or empty when there is none or the file is unreadable. */
    public Optional<Saved> load(UUID player) {
        Path file = file(player);
        if (Files.notExists(file)) {
            return Optional.empty();
        }
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            p.load(in);
            return Optional.of(new Saved(p.getProperty("gameMode", "SURVIVAL"),
                    Boolean.parseBoolean(p.getProperty("allowFlight", "false")),
                    Boolean.parseBoolean(p.getProperty("flying", "false")), p.getProperty("world", ""),
                    Double.parseDouble(p.getProperty("x", "0")), Double.parseDouble(p.getProperty("y", "0")),
                    Double.parseDouble(p.getProperty("z", "0")), Float.parseFloat(p.getProperty("yaw", "0")),
                    Float.parseFloat(p.getProperty("pitch", "0"))));
        } catch (IOException | NumberFormatException e) {
            return Optional.empty();
        }
    }

    public void delete(UUID player) {
        try {
            Files.deleteIfExists(file(player));
        } catch (IOException e) {
            // A leftover file only means one harmless extra restore on the next join.
        }
    }

    private Path file(UUID player) {
        return folder.resolve(player + ".properties");
    }
}
