package id.vae.scenes.scene;

import id.vae.scenes.database.DatabaseManager;
import id.vae.scenes.database.ProgressRepository;
import id.vae.scenes.util.ScenesLogger;

import java.sql.SQLException;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Progress tracker backed by SQLite with a per-player cache, so checks during gameplay never
 * query the database. Preload a player on join; writes happen on the database thread.
 */
public final class DatabaseProgressTracker implements ProgressTracker {

    private final ProgressRepository repository;
    private final DatabaseManager database;
    private final ScenesLogger log;
    private final ConcurrentHashMap<UUID, Set<String>> cache = new ConcurrentHashMap<>();

    public DatabaseProgressTracker(ProgressRepository repository, DatabaseManager database, ScenesLogger log) {
        this.repository = repository;
        this.database = database;
        this.log = log;
    }

    @Override
    public boolean hasCompleted(UUID player, String sceneId) {
        return completedSet(player).contains(sceneId);
    }

    @Override
    public void recordCompleted(UUID player, String sceneId) {
        completedSet(player).add(sceneId);
        database.async(c -> {
            repository.markCompleted(player, sceneId, System.currentTimeMillis());
            return null;
        }).exceptionally(error -> {
            log.error("Could not save progress for " + player + " scene " + sceneId, error);
            return null;
        });
    }

    /** Loads a player's progress on the database thread. */
    public void preload(UUID player) {
        database.async(c -> {
            cache.put(player, load(player));
            return null;
        }).exceptionally(error -> {
            log.error("Could not preload progress for " + player, error);
            return null;
        });
    }

    /** Drops cached data for a player (on quit, or after an admin reset). */
    public void invalidate(UUID player) {
        cache.remove(player);
    }

    public void invalidateAll() {
        cache.clear();
    }

    private Set<String> completedSet(UUID player) {
        Set<String> cached = cache.get(player);
        if (cached != null) {
            return cached;
        }
        Set<String> loaded = load(player);
        Set<String> previous = cache.putIfAbsent(player, loaded);
        return previous != null ? previous : loaded;
    }

    private Set<String> load(UUID player) {
        Set<String> set = ConcurrentHashMap.newKeySet();
        try {
            for (ProgressRepository.ProgressEntry entry : repository.forPlayer(player)) {
                if (entry.completedCount() > 0) {
                    set.add(entry.sceneId());
                }
            }
        } catch (SQLException e) {
            log.error("Could not load progress for " + player, e);
        }
        return set;
    }
}
