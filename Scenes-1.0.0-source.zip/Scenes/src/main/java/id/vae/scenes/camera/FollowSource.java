package id.vae.scenes.camera;

import java.util.function.Supplier;

/**
 * Follows a moving target at a fixed offset, always facing it, with exponential smoothing.
 * The target supplier may return null when the target is unavailable; the camera then stays put.
 */
public final class FollowSource implements PoseSource {

    private final Supplier<Vec3> target;
    private final Vec3 offset;
    private final double smoothingMillis;
    private final long duration;

    private Vec3 position;
    private Vec3 lastTarget;
    private long lastElapsed;

    public FollowSource(Supplier<Vec3> target, Vec3 offset, double smoothingMillis, long durationMillis) {
        this.target = target;
        this.offset = offset;
        this.smoothingMillis = Math.max(0, smoothingMillis);
        this.duration = durationMillis;
    }

    @Override
    public long durationMillis() {
        return duration;
    }

    @Override
    public synchronized CameraPose poseAt(long elapsedMillis) {
        Vec3 current = target.get();
        if (current != null) {
            lastTarget = current;
        }
        if (lastTarget == null) {
            return new CameraPose(0, 0, 0, 0, 0);
        }
        Vec3 desired = lastTarget.add(offset);
        if (position == null || smoothingMillis == 0) {
            position = desired;
        } else {
            double dt = Math.max(0, elapsedMillis - lastElapsed);
            double alpha = 1.0 - Math.exp(-dt / smoothingMillis);
            position = Vec3.lerp(position, desired, alpha);
        }
        lastElapsed = elapsedMillis;
        return CameraPose.lookAt(position, lastTarget);
    }
}
