package id.vae.scenes.bukkit;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

/** A technique for showing the world from the camera entity. Implementations must make detach idempotent. */
interface CameraBackend {

    String name();

    void attach(Player player, Entity camera) throws Exception;

    void detach(Player player, Entity camera);
}
