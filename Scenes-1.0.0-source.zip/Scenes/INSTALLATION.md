# Installation

## Requirements

- Paper 1.21.11 and Java 21
- Optional, all detected automatically: ProtocolLib (camera without spectator mode), AuthMe (wait for login),
  PlaceholderAPI (placeholders in subtitles), Geyser/Floodgate (Bedrock players)

## Build on Termux

    pkg update
    pkg install openjdk-21 maven

    java -version
    mvn -version

    cd Scenes
    mvn clean test
    mvn clean package

The plugin is `target/Scenes-1.0.0.jar`. The first build downloads the Paper API, so it needs internet
and a few minutes. If `mvn clean test` fails, send the full log; a failing test never means the plugin is broken
until you have seen which one.

## Install on the server

1. Stop the server.
2. Copy `Scenes-1.0.0.jar` to the server's `plugins/` folder.
3. Start Paper 1.21.11 (Java 21). The log shows `[Scenes] Plugin enabled.`, how many scenes were loaded, and which
   camera backend is used.
4. The five built-in scenes are imported on the first start. Try one: `/scene start <yourname> first_join`.

## Notes

- The SQLite driver is marked `provided` because Paper bundles it. If the plugin refuses to start with
  "SQLite JDBC driver not found", declare it under `libraries:` in `plugin.yml`.
- Files: see CONFIGURATION.md. The database is `plugins/Scenes/data/scenes.db`; backups are in `plugins/Scenes/backups/`.
- To get a built-in scene back after deleting it: delete its file in `plugins/Scenes/scenes/` and restart (the original is copied again), then run `/scenes import <file>`.
- If a scene is stuck (for example after an error in another plugin), `/scene stopall` restores every player.
- Never remove the plugin while a player is in the middle of a camera shot with the spectator backend: stop
  scenes first. If the server did crash during one, the player's game mode and location are restored when they next join.

## Troubleshooting

| Symptom | What to check |
| --- | --- |
| Camera shots are skipped | the log says why; `camera.backend`, ProtocolLib installed, `limits.max-camera-sessions`, `camera.max-distance` |
| A scene does not start | `/scene list` (is it enabled?); `once-per-player` scenes only play once, use `/scene reset`; cooldown; priority of the scene already running |
| First-join scene never plays | with AuthMe it waits for login; check `integrations.authme` and the `[Scenes] Join hooks ready` line |
| RTP animation is skipped | the command must be in `rtp.commands` and the player must be allowed to use it; check the RTP scene is enabled |
| Screen stays dark | `/scene stop <player>`; the blindness effect lasts at most about two seconds after the scene ends |
