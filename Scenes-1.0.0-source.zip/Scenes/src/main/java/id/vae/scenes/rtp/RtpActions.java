package id.vae.scenes.rtp;

import id.vae.scenes.scene.ActionContext;
import id.vae.scenes.scene.ActionDefinition;
import id.vae.scenes.scene.ActionHandler;
import id.vae.scenes.scene.ActionHandlers;
import id.vae.scenes.scene.ActionRegistry;
import id.vae.scenes.scene.ActionResult;
import id.vae.scenes.scene.ConfigValues;

import java.util.List;
import java.util.UUID;

/**
 * RTP_EXECUTE: runs the held-back RTP command and pauses the scene until the teleport succeeds or fails.
 * It stores {@code rtp.result} (SUCCESS or FAILED) for BRANCH conditions. If the teleport takes longer than
 * {@code timeout-ms} (default: the hook's timeout) the scene is aborted and everything is restored.
 */
public final class RtpActions {

    public static final String RESULT_KEY = "rtp.result";
    private static final String CLEANUP_KEY = "rtp.cleanup";

    private RtpActions() {
    }

    public static void registerAll(ActionRegistry registry, RtpControl control) {
        registry.register(new Execute(control));
    }

    private static final class Execute implements ActionHandler {
        private final RtpControl control;

        Execute(RtpControl control) {
            this.control = control;
        }

        @Override
        public String type() {
            return "RTP_EXECUTE";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            return ConfigValues.longValue(action.config(), "timeout-ms", 1000) <= 0
                    ? List.of("'timeout-ms' must be greater than 0")
                    : List.of();
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            UUID player = ctx.player();
            ActionHandlers.cleanupOnce(ctx, CLEANUP_KEY, () -> control.finish(player));
            if (!control.execute(player)) {
                ctx.variables().put(RESULT_KEY, "FAILED");
                return ActionResult.done();
            }
            long timeout = ConfigValues.longValue(action.config(), "timeout-ms", control.timeoutMillis());
            return ActionResult.waitFor(() -> {
                RtpControl.Status status = control.status(player);
                if (status == RtpControl.Status.SUCCEEDED) {
                    ctx.variables().put(RESULT_KEY, "SUCCESS");
                    return true;
                }
                if (status == RtpControl.Status.FAILED || status == RtpControl.Status.NONE) {
                    ctx.variables().put(RESULT_KEY, "FAILED");
                    return true;
                }
                return false;
            }, timeout, 50, true);
        }
    }
}
