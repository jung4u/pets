package id.vae.scenes.subtitle;

import id.vae.scenes.core.Service;
import id.vae.scenes.scene.SceneScheduler;
import id.vae.scenes.sound.SoundControl;
import id.vae.scenes.sound.SoundSpec;
import id.vae.scenes.util.ScenesLogger;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Schedules and arbitrates subtitles. Each area (title area or action bar) shows one subtitle at a
 * time; a lower-priority subtitle never replaces a higher-priority one that is still showing.
 * Main thread only.
 */
public final class SubtitleService implements Service, SubtitleControl {

    private record Active(int priority, long endsAt) {
    }

    private static final class State {
        final List<SceneScheduler.Task> tasks = new ArrayList<>();
        final Map<SubtitlePosition, Active> active = new EnumMap<>(SubtitlePosition.class);
    }

    private final SubtitleDisplay display;
    private final PlaceholderResolver placeholders;
    private final SoundControl sounds;
    private final SceneScheduler scheduler;
    private final ScenesLogger log;
    private final Map<UUID, State> states = new HashMap<>();

    public SubtitleService(SubtitleDisplay display, PlaceholderResolver placeholders, SoundControl sounds,
                           SceneScheduler scheduler, ScenesLogger log) {
        this.display = display;
        this.placeholders = placeholders;
        this.sounds = sounds;
        this.scheduler = scheduler;
        this.log = log;
    }

    @Override
    public String name() {
        return "subtitle";
    }

    @Override
    public void start() {
        // Nothing to start.
    }

    @Override
    public void stop() {
        for (UUID player : new ArrayList<>(states.keySet())) {
            clear(player);
        }
    }

    @Override
    public void show(UUID player, SubtitleSpec spec) {
        if (!spec.enabled()) {
            return;
        }
        State state = states.computeIfAbsent(player, k -> new State());
        for (int i = 0; i <= spec.repeat(); i++) {
            long at = spec.delayMillis() + i * Math.max(spec.repeatIntervalMillis(), spec.durationMillis());
            schedule(state, at, () -> present(player, spec, state));
        }
    }

    @Override
    public void queue(UUID player, List<SubtitleSpec> lines) {
        State state = states.computeIfAbsent(player, k -> new State());
        List<SubtitleSpec> ordered = lines.stream().filter(SubtitleSpec::enabled)
                .sorted(Comparator.comparingInt(SubtitleSpec::order)).toList();
        long cursor = 0;
        for (SubtitleSpec line : ordered) {
            cursor += line.delayMillis();
            for (int i = 0; i <= line.repeat(); i++) {
                long at = cursor;
                schedule(state, at, () -> present(player, line, state));
                cursor += Math.max(line.repeatIntervalMillis(), line.durationMillis());
            }
        }
    }

    @Override
    public void hide(UUID player) {
        State state = states.get(player);
        if (state != null) {
            state.active.clear();
        }
        display.hide(player, null);
    }

    @Override
    public void clear(UUID player) {
        State state = states.remove(player);
        if (state != null) {
            state.tasks.forEach(SceneScheduler.Task::cancel);
        }
        display.hide(player, null);
    }

    private void schedule(State state, long delayMillis, Runnable action) {
        if (delayMillis <= 0) {
            action.run();
        } else {
            state.tasks.add(scheduler.runLater(delayMillis, action));
        }
    }

    private void present(UUID player, SubtitleSpec spec, State state) {
        long now = scheduler.nowMillis();
        SubtitlePosition area = spec.position().sharesTitleArea() ? SubtitlePosition.CENTER : SubtitlePosition.BOTTOM;
        Active current = state.active.get(area);
        if (current != null && now < current.endsAt() && current.priority() > spec.priority()) {
            log.debug("Subtitle dropped: a higher-priority subtitle is showing.");
            return;
        }
        try {
            String text = SubtitleFormatter.toMiniMessage(spec, placeholders.apply(player, spec.text()));
            long fadeIn = Math.min(spec.fadeInMillis(), spec.durationMillis());
            long fadeOut = Math.min(spec.fadeOutMillis(), Math.max(0, spec.durationMillis() - fadeIn));
            long stay = Math.max(0, spec.durationMillis() - fadeIn - fadeOut);
            display.show(player, spec.position(), text, fadeIn, stay, fadeOut);
            state.active.put(area, new Active(spec.priority(), now + spec.durationMillis()));
            if (!spec.soundKey().isBlank()) {
                sounds.play(player, SoundSpec.simple(spec.soundKey(), spec.volume(), spec.pitch()));
            }
        } catch (RuntimeException e) {
            log.error("Could not show a subtitle", e);
        }
    }
}
