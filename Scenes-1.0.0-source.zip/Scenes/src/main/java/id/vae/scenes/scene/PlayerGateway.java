package id.vae.scenes.scene;

import java.util.UUID;

/** Read-only view of online players, so the scene logic does not depend on Bukkit. */
public interface PlayerGateway {

    boolean isOnline(UUID player);

    boolean hasPermission(UUID player, String permission);

    /** World name of the player, or null when offline. */
    String worldOf(UUID player);

    /** Player name, or null when offline. */
    String nameOf(UUID player);
}
