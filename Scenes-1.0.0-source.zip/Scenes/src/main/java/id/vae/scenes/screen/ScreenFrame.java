package id.vae.scenes.screen;

/**
 * What the screen should look like at one moment, each channel from 0 (off) to 1 (full).
 *
 * @param black    full black screen
 * @param darkness vanilla darkness effect
 * @param vignette darkened edges (simulated)
 * @param blur     wobbling blur (simulated)
 * @param flash    one-shot white flash
 */
public record ScreenFrame(double black, double darkness, double vignette, double blur, double flash) {

    public static final ScreenFrame ZERO = new ScreenFrame(0, 0, 0, 0, 0);

    /** The strongest value of each channel, used when several effects run at once. */
    public static ScreenFrame max(ScreenFrame a, ScreenFrame b) {
        return new ScreenFrame(Math.max(a.black, b.black), Math.max(a.darkness, b.darkness),
                Math.max(a.vignette, b.vignette), Math.max(a.blur, b.blur), Math.max(a.flash, b.flash));
    }

    public boolean isZero() {
        return black <= 0 && darkness <= 0 && vignette <= 0 && blur <= 0 && flash <= 0;
    }
}
