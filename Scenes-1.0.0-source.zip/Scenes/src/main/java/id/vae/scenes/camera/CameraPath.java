package id.vae.scenes.camera;

import java.util.List;

/**
 * A multi-waypoint camera path. Timeline: hold at the first waypoint, then for each next waypoint
 * travel (its duration, its easing) and hold (its pause). With {@code smooth} the positions follow a
 * Catmull-Rom spline through the waypoints instead of straight lines.
 */
public final class CameraPath implements PoseSource {

    private final List<Waypoint> waypoints;
    private final boolean smooth;
    private final long[] travelEnd;
    private final long[] holdEnd;
    private final long total;

    public CameraPath(List<Waypoint> waypoints, boolean smooth) {
        if (waypoints.isEmpty()) {
            throw new IllegalArgumentException("A camera path needs at least one waypoint");
        }
        this.waypoints = List.copyOf(waypoints);
        this.smooth = smooth;
        int n = this.waypoints.size();
        travelEnd = new long[n];
        holdEnd = new long[n];
        long cursor = this.waypoints.get(0).pauseMillis();
        holdEnd[0] = cursor;
        for (int i = 1; i < n; i++) {
            cursor += this.waypoints.get(i).durationMillis();
            travelEnd[i] = cursor;
            cursor += this.waypoints.get(i).pauseMillis();
            holdEnd[i] = cursor;
        }
        total = cursor;
    }

    public List<Waypoint> waypoints() {
        return waypoints;
    }

    @Override
    public long durationMillis() {
        return total;
    }

    @Override
    public CameraPose poseAt(long elapsedMillis) {
        long t = Math.max(0, elapsedMillis);
        if (t < holdEnd[0]) {
            return waypoints.get(0).resolved();
        }
        for (int i = 1; i < waypoints.size(); i++) {
            if (t < travelEnd[i]) {
                long start = holdEnd[i - 1];
                double fraction = (double) (t - start) / (travelEnd[i] - start);
                return segment(i, fraction);
            }
            if (t < holdEnd[i]) {
                return waypoints.get(i).resolved();
            }
        }
        return waypoints.get(waypoints.size() - 1).resolved();
    }

    private CameraPose segment(int to, double fraction) {
        Waypoint a = waypoints.get(to - 1);
        Waypoint b = waypoints.get(to);
        double e = b.easing().apply(fraction);

        Vec3 position;
        if (smooth) {
            Vec3 before = waypoints.get(Math.max(0, to - 2)).position();
            Vec3 after = waypoints.get(Math.min(waypoints.size() - 1, to + 1)).position();
            position = catmullRom(before, a.position(), b.position(), after, e);
        } else {
            position = Vec3.lerp(a.position(), b.position(), e);
        }

        if (a.lookAt() != null && b.lookAt() != null) {
            return CameraPose.lookAt(position, Vec3.lerp(a.lookAt(), b.lookAt(), e));
        }
        CameraPose from = a.resolved();
        CameraPose target = b.resolved();
        return new CameraPose(position.x(), position.y(), position.z(),
                CameraPose.lerpAngle(from.yaw(), target.yaw(), e),
                (float) (from.pitch() + (target.pitch() - from.pitch()) * e));
    }

    private static Vec3 catmullRom(Vec3 p0, Vec3 p1, Vec3 p2, Vec3 p3, double t) {
        return new Vec3(spline(p0.x(), p1.x(), p2.x(), p3.x(), t),
                spline(p0.y(), p1.y(), p2.y(), p3.y(), t),
                spline(p0.z(), p1.z(), p2.z(), p3.z(), t));
    }

    private static double spline(double p0, double p1, double p2, double p3, double t) {
        double t2 = t * t;
        double t3 = t2 * t;
        return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2
                + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
    }
}
