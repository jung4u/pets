package id.vae.scenes.bukkit;

import id.vae.scenes.particle.ParticleCall;
import id.vae.scenes.particle.ParticleOutput;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Spawns particles for one player, or for everyone nearby. An unknown particle type throws, which
 * makes the particle service log it and stop that effect instead of failing every emission.
 */
public final class BukkitParticleOutput implements ParticleOutput {

    private static final String DEFAULT_DUST = "#a855f7";

    @Override
    public void spawn(UUID id, ParticleCall call, boolean nearby) {
        Player player = Bukkit.getPlayer(id);
        if (player == null) {
            return;
        }
        Particle particle;
        try {
            particle = Particle.valueOf(call.type());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Unknown particle type '" + call.type() + "'", e);
        }
        Object data = switch (call.type()) {
            case "DUST" -> new Particle.DustOptions(color(call.color(), DEFAULT_DUST), 1.0f);
            case "ENTITY_EFFECT" -> color(call.color(), "#ffffff");
            default -> null;
        };
        if (nearby) {
            player.getWorld().spawnParticle(particle, call.x(), call.y(), call.z(), call.count(), call.offsetX(),
                    call.offsetY(), call.offsetZ(), call.speed(), data);
        } else {
            player.spawnParticle(particle, call.x(), call.y(), call.z(), call.count(), call.offsetX(),
                    call.offsetY(), call.offsetZ(), call.speed(), data);
        }
    }

    private static Color color(String hex, String fallback) {
        String value = hex == null || hex.isBlank() ? fallback : hex;
        return Color.fromRGB(Integer.parseInt(value.replace("#", ""), 16));
    }
}
