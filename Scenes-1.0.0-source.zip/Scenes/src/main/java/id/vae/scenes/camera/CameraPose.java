package id.vae.scenes.camera;

/** Camera position and orientation using Minecraft conventions (yaw 0 faces +Z, pitch positive looks down). */
public record CameraPose(double x, double y, double z, float yaw, float pitch) {

    public Vec3 position() {
        return new Vec3(x, y, z);
    }

    public CameraPose withPosition(Vec3 p) {
        return new CameraPose(p.x(), p.y(), p.z(), yaw, pitch);
    }

    /** A pose at {@code from} that faces {@code target}. */
    public static CameraPose lookAt(Vec3 from, Vec3 target) {
        double dx = target.x() - from.x();
        double dy = target.y() - from.y();
        double dz = target.z() - from.z();
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return new CameraPose(from.x(), from.y(), from.z(), yaw, pitch);
    }

    /** Interpolates angles along the shortest turn. */
    public static float lerpAngle(float from, float to, double t) {
        double delta = ((to - from + 540.0) % 360.0) - 180.0;
        return (float) (from + delta * t);
    }

    public CameraPose lerp(CameraPose o, double t) {
        return new CameraPose(x + (o.x - x) * t, y + (o.y - y) * t, z + (o.z - z) * t,
                lerpAngle(yaw, o.yaw, t), (float) (pitch + (o.pitch - pitch) * t));
    }
}
