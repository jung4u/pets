package id.vae.scenes.rtp;

import id.vae.scenes.scene.EngineHarness;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static id.vae.scenes.scene.TestSupport.action;
import static id.vae.scenes.scene.TestSupport.mark;
import static id.vae.scenes.scene.TestSupport.scene;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RtpActionsTest {

    private static final class FakeRtp implements RtpControl {
        final Map<UUID, Status> statuses = new HashMap<>();
        boolean canExecute = true;
        int executed;
        int finished;

        @Override
        public Status status(UUID player) {
            return statuses.getOrDefault(player, Status.NONE);
        }

        @Override
        public boolean execute(UUID player) {
            if (!canExecute) {
                return false;
            }
            executed++;
            statuses.put(player, Status.EXECUTING);
            return true;
        }

        @Override
        public void finish(UUID player) {
            finished++;
            statuses.remove(player);
        }

        @Override
        public long timeoutMillis() {
            return 15_000;
        }
    }

    private EngineHarness h;
    private FakeRtp rtp;

    @BeforeEach
    void setUp() {
        h = new EngineHarness();
        rtp = new FakeRtp();
        RtpActions.registerAll(h.registry, rtp);
    }

    private static Map<String, Object> failedBranch() {
        return Map.of("condition", Map.of("type", "VARIABLE_EQUALS", "key", "rtp.result", "value", "FAILED"),
                "then-end", true);
    }

    @Test
    void sceneWaitsForTheTeleportThenContinues() {
        h.run(scene("rtp", 0, action("go", "RTP_EXECUTE", 0, 0, Map.of()), mark("after", 100)));

        h.clock.advance(300);
        assertTrue(h.events.isEmpty());
        assertEquals(1, rtp.executed);

        rtp.statuses.put(h.alice, RtpControl.Status.SUCCEEDED);
        h.clock.advance(50);
        h.clock.advance(100);

        assertEquals(1, h.events.size());
        assertTrue(h.events.get(0).startsWith("after@"));
        assertFalse(h.engine.isRunning(h.alice));
        assertEquals(1, rtp.finished);
    }

    @Test
    void aFailedTeleportEndsTheSceneBeforeTheFinishingAnimation() {
        h.run(scene("rtp", 0, action("go", "RTP_EXECUTE", 0, 0, Map.of()),
                action("failed", "BRANCH", 0, 0, failedBranch()), mark("never", 100)));

        rtp.statuses.put(h.alice, RtpControl.Status.FAILED);
        h.clock.advance(1000);

        assertTrue(h.events.isEmpty());
        assertFalse(h.engine.isRunning(h.alice));
        assertEquals(1, rtp.finished);
    }

    @Test
    void aSuccessfulTeleportPassesTheBranch() {
        h.run(scene("rtp", 0, action("go", "RTP_EXECUTE", 0, 0, Map.of()),
                action("failed", "BRANCH", 0, 0, failedBranch()), mark("arrived", 100)));

        rtp.statuses.put(h.alice, RtpControl.Status.SUCCEEDED);
        h.clock.advance(1000);

        assertEquals(1, h.events.size());
    }

    @Test
    void aTeleportThatNeverHappensAbortsTheSceneAndCleansUp() {
        h.run(scene("rtp", 0, action("go", "RTP_EXECUTE", 0, 0, Map.of("timeout-ms", 500)), mark("never", 100)));

        h.clock.advance(5000);

        assertTrue(h.events.isEmpty());
        assertFalse(h.engine.isRunning(h.alice));
        assertEquals(1, rtp.finished);
    }

    @Test
    void whenThereIsNothingToExecuteTheResultIsFailed() {
        rtp.canExecute = false;
        h.run(scene("rtp", 0, action("go", "RTP_EXECUTE", 0, 0, Map.of()),
                action("failed", "BRANCH", 0, 0, failedBranch()), mark("never", 100)));

        h.clock.advance(1000);

        assertTrue(h.events.isEmpty());
        assertFalse(h.engine.isRunning(h.alice));
    }

    @Test
    void cancellingTheSceneWhileWaitingForgetsTheRequest() {
        h.run(scene("rtp", 0, action("go", "RTP_EXECUTE", 0, 0, Map.of())));

        h.engine.stop(h.alice, "test");

        assertEquals(1, rtp.finished);
    }

    @Test
    void validationRejectsANonPositiveTimeout() {
        assertTrue(h.errors(action("go", "RTP_EXECUTE", 0, 0, Map.of("timeout-ms", 0))).contains("timeout-ms"));
        assertEquals("", h.errors(action("go", "RTP_EXECUTE", 0, 0, Map.of())));
    }
}
