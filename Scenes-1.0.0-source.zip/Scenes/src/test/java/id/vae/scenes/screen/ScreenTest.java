package id.vae.scenes.screen;

import id.vae.scenes.camera.FakeCameraControl;
import id.vae.scenes.scene.EngineHarness;
import id.vae.scenes.scene.SceneEngine;
import id.vae.scenes.util.Easing;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static id.vae.scenes.scene.TestSupport.action;
import static id.vae.scenes.scene.TestSupport.scene;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScreenTest {

    private static final class FakeScreen implements ScreenControl {
        final List<ScreenPlan> plans = new ArrayList<>();
        int clears;

        @Override
        public void play(UUID player, ScreenPlan plan) {
            plans.add(plan);
        }

        @Override
        public void clear(UUID player) {
            clears++;
        }
    }

    private EngineHarness h;
    private FakeScreen screen;
    private FakeCameraControl camera;

    @BeforeEach
    void setUp() {
        h = new EngineHarness();
        screen = new FakeScreen();
        camera = new FakeCameraControl();
        ScreenActions.registerAll(h.registry, screen, camera);
    }

    private static ScreenPlan plan(ScreenEffectType type, long duration, double intensity, int repeat, long gap,
                                   boolean hold) {
        return ScreenPlans.create(type, duration, intensity, Easing.LINEAR, repeat, gap, hold);
    }

    private static int peaks(ScreenPlan plan, long length) {
        int peaks = 0;
        boolean high = false;
        for (long t = 0; t <= length; t += 10) {
            boolean now = plan.frameAt(t).black() >= 0.99;
            if (now && !high) {
                peaks++;
            }
            high = now;
        }
        return peaks;
    }

    @Test
    void effectsAreSortedIntoChannelsSoTheyCanRunTogether() {
        assertEquals(ScreenChannel.BLACK, plan(ScreenEffectType.FADE_OUT, 100, 1, 1, 0, true).channel());
        assertEquals(ScreenChannel.BLACK, plan(ScreenEffectType.EYE_OPEN, 100, 1, 1, 0, false).channel());
        assertEquals(ScreenChannel.BLACK, plan(ScreenEffectType.TRIPLE_BLINK, 100, 1, 1, 0, false).channel());
        assertEquals(ScreenChannel.BLUR, plan(ScreenEffectType.BLUR, 100, 1, 1, 0, false).channel());
        assertEquals(ScreenChannel.VIGNETTE, plan(ScreenEffectType.VIGNETTE, 100, 1, 1, 0, false).channel());
        assertEquals(ScreenChannel.DARKNESS, plan(ScreenEffectType.DARKNESS, 100, 1, 1, 0, false).channel());
        assertEquals(ScreenChannel.FLASH, plan(ScreenEffectType.FLASH, 100, 1, 1, 0, false).channel());
    }

    @Test
    void framesMergeByTakingTheStrongestChannelValues() {
        ScreenFrame merged = ScreenFrame.max(new ScreenFrame(0.2, 0, 0.9, 0, 0), new ScreenFrame(0.7, 0.1, 0.3, 0.5, 0));

        assertEquals(new ScreenFrame(0.7, 0.1, 0.9, 0.5, 0), merged);
    }

    @Test
    void fadeOutRisesToBlackAndHolds() {
        ScreenPlan plan = plan(ScreenEffectType.FADE_OUT, 1000, 1, 1, 0, true);

        assertEquals(0.0, plan.frameAt(0).black(), 1e-9);
        assertEquals(0.5, plan.frameAt(500).black(), 1e-9);
        assertEquals(1.0, plan.frameAt(1000).black(), 1e-9);
        assertEquals(1.0, plan.frameAt(99_999).black(), 1e-9);
    }

    @Test
    void fadeInStartsBlackAndEndsClear() {
        ScreenPlan plan = plan(ScreenEffectType.FADE_IN, 1000, 1, 1, 0, false);

        assertEquals(1.0, plan.frameAt(0).black(), 1e-9);
        assertEquals(0.5, plan.frameAt(500).black(), 1e-9);
        assertTrue(plan.frameAt(1000).isZero());
    }

    @Test
    void blinkCountsMatchAndTheScreenEndsOpen() {
        assertEquals(1, peaks(plan(ScreenEffectType.BLINK, 1000, 1, 1, 0, false), 990));
        assertEquals(2, peaks(plan(ScreenEffectType.DOUBLE_BLINK, 1000, 1, 1, 0, false), 990));
        assertEquals(3, peaks(plan(ScreenEffectType.TRIPLE_BLINK, 1500, 1, 1, 0, false), 1490));
        assertTrue(plan(ScreenEffectType.DOUBLE_BLINK, 1000, 1, 1, 0, false).frameAt(1000).isZero());
        assertEquals(0.0, plan(ScreenEffectType.DOUBLE_BLINK, 1000, 1, 1, 0, false).frameAt(999).black(), 1e-9);
    }

    @Test
    void intensityScalesTheEffect() {
        ScreenPlan plan = plan(ScreenEffectType.BLACK_SCREEN, 500, 0.4, 1, 0, false);

        assertEquals(0.4, plan.frameAt(100).black(), 1e-9);
    }

    @Test
    void repeatsRunWithAGapBetweenThem() {
        ScreenPlan plan = plan(ScreenEffectType.BLACK_SCREEN, 100, 1, 3, 100, false);

        assertEquals(500, plan.durationMillis());
        assertEquals(1.0, plan.frameAt(50).black(), 1e-9);
        assertTrue(plan.frameAt(150).isZero());
        assertEquals(1.0, plan.frameAt(250).black(), 1e-9);
        assertEquals(1.0, plan.frameAt(450).black(), 1e-9);
        assertTrue(plan.frameAt(500).isZero());
    }

    @Test
    void flashIsABriefOneShot() {
        ScreenPlan plan = plan(ScreenEffectType.FLASH, 0, 1, 1, 0, false);

        assertEquals(1.0, plan.frameAt(0).flash(), 1e-9);
        assertEquals(0.0, plan.frameAt(150).flash(), 1e-9);
        assertTrue(plan.durationMillis() >= 100);
    }

    @Test
    void eyeClosingEndsFullyClosedAndOpeningEndsClear() {
        ScreenPlan close = plan(ScreenEffectType.EYE_CLOSE, 1000, 1, 1, 0, true);
        ScreenPlan open = plan(ScreenEffectType.EYE_OPEN, 1000, 1, 1, 0, false);

        assertEquals(1.0, close.frameAt(5000).black(), 1e-9);
        assertEquals(1.0, close.frameAt(5000).vignette(), 1e-9);
        assertEquals(1.0, open.frameAt(0).black(), 1e-9);
        assertTrue(open.frameAt(1000).isZero());
    }

    @Test
    void blurAndVignetteRiseHoldAndFall() {
        ScreenPlan blur = plan(ScreenEffectType.BLUR, 1000, 1, 1, 0, false);
        ScreenPlan vignette = plan(ScreenEffectType.VIGNETTE, 1000, 1, 1, 0, false);

        assertEquals(0.0, blur.frameAt(0).blur(), 1e-9);
        assertEquals(1.0, blur.frameAt(500).blur(), 1e-9);
        assertTrue(blur.frameAt(990).blur() < 0.1);
        assertEquals(1.0, vignette.frameAt(500).vignette(), 1e-9);
    }

    @Test
    void fadeActionPlaysAHeldPlanAndClearsWhenTheSceneIsCancelled() {
        assertEquals(SceneEngine.StartResult.STARTED, h.run(scene("intro", 0,
                action("fade", "SCREEN_FADE", 0, 2000, Map.of("direction", "OUT")))));

        assertEquals(1, screen.plans.size());
        assertTrue(screen.plans.get(0).holdsFinalFrame());
        assertEquals(2000, screen.plans.get(0).durationMillis());

        h.engine.stop(h.alice, "test");
        assertEquals(1, screen.clears);
    }

    @Test
    void fadeInDoesNotHoldAndSpeedShortensTheEffect() {
        h.run(scene("intro", 0, action("fade", "SCREEN_FADE", 0, 2000, Map.of("direction", "IN", "speed", 2.0))));

        assertFalse(screen.plans.get(0).holdsFinalFrame());
        assertEquals(1000, screen.plans.get(0).durationMillis());
    }

    @Test
    void flashColorIsPassedToThePlan() {
        h.run(scene("intro", 0, action("flash", "SCREEN_FLASH", 0, 0, Map.of("color", "FFAA00"))));

        assertEquals("#ffaa00", screen.plans.get(0).flashColor());
    }

    @Test
    void blinkCountSelectsTheEffect() {
        h.run(scene("intro", 0, action("blink", "SCREEN_BLINK", 0, 1000, Map.of("count", 2))));

        assertEquals(2, peaks(screen.plans.get(0), 990));
    }

    @Test
    void screenShakeUsesTheCamera() {
        h.run(scene("intro", 0, action("shake", "SCREEN_SHAKE", 0, 800, Map.of("intensity", 1.5))));

        assertEquals(List.of("begin", "shake"), camera.calls);
    }

    @Test
    void sceneCancellationEndsTheShakeCamera() {
        h.run(scene("intro", 0, action("shake", "SCREEN_SHAKE", 0, 800, Map.of())));
        h.engine.stop(h.alice, "test");

        assertFalse(camera.isActive(h.alice));
    }

    @Test
    void validationReportsBadSettings() {
        assertTrue(h.errors(action("a", "SCREEN_BLINK", 0, 1000, Map.of("count", 5))).contains("count"));
        assertTrue(h.errors(action("a", "SCREEN_FADE", 0, 1000, Map.of("direction", "SIDEWAYS"))).contains("direction"));
        assertTrue(h.errors(action("a", "SCREEN_EYE", 0, 1000, Map.of("state", "HALF"))).contains("state"));
        assertTrue(h.errors(action("a", "SCREEN_BLUR", 0, 1000, Map.of("intensity", 2.0))).contains("intensity"));
        assertTrue(h.errors(action("a", "SCREEN_BLUR", 0, 1000, Map.of("repeat", 0))).contains("repeat"));
        assertTrue(h.errors(action("a", "SCREEN_BLUR", 0, 1000, Map.of("speed", 0))).contains("speed"));
        assertTrue(h.errors(action("a", "SCREEN_FLASH", 0, 0, Map.of("color", "nothex"))).contains("color"));
        assertTrue(h.errors(action("a", "SCREEN_FADE", 0, 0, Map.of())).contains("duration"));
        assertEquals("", h.errors(action("a", "SCREEN_FLASH", 0, 0, Map.of())));
        assertEquals("", h.errors(action("a", "SCREEN_FADE", 0, 1000, Map.of("direction", "in"))));
        assertEquals("", h.errors(action("a", "SCREEN_CLEAR", 0, 0, Map.of())));
    }
}
