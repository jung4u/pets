package id.vae.scenes.scene;

import java.util.Comparator;
import java.util.List;

/**
 * An immutable scene. Edits create a new instance, so a running scene is never
 * changed underneath itself.
 *
 * @param durationMillis minimum total length; the scene ends at the later of this
 *                       and the end of its last action
 */
public record SceneDefinition(
        String id,
        String name,
        String description,
        boolean enabled,
        TriggerSpec trigger,
        int priority,
        long cooldownMillis,
        long durationMillis,
        List<ConditionSpec> conditions,
        List<ActionDefinition> actions) {

    public SceneDefinition {
        id = id == null ? "" : id.trim();
        name = name == null ? "" : name.trim();
        description = description == null ? "" : description;
        trigger = trigger == null ? TriggerSpec.manual() : trigger;
        conditions = conditions == null ? List.of() : List.copyOf(conditions);
        actions = actions == null ? List.of()
                : actions.stream().sorted(Comparator.comparingInt(ActionDefinition::order)).toList();
    }

    public SceneDefinition withId(String newId) {
        return new SceneDefinition(newId, name, description, enabled, trigger, priority, cooldownMillis,
                durationMillis, conditions, actions);
    }

    public SceneDefinition withName(String newName) {
        return new SceneDefinition(id, newName, description, enabled, trigger, priority, cooldownMillis,
                durationMillis, conditions, actions);
    }

    public SceneDefinition withEnabled(boolean newEnabled) {
        return new SceneDefinition(id, name, description, newEnabled, trigger, priority, cooldownMillis,
                durationMillis, conditions, actions);
    }

    public SceneDefinition withPriority(int newPriority) {
        return new SceneDefinition(id, name, description, enabled, trigger, newPriority, cooldownMillis,
                durationMillis, conditions, actions);
    }

    public SceneDefinition withTrigger(TriggerSpec newTrigger) {
        return new SceneDefinition(id, name, description, enabled, newTrigger, priority, cooldownMillis,
                durationMillis, conditions, actions);
    }

    public SceneDefinition withCooldown(long newCooldownMillis) {
        return new SceneDefinition(id, name, description, enabled, trigger, priority, newCooldownMillis,
                durationMillis, conditions, actions);
    }

    public SceneDefinition withActions(List<ActionDefinition> newActions) {
        return new SceneDefinition(id, name, description, enabled, trigger, priority, cooldownMillis,
                durationMillis, conditions, newActions);
    }
}
