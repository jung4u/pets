package id.vae.scenes.scene;

import java.util.UUID;

/** Remembers which scenes a player has completed. */
public interface ProgressTracker {

    boolean hasCompleted(UUID player, String sceneId);

    void recordCompleted(UUID player, String sceneId);
}
