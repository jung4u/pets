package id.vae.scenes.scene;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Evaluates conditions. Supported types: PERMISSION (permission), WORLD (world),
 * VARIABLE_EQUALS (key, value) and PLAYER_ONLINE. Any condition accepts
 * {@code negate: true}.
 */
public final class ConditionEvaluator {

    public static final Set<String> TYPES = Set.of("PERMISSION", "WORLD", "VARIABLE_EQUALS", "PLAYER_ONLINE");

    private final PlayerGateway players;

    public ConditionEvaluator(PlayerGateway players) {
        this.players = players;
    }

    public boolean allMatch(List<ConditionSpec> conditions, UUID player, Map<String, Object> variables) {
        for (ConditionSpec condition : conditions) {
            if (!matches(condition, player, variables)) {
                return false;
            }
        }
        return true;
    }

    public boolean matches(ConditionSpec condition, UUID player, Map<String, Object> variables) {
        boolean result = switch (condition.type()) {
            case "PERMISSION" -> players.hasPermission(player,
                    ConfigValues.string(condition.params(), "permission", ""));
            case "WORLD" -> {
                String world = players.worldOf(player);
                yield world != null && world.equalsIgnoreCase(ConfigValues.string(condition.params(), "world", ""));
            }
            case "VARIABLE_EQUALS" -> {
                Object actual = variables.get(ConfigValues.string(condition.params(), "key", ""));
                yield actual != null
                        && String.valueOf(actual).equals(ConfigValues.string(condition.params(), "value", ""));
            }
            case "PLAYER_ONLINE" -> players.isOnline(player);
            default -> false;
        };
        return ConfigValues.bool(condition.params(), "negate", false) != result;
    }

    /** Returns problems with the condition; empty when it is valid. */
    public List<String> validate(ConditionSpec condition) {
        List<String> errors = new ArrayList<>();
        if (!TYPES.contains(condition.type())) {
            errors.add("unknown condition type '" + condition.type().toLowerCase(Locale.ROOT) + "'");
            return errors;
        }
        Map<String, Object> p = condition.params();
        switch (condition.type()) {
            case "PERMISSION" -> {
                if (ConfigValues.string(p, "permission", "").isBlank()) {
                    errors.add("PERMISSION condition needs 'permission'");
                }
            }
            case "WORLD" -> {
                if (ConfigValues.string(p, "world", "").isBlank()) {
                    errors.add("WORLD condition needs 'world'");
                }
            }
            case "VARIABLE_EQUALS" -> {
                if (ConfigValues.string(p, "key", "").isBlank()) {
                    errors.add("VARIABLE_EQUALS condition needs 'key'");
                }
            }
            default -> { }
        }
        return errors;
    }
}
