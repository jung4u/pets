package id.vae.scenes.core;

import id.vae.scenes.config.ConfigService;
import id.vae.scenes.config.DatabaseSettings;
import id.vae.scenes.database.DatabaseManager;
import id.vae.scenes.util.ScenesLogger;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/** Scheduled database backups. Runs on its own thread and only while backups are enabled. */
public final class MaintenanceService implements Service {

    private final ConfigService config;
    private final DatabaseManager db;
    private final Path dataFolder;
    private final ScenesLogger log;
    private final List<ScheduledFuture<?>> tasks = new ArrayList<>();
    private ScheduledExecutorService scheduler;

    public MaintenanceService(ConfigService config, DatabaseManager db, Path dataFolder, ScenesLogger log) {
        this.config = config;
        this.db = db;
        this.dataFolder = dataFolder;
        this.log = log;
    }

    @Override
    public String name() {
        return "maintenance";
    }

    @Override
    public synchronized void start() {
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "Scenes-Maintenance");
            t.setDaemon(true);
            return t;
        });
        schedule(true);
    }

    /** Re-reads the backup settings (used after a reload). */
    public synchronized void reschedule() {
        if (scheduler == null) {
            return;
        }
        cancelTasks();
        schedule(false);
    }

    @Override
    public synchronized void stop() {
        cancelTasks();
        if (scheduler != null) {
            scheduler.shutdownNow();
            scheduler = null;
        }
    }

    private void schedule(boolean startup) {
        DatabaseSettings s = config.database();
        if (!s.backupEnabled()) {
            return;
        }
        long interval = s.backupIntervalMinutes();
        long initialDelay = (startup && s.backupOnStartup()) ? 0 : interval;
        tasks.add(scheduler.scheduleWithFixedDelay(this::backup, initialDelay, interval, TimeUnit.MINUTES));
    }

    private void cancelTasks() {
        for (ScheduledFuture<?> task : tasks) {
            task.cancel(false);
        }
        tasks.clear();
    }

    private void backup() {
        try {
            Path file = db.backup(dataFolder.resolve("backups"), config.database().backupKeep());
            log.info("Database backup created: " + file.getFileName());
        } catch (Exception e) {
            log.error("Database backup failed", e);
        }
    }
}
