package id.vae.scenes.database;

import id.vae.scenes.util.ScenesLogger;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.UUID;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ProgressRepositoryTest {

    private DatabaseManager db;
    private PlayerRepository players;
    private ProgressRepository progress;
    private final UUID alice = UUID.randomUUID();
    private final UUID bob = UUID.randomUUID();

    @BeforeEach
    void setUp() throws Exception {
        db = DatabaseManager.inMemory(new ScenesLogger(Logger.getLogger("test"), false));
        db.start();
        players = new PlayerRepository(db);
        progress = new ProgressRepository(db);
        players.upsert(alice, "Alice", 1L);
        players.upsert(bob, "Bob", 1L);
    }

    @AfterEach
    void tearDown() {
        db.stop();
    }

    @Test
    void playerUpsertUpdatesNameAndKeepsFirstSeen() throws Exception {
        players.upsert(alice, "AliceRenamed", 50L);

        PlayerRepository.PlayerRecord record = players.find(alice).orElseThrow();
        assertEquals("AliceRenamed", record.name());
        assertEquals(1L, record.firstSeen());
        assertEquals(50L, record.lastSeen());
    }

    @Test
    void sceneIsNotCompletedUntilMarked() throws Exception {
        assertFalse(progress.hasCompleted(alice, "first_join"));

        progress.markCompleted(alice, "first_join", 10L);

        assertTrue(progress.hasCompleted(alice, "first_join"));
        assertFalse(progress.hasCompleted(bob, "first_join"));
    }

    @Test
    void repeatedCompletionIncrementsCountAndKeepsFirstTimestamp() throws Exception {
        progress.markCompleted(alice, "first_join", 10L);
        progress.markCompleted(alice, "first_join", 20L);

        ProgressRepository.ProgressEntry entry = progress.forPlayer(alice).get(0);
        assertEquals(2, entry.completedCount());
        assertEquals(10L, entry.firstCompleted());
        assertEquals(20L, entry.lastPlayed());
        assertEquals(2, progress.totalCompleted(alice));
    }

    @Test
    void lastSceneIsTheMostRecentlyPlayed() throws Exception {
        progress.markCompleted(alice, "first_join", 10L);
        progress.markCompleted(alice, "nether", 30L);

        assertEquals("nether", progress.lastScene(alice).orElseThrow());
        assertTrue(progress.lastScene(bob).isEmpty());
    }

    @Test
    void resetOperationsOnlyAffectTheirScope() throws Exception {
        progress.markCompleted(alice, "first_join", 10L);
        progress.markCompleted(alice, "nether", 20L);
        progress.markCompleted(bob, "nether", 30L);

        assertEquals(1, progress.resetScene(alice, "nether"));
        assertTrue(progress.hasCompleted(alice, "first_join"));
        assertTrue(progress.hasCompleted(bob, "nether"));

        assertEquals(1, progress.resetPlayer(alice));
        assertFalse(progress.hasCompleted(alice, "first_join"));

        assertEquals(1, progress.resetSceneForAll("nether"));
        assertFalse(progress.hasCompleted(bob, "nether"));

        progress.markCompleted(bob, "the_end", 40L);
        assertEquals(1, progress.resetAll());
    }

    @Test
    void completingForUnknownPlayerCreatesPlaceholderRow() throws Exception {
        UUID stranger = UUID.randomUUID();

        progress.markCompleted(stranger, "death", 5L);

        assertTrue(progress.hasCompleted(stranger, "death"));
        assertTrue(players.find(stranger).isPresent());
    }
}
