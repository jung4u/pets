package id.vae.scenes.scene;

import id.vae.scenes.core.ServiceRegistry;
import id.vae.scenes.scene.TestSupport.FakePlayers;
import id.vae.scenes.scene.TestSupport.ManualScheduler;
import id.vae.scenes.scene.TestSupport.MapCatalog;
import id.vae.scenes.scene.TestSupport.Marker;
import id.vae.scenes.scene.TestSupport.MemoryProgress;
import id.vae.scenes.util.ScenesLogger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;

import static id.vae.scenes.scene.TestSupport.action;
import static id.vae.scenes.scene.TestSupport.mark;
import static id.vae.scenes.scene.TestSupport.scene;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SceneEngineTest {

    private final ScenesLogger log = new ScenesLogger(Logger.getLogger("test"), false);
    private ManualScheduler clock;
    private FakePlayers players;
    private MapCatalog catalog;
    private MemoryProgress progress;
    private List<String> events;
    private SceneEngine engine;
    private int maxConcurrent;
    private UUID alice;

    @BeforeEach
    void setUp() {
        clock = new ManualScheduler();
        players = new FakePlayers();
        catalog = new MapCatalog();
        progress = new MemoryProgress();
        events = new ArrayList<>();
        maxConcurrent = 10;
        ActionRegistry registry = new ActionRegistry();
        ControlActions.registerAll(registry);
        registry.register(new Marker(events, clock));
        engine = new SceneEngine(catalog, registry, clock, players, progress, new ServiceRegistry(log),
                new ConditionEvaluator(players), () -> maxConcurrent, log);
        alice = players.join("world");
    }

    @Test
    void actionsRunAtTheirOffsetsAndSceneCompletesAfterLastAction() {
        catalog.add(scene("intro", 0, mark("a", 0), mark("b", 500),
                action("c", "MARK", 1000, 500, Map.of())));

        assertEquals(SceneEngine.StartResult.STARTED, engine.start(alice, "intro", false));
        assertEquals(List.of("a@0"), events);

        clock.advance(500);
        assertEquals(List.of("a@0", "b@500"), events);

        clock.advance(500);
        assertEquals(List.of("a@0", "b@500", "c@1000"), events);
        assertTrue(engine.isRunning(alice));

        clock.advance(500);
        assertFalse(engine.isRunning(alice));
        assertTrue(progress.hasCompleted(alice, "intro"));
    }

    @Test
    void failingActionDoesNotStopTheScene() {
        catalog.add(scene("intro", 0, mark("a", 0),
                action("bad", "MARK", 100, 0, Map.of("fail", true)), mark("c", 200)));

        engine.start(alice, "intro", false);
        clock.advance(300);

        assertEquals(List.of("a@0", "c@200"), events);
        assertTrue(progress.hasCompleted(alice, "intro"));
    }

    @Test
    void delayActionPushesLaterActionsBack() {
        catalog.add(scene("intro", 0, mark("a", 0),
                action("pause", "DELAY", 100, 1000, Map.of()), mark("b", 500)));

        engine.start(alice, "intro", false);
        clock.advance(1499);
        assertEquals(List.of("a@0"), events);

        clock.advance(1);
        assertEquals(List.of("a@0", "b@1500"), events);
    }

    @Test
    void endSceneSkipsRemainingActionsButCountsAsCompleted() {
        catalog.add(scene("intro", 0, mark("a", 0), action("end", "END_SCENE", 200, 0, Map.of()),
                mark("never", 1000)));

        engine.start(alice, "intro", false);
        clock.advance(2000);

        assertEquals(List.of("a@0"), events);
        assertFalse(engine.isRunning(alice));
        assertTrue(progress.hasCompleted(alice, "intro"));
    }

    @Test
    void stoppingRunsCleanupAndDoesNotRecordProgress() {
        catalog.add(scene("intro", 0, action("cam", "MARK", 0, 0, Map.of("cleanup", true)), mark("later", 5000)));

        engine.start(alice, "intro", false);
        assertTrue(engine.stop(alice, "test"));
        clock.advance(6000);

        assertEquals(List.of("cam@0", "cleanup:cam"), events);
        assertFalse(progress.hasCompleted(alice, "intro"));
        assertFalse(engine.isRunning(alice));
    }

    @Test
    void waitForConditionResumesWhenConditionBecomesTrue() {
        Map<String, Object> condition = Map.of("type", "WORLD", "world", "nether");
        catalog.add(scene("intro", 0,
                action("wait", "WAIT_FOR_CONDITION", 0, 0, Map.of("condition", condition, "timeout-ms", 5000)),
                mark("b", 100)));

        engine.start(alice, "intro", false);
        clock.advance(300);
        assertTrue(events.isEmpty());

        players.worlds.put(alice, "nether");
        clock.advance(100);
        clock.advance(100);

        assertEquals(List.of("b@500"), events);
    }

    @Test
    void waitTimeoutCanAbortTheScene() {
        Map<String, Object> condition = Map.of("type", "WORLD", "world", "nether");
        catalog.add(scene("intro", 0,
                action("wait", "WAIT_FOR_CONDITION", 0, 0,
                        Map.of("condition", condition, "timeout-ms", 300, "on-timeout", "abort")),
                mark("b", 100)));

        engine.start(alice, "intro", false);
        clock.advance(1000);

        assertTrue(events.isEmpty());
        assertFalse(engine.isRunning(alice));
        assertFalse(progress.hasCompleted(alice, "intro"));
    }

    @Test
    void branchSkipsActionsWhenConditionMatches() {
        Map<String, Object> condition = Map.of("type", "WORLD", "world", "world");
        catalog.add(scene("intro", 0,
                action("branch", "BRANCH", 0, 0, Map.of("condition", condition, "then-skip", List.of("b"))),
                mark("b", 100), mark("c", 200)));

        engine.start(alice, "intro", false);
        clock.advance(300);

        assertEquals(List.of("c@200"), events);
    }

    @Test
    void playOnceScenesDoNotStartAgain() {
        SceneDefinition once = scene("intro", 0, mark("a", 0))
                .withTrigger(TriggerSpec.of(TriggerType.FIRST_JOIN, true));
        catalog.add(once);

        assertEquals(SceneEngine.StartResult.STARTED, engine.start(alice, "intro", false));
        clock.advance(10);
        assertEquals(SceneEngine.StartResult.ALREADY_PLAYED, engine.start(alice, "intro", false));
        assertEquals(SceneEngine.StartResult.STARTED, engine.start(alice, "intro", true));
    }

    @Test
    void cooldownBlocksUntilItExpires() {
        catalog.add(scene("intro", 0, mark("a", 0)).withCooldown(10_000));

        engine.start(alice, "intro", false);
        clock.advance(10);
        assertEquals(SceneEngine.StartResult.COOLDOWN, engine.start(alice, "intro", false));

        clock.advance(10_000);
        assertEquals(SceneEngine.StartResult.STARTED, engine.start(alice, "intro", false));
    }

    @Test
    void higherPriorityPreemptsAndEqualPriorityIsRejected() {
        catalog.add(scene("low", 1, action("cam", "MARK", 0, 0, Map.of("cleanup", true)), mark("x", 5000)));
        catalog.add(scene("high", 5, mark("h", 0), mark("y", 5000)));
        catalog.add(scene("same", 1, mark("s", 0)));

        engine.start(alice, "low", false);
        assertEquals(SceneEngine.StartResult.ALREADY_RUNNING, engine.start(alice, "same", false));
        assertEquals(SceneEngine.StartResult.STARTED, engine.start(alice, "high", false));

        assertEquals("high", engine.runningScene(alice).orElseThrow());
        assertTrue(events.contains("cleanup:cam"));
    }

    @Test
    void concurrentSceneLimitIsEnforced() {
        maxConcurrent = 1;
        UUID bob = players.join("world");
        catalog.add(scene("intro", 0, mark("a", 0), mark("b", 5000)));

        assertEquals(SceneEngine.StartResult.STARTED, engine.start(alice, "intro", false));
        assertEquals(SceneEngine.StartResult.LIMIT_REACHED, engine.start(bob, "intro", false));
    }

    @Test
    void rejectsUnknownDisabledOfflineAndFailedConditions() {
        catalog.add(scene("off", 0, mark("a", 0)).withEnabled(false));
        SceneDefinition guarded = new SceneDefinition("guarded", "guarded", "", true, TriggerSpec.manual(), 0, 0, 0,
                List.of(new ConditionSpec("PERMISSION", Map.of("permission", "vip"))),
                List.of(mark("a", 0)));
        catalog.add(guarded);

        assertEquals(SceneEngine.StartResult.UNKNOWN_SCENE, engine.start(alice, "nope", false));
        assertEquals(SceneEngine.StartResult.DISABLED, engine.start(alice, "off", false));
        assertEquals(SceneEngine.StartResult.CONDITIONS_FAILED, engine.start(alice, "guarded", false));
        assertEquals(SceneEngine.StartResult.PLAYER_OFFLINE, engine.start(UUID.randomUUID(), "guarded", true));
        assertEquals(SceneEngine.StartResult.STARTED, engine.start(alice, "off", true));
    }

    @Test
    void playerQuitCancelsTheirScene() {
        catalog.add(scene("intro", 0, action("cam", "MARK", 0, 0, Map.of("cleanup", true)), mark("later", 5000)));

        engine.start(alice, "intro", false);
        engine.onPlayerQuit(alice);

        assertFalse(engine.isRunning(alice));
        assertEquals(List.of("cam@0", "cleanup:cam"), events);
    }

    @Test
    void stopAllStopsEveryRunningScene() {
        UUID bob = players.join("world");
        catalog.add(scene("intro", 0, mark("a", 0), mark("b", 5000)));
        engine.start(alice, "intro", false);
        engine.start(bob, "intro", false);

        assertEquals(2, engine.stopAll("test"));
        assertEquals(0, engine.runningCount());
    }

    @Test
    void sceneEndsAtItsMinimumDurationAndWaitsPushItBack() {
        SceneDefinition withMinimum = new SceneDefinition("timed", "timed", "", true, TriggerSpec.manual(), 0, 0, 2000,
                List.of(), List.of(mark("a", 0)));
        catalog.add(withMinimum);

        engine.start(alice, "timed", false);
        clock.advance(1999);
        assertTrue(engine.isRunning(alice));
        clock.advance(1);
        assertFalse(engine.isRunning(alice));
    }

    @Test
    void aWaitDoesNotCountTwiceTowardTheSceneEnd() {
        catalog.add(scene("waiting", 0, action("pause", "DELAY", 0, 1000, Map.of()), mark("after", 0)));

        engine.start(alice, "waiting", false);
        clock.advance(1000);

        assertEquals(List.of("after@1000"), events);
        assertFalse(engine.isRunning(alice));
    }
}
