package id.vae.scenes.database;

import id.vae.scenes.util.ScenesLogger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/** Applies pending schema migrations, each inside its own transaction. */
public final class MigrationRunner {

    private final Connection connection;
    private final ScenesLogger log;

    public MigrationRunner(Connection connection, ScenesLogger log) {
        this.connection = connection;
        this.log = log;
    }

    /** Returns how many migrations were applied. */
    public int migrate() throws SQLException {
        try (Statement st = connection.createStatement()) {
            st.execute("CREATE TABLE IF NOT EXISTS schema_version ("
                    + "version INTEGER PRIMARY KEY, description TEXT NOT NULL, applied_at INTEGER NOT NULL)");
        }
        int current = currentVersion();
        List<Migrations.Migration> all = Migrations.all();
        int latest = all.get(all.size() - 1).version();
        if (current > latest) {
            throw new SQLException("Database schema version " + current
                    + " is newer than the supported version " + latest);
        }

        int applied = 0;
        boolean previousAutoCommit = connection.getAutoCommit();
        try {
            for (Migrations.Migration migration : all) {
                if (migration.version() <= current) {
                    continue;
                }
                apply(migration);
                applied++;
            }
        } finally {
            connection.setAutoCommit(previousAutoCommit);
        }
        if (applied > 0) {
            log.info("Database migrated to schema version " + latest + ".");
        }
        return applied;
    }

    private int currentVersion() throws SQLException {
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("SELECT COALESCE(MAX(version), 0) FROM schema_version")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private void apply(Migrations.Migration migration) throws SQLException {
        connection.setAutoCommit(false);
        try {
            try (Statement st = connection.createStatement()) {
                for (String sql : migration.statements()) {
                    st.execute(sql);
                }
            }
            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO schema_version(version, description, applied_at) VALUES(?, ?, ?)")) {
                ps.setInt(1, migration.version());
                ps.setString(2, migration.description());
                ps.setLong(3, System.currentTimeMillis());
                ps.executeUpdate();
            }
            connection.commit();
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException rollbackError) {
                e.addSuppressed(rollbackError);
            }
            throw new SQLException("Migration " + migration.version() + " failed: " + e.getMessage(), e);
        }
    }
}
