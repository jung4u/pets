package id.vae.scenes.core;

import id.vae.scenes.util.ScenesLogger;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ServiceRegistryTest {

    private final ScenesLogger log = new ScenesLogger(Logger.getLogger("test"), false);

    static class Fake implements Service {
        private final String name;
        private final List<String> events;
        private final boolean failStart;
        private final boolean failStop;

        Fake(String name, List<String> events, boolean failStart, boolean failStop) {
            this.name = name;
            this.events = events;
            this.failStart = failStart;
            this.failStop = failStop;
        }

        @Override
        public String name() {
            return name;
        }

        @Override
        public void start() throws Exception {
            if (failStart) {
                throw new Exception("boom");
            }
            events.add("start:" + name);
        }

        @Override
        public void stop() {
            events.add("stop:" + name);
            if (failStop) {
                throw new IllegalStateException("stop failed");
            }
        }
    }

    static final class A extends Fake {
        A(List<String> e, boolean fs, boolean fp) {
            super("A", e, fs, fp);
        }
    }

    static final class B extends Fake {
        B(List<String> e, boolean fs, boolean fp) {
            super("B", e, fs, fp);
        }
    }

    static final class C extends Fake {
        C(List<String> e, boolean fs, boolean fp) {
            super("C", e, fs, fp);
        }
    }

    @Test
    void startsInOrderAndStopsInReverse() throws Exception {
        List<String> events = new ArrayList<>();
        ServiceRegistry registry = new ServiceRegistry(log);
        registry.register(A.class, new A(events, false, false));
        registry.register(B.class, new B(events, false, false));
        registry.register(C.class, new C(events, false, false));

        registry.startAll();
        assertTrue(registry.isRunning());
        registry.stopAll();

        assertEquals(List.of("start:A", "start:B", "start:C", "stop:C", "stop:B", "stop:A"), events);
        assertFalse(registry.isRunning());
    }

    @Test
    void failedStartRollsBackStartedServices() {
        List<String> events = new ArrayList<>();
        ServiceRegistry registry = new ServiceRegistry(log);
        registry.register(A.class, new A(events, false, false));
        registry.register(B.class, new B(events, true, false));
        registry.register(C.class, new C(events, false, false));

        ServiceStartException ex = assertThrows(ServiceStartException.class, registry::startAll);

        assertEquals("B", ex.serviceName());
        assertEquals(List.of("start:A", "stop:A"), events);
        assertFalse(registry.isRunning());
    }

    @Test
    void stopFailureDoesNotPreventOtherServicesFromStopping() throws Exception {
        List<String> events = new ArrayList<>();
        ServiceRegistry registry = new ServiceRegistry(log);
        registry.register(A.class, new A(events, false, false));
        registry.register(B.class, new B(events, false, true));

        registry.startAll();
        registry.stopAll();

        assertEquals(List.of("start:A", "start:B", "stop:B", "stop:A"), events);
    }

    @Test
    void duplicateRegistrationAndMissingLookupAreRejected() {
        ServiceRegistry registry = new ServiceRegistry(log);
        registry.register(A.class, new A(new ArrayList<>(), false, false));

        assertThrows(IllegalStateException.class,
                () -> registry.register(A.class, new A(new ArrayList<>(), false, false)));
        assertThrows(IllegalStateException.class, () -> registry.get(B.class));
    }
}
