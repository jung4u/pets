package id.vae.scenes.particle;

import id.vae.scenes.camera.Vec3;

/**
 * A particle effect.
 *
 * @param amount     particles per emission (clamped by the configured limit)
 * @param offset     spread for POINT, or per-particle spread for the other shapes
 * @param radius     radius of RING, SPHERE and SPIRAL
 * @param height     height of SPIRAL, and the height above the player's feet for PLAYER anchors
 * @param direction  when non-zero, POINT particles fly in this direction
 * @param color      hex colour for DUST and ENTITY_EFFECT particles, empty otherwise
 * @param point      position for WORLD anchors
 * @param follow     re-read the anchor for every emission
 * @param nearby     true to show to nearby players too, false for the viewer only
 */
public record ParticleSpec(String type, Shape shape, int amount, Vec3 offset, double speed, double radius,
                           double height, Vec3 direction, String color, Anchor anchor, Vec3 point, boolean follow,
                           boolean nearby, long durationMillis, long intervalMillis) {

    public enum Shape { POINT, RING, SPHERE, SPIRAL }

    public enum Anchor { PLAYER, CAMERA, WORLD }

    public ParticleSpec {
        type = type == null ? "" : type.trim().toUpperCase();
        shape = shape == null ? Shape.POINT : shape;
        anchor = anchor == null ? Anchor.PLAYER : anchor;
        offset = offset == null ? new Vec3(0, 0, 0) : offset;
        direction = direction == null ? new Vec3(0, 0, 0) : direction;
        color = color == null ? "" : color;
        amount = Math.max(1, amount);
        durationMillis = Math.max(0, durationMillis);
        intervalMillis = Math.max(50, intervalMillis);
    }
}
