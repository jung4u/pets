package id.vae.scenes.subtitle;

import id.vae.scenes.scene.EngineHarness;
import id.vae.scenes.sound.SoundControl;
import id.vae.scenes.sound.SoundSpec;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static id.vae.scenes.scene.TestSupport.action;
import static id.vae.scenes.scene.TestSupport.scene;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SubtitleTest {

    private static final class FakeDisplay implements SubtitleDisplay {
        final List<String> events = new ArrayList<>();

        @Override
        public void show(UUID player, SubtitlePosition position, String text, long in, long stay, long out) {
            events.add("show:" + position + "|" + text + "|" + in + "|" + stay + "|" + out);
        }

        @Override
        public void hide(UUID player, SubtitlePosition position) {
            events.add("hide:" + position);
        }
    }

    private static final class FakeSounds implements SoundControl {
        final List<String> played = new ArrayList<>();

        @Override
        public void play(UUID player, SoundSpec spec) {
            played.add(spec.key());
        }

        @Override
        public void stop(UUID player, String keyOrNull) {
        }

        @Override
        public void endScene(UUID player) {
        }
    }

    private EngineHarness h;
    private FakeDisplay display;
    private FakeSounds sounds;
    private SubtitleService service;

    @BeforeEach
    void setUp() {
        h = new EngineHarness();
        display = new FakeDisplay();
        sounds = new FakeSounds();
        service = new SubtitleService(display, (player, text) -> text.replace("%player_name%", "Alice"), sounds,
                h.clock, h.log);
        SubtitleActions.registerAll(h.registry, service);
    }

    private static SubtitleSpec spec(String text, SubtitlePosition position, long duration, int priority) {
        return new SubtitleSpec(text, "", List.of(), false, false, false, position, duration, 250, 250, 0, priority,
                0, 0, 0, true, "", 1f, 1f);
    }

    @Test
    void formatterWrapsColourAndStylesInOrder() {
        SubtitleSpec styled = new SubtitleSpec("x", "a855f7", List.of(), true, true, true, SubtitlePosition.CENTER,
                1000, 0, 0, 0, 0, 0, 0, 0, true, "", 1f, 1f);
        SubtitleSpec gradient = new SubtitleSpec("x", "", List.of("#ff0000", "00ff00"), false, false, false,
                SubtitlePosition.CENTER, 1000, 0, 0, 0, 0, 0, 0, 0, true, "", 1f, 1f);

        assertEquals("<color:#a855f7><bold><italic><underlined>Hi</underlined></italic></bold></color>",
                SubtitleFormatter.toMiniMessage(styled, "Hi"));
        assertEquals("<gradient:#ff0000:#00ff00>Hi</gradient>", SubtitleFormatter.toMiniMessage(gradient, "Hi"));
        assertEquals("Hi", SubtitleFormatter.toMiniMessage(SubtitleSpec.plain("Hi", 1000), "Hi"));
        assertEquals("a\\<red>b", SubtitleFormatter.escape("a<red>b"));
    }

    @Test
    void subtitleShowsImmediatelyWithFadeAndStayTimes() {
        service.show(h.alice, SubtitleSpec.plain("Where am I?", 3000));

        assertEquals(List.of("show:CENTER|Where am I?|250|2500|250"), display.events);
    }

    @Test
    void placeholdersAreResolvedBeforeFormatting() {
        service.show(h.alice, SubtitleSpec.plain("Hi %player_name%", 3000));

        assertTrue(display.events.get(0).contains("Hi Alice"));
    }

    @Test
    void delayHoldsTheSubtitleBack() {
        SubtitleSpec delayed = new SubtitleSpec("later", "", List.of(), false, false, false, SubtitlePosition.CENTER,
                1000, 0, 0, 500, 0, 0, 0, 0, true, "", 1f, 1f);

        service.show(h.alice, delayed);
        assertTrue(display.events.isEmpty());

        h.clock.advance(500);
        assertEquals(1, display.events.size());
    }

    @Test
    void higherPriorityIsNotReplacedUntilItEnds() {
        service.show(h.alice, spec("high", SubtitlePosition.CENTER, 3000, 5));
        h.clock.advance(1000);
        service.show(h.alice, spec("low", SubtitlePosition.TOP, 3000, 1));
        assertEquals(1, display.events.size());

        service.show(h.alice, spec("equal", SubtitlePosition.CENTER, 3000, 5));
        assertEquals(2, display.events.size());

        h.clock.advance(3000);
        service.show(h.alice, spec("low again", SubtitlePosition.CENTER, 3000, 1));
        assertEquals(3, display.events.size());
    }

    @Test
    void actionBarIsIndependentOfTheTitleArea() {
        service.show(h.alice, spec("title", SubtitlePosition.CENTER, 3000, 9));
        service.show(h.alice, spec("bar", SubtitlePosition.BOTTOM, 3000, 0));

        assertEquals(2, display.events.size());
    }

    @Test
    void queueShowsLinesInOrderWithTheirDelays() {
        SubtitleSpec first = new SubtitleSpec("one", "", List.of(), false, false, false, SubtitlePosition.CENTER,
                1000, 0, 0, 0, 0, 1, 0, 0, true, "", 1f, 1f);
        SubtitleSpec second = new SubtitleSpec("two", "", List.of(), false, false, false, SubtitlePosition.CENTER,
                1000, 0, 0, 500, 0, 2, 0, 0, true, "", 1f, 1f);

        service.queue(h.alice, List.of(second, first));
        assertEquals(1, display.events.size());
        assertTrue(display.events.get(0).contains("one"));

        h.clock.advance(1499);
        assertEquals(1, display.events.size());
        h.clock.advance(1);
        assertEquals(2, display.events.size());
        assertTrue(display.events.get(1).contains("two"));
    }

    @Test
    void clearCancelsWhatIsStillScheduledAndHides() {
        SubtitleSpec later = new SubtitleSpec("later", "", List.of(), false, false, false, SubtitlePosition.CENTER,
                1000, 0, 0, 5000, 0, 0, 0, 0, true, "", 1f, 1f);
        service.show(h.alice, later);

        service.clear(h.alice);
        h.clock.advance(10_000);

        assertEquals(List.of("hide:null"), display.events);
    }

    @Test
    void repeatsShowAgainAfterTheDuration() {
        SubtitleSpec again = new SubtitleSpec("again", "", List.of(), false, false, false, SubtitlePosition.CENTER,
                3000, 250, 250, 0, 0, 0, 2, 0, true, "", 1f, 1f);

        service.show(h.alice, again);
        h.clock.advance(6000);

        assertEquals(3, display.events.size());
    }

    @Test
    void soundPlaysWithTheSubtitleAndDisabledOnesAreSkipped() {
        SubtitleSpec withSound = new SubtitleSpec("hm", "", List.of(), false, false, false, SubtitlePosition.CENTER,
                1000, 0, 0, 0, 0, 0, 0, 0, true, "entity.player.breath", 0.5f, 1f);
        SubtitleSpec disabled = new SubtitleSpec("no", "", List.of(), false, false, false, SubtitlePosition.CENTER,
                1000, 0, 0, 0, 0, 0, 0, 0, false, "", 1f, 1f);

        service.show(h.alice, withSound);
        service.show(h.alice, disabled);

        assertEquals(List.of("entity.player.breath"), sounds.played);
        assertEquals(1, display.events.size());
    }

    @Test
    void showActionUsesTheActionDurationAndClearsWhenTheSceneIsCancelled() {
        h.run(scene("intro", 0, action("sub", "SUBTITLE_SHOW", 0, 4000,
                Map.of("text", "Was I just summoned here?", "color", "#a855f7", "position", "TOP"))));

        assertEquals("show:TOP|<color:#a855f7>Was I just summoned here?</color>|250|3500|250", display.events.get(0));

        h.engine.stop(h.alice, "test");
        assertEquals("hide:null", display.events.get(display.events.size() - 1));
    }

    @Test
    void queueActionSchedulesEveryLine() {
        h.run(scene("intro", 0, action("q", "SUBTITLE_QUEUE", 0, 0, Map.of("lines", List.of(
                Map.of("text", "one", "duration-ms", 1000),
                Map.of("text", "two", "duration-ms", 1000, "delay-ms", 200))))));

        h.clock.advance(1200);

        assertEquals(2, display.events.size());
    }

    @Test
    void validationReportsBadSubtitleSettings() {
        assertTrue(h.errors(action("a", "SUBTITLE_SHOW", 0, 3000, Map.of())).contains("text"));
        assertTrue(h.errors(action("a", "SUBTITLE_SHOW", 0, 3000, Map.of("text", "x", "color", "red")))
                .contains("color"));
        assertTrue(h.errors(action("a", "SUBTITLE_SHOW", 0, 3000, Map.of("text", "x", "gradient", List.of("#ffffff"))))
                .contains("gradient"));
        assertTrue(h.errors(action("a", "SUBTITLE_SHOW", 0, 3000, Map.of("text", "x", "position", "LEFT")))
                .contains("position"));
        assertTrue(h.errors(action("a", "SUBTITLE_SHOW", 0, 400, Map.of("text", "x"))).contains("fade"));
        assertTrue(h.errors(action("a", "SUBTITLE_SHOW", 0, 3000, Map.of("text", "x", "sound", "Bad Key")))
                .contains("sound"));
        assertTrue(h.errors(action("a", "SUBTITLE_QUEUE", 0, 0, Map.of())).contains("lines"));
        assertEquals("", h.errors(action("a", "SUBTITLE_SHOW", 0, 3000, Map.of("text", "ok"))));
        assertEquals("", h.errors(action("a", "SUBTITLE_SHOW", 0, 0, Map.of("text", "default duration"))));
        assertEquals("", h.errors(action("a", "SUBTITLE_HIDE", 0, 0, Map.of())));
    }
}
