package id.vae.scenes.bukkit;

import id.vae.scenes.scene.PlayerLocks;
import id.vae.scenes.util.ScenesLogger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Sends the vanilla "set camera" packet through ProtocolLib. The player stays in their own game mode
 * and at their own position; only the view moves. ProtocolLib is reached by reflection so Scenes
 * builds and loads without it.
 */
final class ProtocolLibBackend implements CameraBackend {

    private final Plugin plugin;
    private final PlayerLocks locks;
    private final ScenesLogger log;
    private final Set<UUID> attached = new HashSet<>();

    private final Object protocolManager;
    private final Object cameraType;
    private final Method createPacket;
    private final Method sendServerPacket;
    private final Method getIntegers;
    private final Method write;

    ProtocolLibBackend(Plugin plugin, PlayerLocks locks, ScenesLogger log) throws ReflectiveOperationException {
        this.plugin = plugin;
        this.locks = locks;
        this.log = log;

        Class<?> library = Class.forName("com.comphenix.protocol.ProtocolLibrary");
        Class<?> manager = Class.forName("com.comphenix.protocol.ProtocolManager");
        Class<?> packetType = Class.forName("com.comphenix.protocol.PacketType");
        Class<?> serverTypes = Class.forName("com.comphenix.protocol.PacketType$Play$Server");
        Class<?> container = Class.forName("com.comphenix.protocol.events.PacketContainer");
        Class<?> modifier = Class.forName("com.comphenix.protocol.reflect.StructureModifier");

        protocolManager = library.getMethod("getProtocolManager").invoke(null);
        cameraType = serverTypes.getField("CAMERA").get(null);
        createPacket = manager.getMethod("createPacket", packetType);
        sendServerPacket = manager.getMethod("sendServerPacket", Player.class, container);
        getIntegers = container.getMethod("getIntegers");
        write = modifier.getMethod("write", int.class, Object.class);
    }

    @Override
    public String name() {
        return "protocollib";
    }

    @Override
    public void attach(Player player, Entity camera) {
        UUID id = player.getUniqueId();
        attached.add(id);
        locks.lock(id);
        int entityId = camera.getEntityId();
        // One short delay lets the client finish spawning the camera entity before it is told to use it.
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (attached.contains(id) && player.isOnline() && camera.isValid()) {
                send(player, entityId);
            }
        }, 2L);
    }

    @Override
    public void detach(Player player, Entity camera) {
        UUID id = player.getUniqueId();
        if (!attached.remove(id)) {
            return;
        }
        locks.unlock(id);
        if (player.isOnline()) {
            send(player, player.getEntityId());
        }
    }

    private void send(Player player, int entityId) {
        try {
            Object packet = createPacket.invoke(protocolManager, cameraType);
            Object integers = getIntegers.invoke(packet);
            write.invoke(integers, 0, entityId);
            sendServerPacket.invoke(protocolManager, player, packet);
        } catch (ReflectiveOperationException | RuntimeException e) {
            log.error("Could not send the camera packet to " + player.getName(), e);
        }
    }
}
