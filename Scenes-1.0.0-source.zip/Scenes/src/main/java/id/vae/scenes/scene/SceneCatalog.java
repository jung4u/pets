package id.vae.scenes.scene;

import java.util.Collection;
import java.util.Optional;

/** Read access to the loaded scenes. */
public interface SceneCatalog {

    Optional<SceneDefinition> find(String id);

    Collection<SceneDefinition> all();
}
