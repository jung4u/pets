package id.vae.scenes.scene;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** A condition such as PERMISSION or WORLD with its parameters. */
public record ConditionSpec(String type, Map<String, Object> params) {

    public ConditionSpec {
        type = type == null ? "" : type.trim().toUpperCase(Locale.ROOT);
        params = params == null
                ? Map.of()
                : Collections.unmodifiableMap(new LinkedHashMap<>(params));
    }

    /** Builds a condition from a map where "type" selects the condition and the rest are parameters. */
    public static ConditionSpec fromMap(Map<String, Object> raw) {
        Map<String, Object> copy = new LinkedHashMap<>(raw);
        Object type = copy.remove("type");
        return new ConditionSpec(type == null ? "" : String.valueOf(type), copy);
    }

    public Map<String, Object> toMap() {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("type", type);
        out.putAll(params);
        return out;
    }
}
