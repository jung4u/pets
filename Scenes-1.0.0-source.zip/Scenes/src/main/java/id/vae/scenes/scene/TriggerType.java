package id.vae.scenes.scene;

/** Events that can start a scene automatically. MANUAL scenes only start from commands or the web panel. */
public enum TriggerType {
    MANUAL,
    FIRST_JOIN,
    LOGIN_SUCCESS,
    REGISTER_SUCCESS,
    WORLD_CHANGE,
    NETHER_ENTER,
    END_ENTER,
    RTP_START,
    RTP_SUCCESS,
    PLAYER_DEATH,
    PLAYER_RESPAWN,
    COMMAND,
    PERMISSION,
    CUSTOM
}
