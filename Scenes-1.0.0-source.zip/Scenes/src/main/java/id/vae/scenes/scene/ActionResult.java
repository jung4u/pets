package id.vae.scenes.scene;

import java.util.function.BooleanSupplier;

/** What the scene runner should do after an action ran. */
public final class ActionResult {

    public enum Kind { DONE, END_SCENE, WAIT }

    private static final ActionResult DONE = new ActionResult(Kind.DONE, null, 0, 0, false);
    private static final ActionResult END = new ActionResult(Kind.END_SCENE, null, 0, 0, false);

    private final Kind kind;
    private final BooleanSupplier ready;
    private final long timeoutMillis;
    private final long pollMillis;
    private final boolean abortOnTimeout;

    private ActionResult(Kind kind, BooleanSupplier ready, long timeoutMillis, long pollMillis,
                         boolean abortOnTimeout) {
        this.kind = kind;
        this.ready = ready;
        this.timeoutMillis = timeoutMillis;
        this.pollMillis = pollMillis;
        this.abortOnTimeout = abortOnTimeout;
    }

    public static ActionResult done() {
        return DONE;
    }

    public static ActionResult endScene() {
        return END;
    }

    /**
     * Pauses the timeline until the supplier returns true or the timeout passes.
     * Time spent waiting pushes back every later action.
     */
    public static ActionResult waitFor(BooleanSupplier ready, long timeoutMillis, long pollMillis,
                                       boolean abortOnTimeout) {
        return new ActionResult(Kind.WAIT, ready, Math.max(0, timeoutMillis), Math.max(1, pollMillis),
                abortOnTimeout);
    }

    public Kind kind() {
        return kind;
    }

    public BooleanSupplier ready() {
        return ready;
    }

    public long timeoutMillis() {
        return timeoutMillis;
    }

    public long pollMillis() {
        return pollMillis;
    }

    public boolean abortOnTimeout() {
        return abortOnTimeout;
    }
}
