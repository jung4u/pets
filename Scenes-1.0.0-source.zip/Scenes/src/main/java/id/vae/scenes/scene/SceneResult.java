package id.vae.scenes.scene;

import java.util.List;

/** Outcome of a scene edit: either the stored scene or the reasons it was rejected. */
public record SceneResult(boolean ok, List<String> errors, SceneDefinition scene) {

    public static SceneResult success(SceneDefinition scene) {
        return new SceneResult(true, List.of(), scene);
    }

    public static SceneResult failure(String... errors) {
        return new SceneResult(false, List.of(errors), null);
    }

    public static SceneResult failure(List<String> errors) {
        return new SceneResult(false, List.copyOf(errors), null);
    }
}
