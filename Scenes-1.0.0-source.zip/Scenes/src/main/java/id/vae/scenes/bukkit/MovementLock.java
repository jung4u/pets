package id.vae.scenes.bukkit;

import id.vae.scenes.scene.PlayerLocks;
import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Freezes a player by cancelling position changes while still allowing the head to turn. It keeps no
 * persistent state on the player (no speed or ability changes), so a crash can never leave anyone stuck.
 * Locks are counted: the player is released when every lock has been released.
 */
public final class MovementLock implements PlayerLocks, Listener {

    private final Map<UUID, Integer> locks = new HashMap<>();

    @Override
    public void lock(UUID player) {
        locks.merge(player, 1, Integer::sum);
    }

    @Override
    public void unlock(UUID player) {
        Integer count = locks.get(player);
        if (count == null) {
            return;
        }
        if (count > 1) {
            locks.put(player, count - 1);
        } else {
            locks.remove(player);
        }
    }

    public boolean isLocked(UUID player) {
        return locks.containsKey(player);
    }

    public void releaseAll() {
        locks.clear();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!locks.containsKey(event.getPlayer().getUniqueId())) {
            return;
        }
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) {
            return;
        }
        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
            Location fixed = from.clone();
            fixed.setYaw(to.getYaw());
            fixed.setPitch(to.getPitch());
            event.setTo(fixed);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        locks.remove(event.getPlayer().getUniqueId());
    }
}
