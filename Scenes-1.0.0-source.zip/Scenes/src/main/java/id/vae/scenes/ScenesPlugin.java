package id.vae.scenes;

import id.vae.scenes.bukkit.BukkitParticleOutput;
import id.vae.scenes.bukkit.BukkitPlaceholders;
import id.vae.scenes.bukkit.BukkitPlayerGateway;
import id.vae.scenes.bukkit.BukkitSceneScheduler;
import id.vae.scenes.bukkit.BukkitSoundOutput;
import id.vae.scenes.bukkit.BukkitSubtitleDisplay;
import id.vae.scenes.bukkit.BukkitTriggerListener;
import id.vae.scenes.bukkit.CameraManager;
import id.vae.scenes.bukkit.CrashRecovery;
import id.vae.scenes.bukkit.JoinCoordinator;
import id.vae.scenes.bukkit.MovementLock;
import id.vae.scenes.bukkit.PresetFiles;
import id.vae.scenes.bukkit.RestoreStore;
import id.vae.scenes.bukkit.RtpHook;
import id.vae.scenes.bukkit.SceneSeeder;
import id.vae.scenes.bukkit.ScreenManager;
import id.vae.scenes.camera.CameraActions;
import id.vae.scenes.command.SceneCommand;
import id.vae.scenes.config.ConfigService;
import id.vae.scenes.core.MaintenanceService;
import id.vae.scenes.core.ServiceRegistry;
import id.vae.scenes.core.ServiceStartException;
import id.vae.scenes.database.DatabaseManager;
import id.vae.scenes.database.PlayerRepository;
import id.vae.scenes.database.ProgressRepository;
import id.vae.scenes.database.SceneRepository;
import id.vae.scenes.database.SettingsRepository;
import id.vae.scenes.particle.ParticleActions;
import id.vae.scenes.particle.ParticleService;
import id.vae.scenes.scene.ActionRegistry;
import id.vae.scenes.scene.ConditionEvaluator;
import id.vae.scenes.scene.ControlActions;
import id.vae.scenes.scene.DatabaseProgressTracker;
import id.vae.scenes.scene.PlayerActions;
import id.vae.scenes.scene.PresetLibrary;
import id.vae.scenes.scene.SceneEngine;
import id.vae.scenes.scene.SceneManager;
import id.vae.scenes.scene.SceneValidator;
import id.vae.scenes.rtp.RtpActions;
import id.vae.scenes.screen.ScreenActions;
import id.vae.scenes.sound.SoundActions;
import id.vae.scenes.sound.SoundService;
import id.vae.scenes.subtitle.SubtitleActions;
import id.vae.scenes.subtitle.SubtitleService;
import id.vae.scenes.trigger.TriggerManager;
import id.vae.scenes.util.ScenesLogger;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.InputStream;
import java.nio.file.Path;

public final class ScenesPlugin extends JavaPlugin {

    private ScenesLogger scenesLog;
    private ServiceRegistry services;
    private ActionRegistry actionRegistry;
    private ScreenManager screen;
    private ProgressRepository progressRepository;
    private DatabaseProgressTracker progressTracker;

    @Override
    public void onEnable() {
        scenesLog = new ScenesLogger(getLogger(), false);
        services = new ServiceRegistry(scenesLog);

        Path dataFolder = getDataFolder().toPath();
        ConfigService config = services.register(ConfigService.class,
                new ConfigService(dataFolder, this::openResource, scenesLog));
        DatabaseManager database = services.register(DatabaseManager.class,
                new DatabaseManager(() -> dataFolder.resolve(config.database().file()), scenesLog));
        services.register(MaintenanceService.class,
                new MaintenanceService(config, database, dataFolder, scenesLog));

        BukkitPlayerGateway players = new BukkitPlayerGateway();
        ConditionEvaluator conditions = new ConditionEvaluator(players);
        ActionRegistry actions = new ActionRegistry();
        ControlActions.registerAll(actions);
        MovementLock movementLock = new MovementLock();
        RestoreStore restoreStore = new RestoreStore(dataFolder.resolve("data").resolve("pending"));
        CameraManager camera = services.register(CameraManager.class,
                new CameraManager(this, config::camera, () -> config.general().maxCameraSessions(), movementLock,
                        restoreStore, scenesLog));
        CameraActions.registerAll(actions, camera);
        PlayerActions.registerAll(actions, movementLock);

        BukkitSceneScheduler scheduler = new BukkitSceneScheduler(this);
        PresetLibrary soundPresets = new PresetLibrary();
        PresetLibrary particlePresets = new PresetLibrary();
        services.register(PresetFiles.class,
                new PresetFiles(dataFolder, this::openResource, scenesLog, soundPresets, particlePresets));
        screen = services.register(ScreenManager.class, new ScreenManager(this, scenesLog));
        SoundService sounds = services.register(SoundService.class,
                new SoundService(new BukkitSoundOutput(), camera, scheduler, scenesLog));
        SubtitleService subtitles = services.register(SubtitleService.class,
                new SubtitleService(new BukkitSubtitleDisplay(this), new BukkitPlaceholders(this), sounds, scheduler,
                        scenesLog));
        ParticleService particles = services.register(ParticleService.class,
                new ParticleService(new BukkitParticleOutput(), camera, scheduler,
                        () -> config.general().maxParticlesPerAction(), scenesLog));
        ScreenActions.registerAll(actions, screen, camera);
        SoundActions.registerAll(actions, sounds, soundPresets);
        SubtitleActions.registerAll(actions, subtitles);
        ParticleActions.registerAll(actions, particles, particlePresets);
        SceneValidator validator = new SceneValidator(actions, conditions);
        progressRepository = new ProgressRepository(database);
        DatabaseProgressTracker progress = new DatabaseProgressTracker(progressRepository, database, scenesLog);
        progressTracker = progress;
        SceneManager sceneManager = services.register(SceneManager.class,
                new SceneManager(new SceneRepository(database), validator, scenesLog));
        SceneSeeder seeder = services.register(SceneSeeder.class,
                new SceneSeeder(sceneManager, new SettingsRepository(database), dataFolder, this::openResource,
                        scenesLog));
        SceneEngine engine = services.register(SceneEngine.class,
                new SceneEngine(sceneManager, actions, scheduler, players, progress, services,
                        conditions, () -> config.general().maxConcurrentScenes(), scenesLog));
        TriggerManager triggers = services.register(TriggerManager.class,
                new TriggerManager(sceneManager, engine, players, scenesLog));
        RtpHook rtpHook = services.register(RtpHook.class,
                new RtpHook(this, config::hooks, triggers, engine, scenesLog));
        RtpActions.registerAll(actions, rtpHook);
        JoinCoordinator joins = services.register(JoinCoordinator.class,
                new JoinCoordinator(this, config::hooks, triggers, database, new PlayerRepository(database),
                        new SettingsRepository(database), scenesLog));
        this.actionRegistry = actions;

        try {
            services.startAll();
        } catch (ServiceStartException e) {
            scenesLog.error("Scenes could not start (" + e.serviceName() + "). Disabling plugin.", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        getServer().getPluginManager().registerEvents(new BukkitTriggerListener(this, triggers, engine, progress), this);
        getServer().getPluginManager().registerEvents(camera, this);
        getServer().getPluginManager().registerEvents(new CrashRecovery(this, restoreStore, camera, scenesLog), this);
        getServer().getPluginManager().registerEvents(screen, this);
        getServer().getPluginManager().registerEvents(rtpHook, this);
        getServer().getPluginManager().registerEvents(joins, this);
        getServer().getPluginManager().registerEvents(movementLock, this);
        SceneCommand commands = new SceneCommand(this);
        for (String name : new String[] {"scenes", "scene"}) {
            PluginCommand command = getCommand(name);
            if (command != null) {
                command.setExecutor(commands);
                command.setTabCompleter(commands);
            }
        }

        scenesLog.setDebug(config.general().debug());
        scenesLog.info("Plugin enabled.");
    }

    @Override
    public void onDisable() {
        if (services != null) {
            services.stopAll();
        }
        if (scenesLog != null) {
            scenesLog.info("Plugin disabled.");
        }
    }

    public ServiceRegistry services() {
        return services;
    }

    public ProgressRepository progressRepository() {
        return progressRepository;
    }

    public DatabaseProgressTracker progressTracker() {
        return progressTracker;
    }

    /** Later engines (camera, screen, subtitle...) register their actions here during startup. */
    public ActionRegistry actionRegistry() {
        return actionRegistry;
    }

    /** Validates and applies configuration changes without a restart. */
    public ConfigService.ReloadResult reloadConfiguration() {
        ConfigService config = services.get(ConfigService.class);
        ConfigService.ReloadResult result = config.reload();
        if (result.ok()) {
            scenesLog.setDebug(config.general().debug());
            services.get(MaintenanceService.class).reschedule();
            services.get(PresetFiles.class).reload();
            scenesLog.info("Configuration reloaded.");
        }
        return result;
    }

    private InputStream openResource(String name) {
        return getResource(name);
    }
}
