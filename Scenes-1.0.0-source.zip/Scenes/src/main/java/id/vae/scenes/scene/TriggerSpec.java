package id.vae.scenes.scene;

/**
 * When and for whom a scene starts automatically.
 *
 * @param permission required permission, empty for none
 * @param world      required world name, empty for any
 * @param argument   command or custom event name for COMMAND and CUSTOM triggers, empty otherwise
 */
public record TriggerSpec(TriggerType type, boolean oncePerPlayer, String permission, String world,
                          String argument) {

    public TriggerSpec {
        type = type == null ? TriggerType.MANUAL : type;
        permission = permission == null ? "" : permission.trim();
        world = world == null ? "" : world.trim();
        argument = argument == null ? "" : argument.trim();
    }

    public static TriggerSpec manual() {
        return new TriggerSpec(TriggerType.MANUAL, false, "", "", "");
    }

    public static TriggerSpec of(TriggerType type, boolean oncePerPlayer) {
        return new TriggerSpec(type, oncePerPlayer, "", "", "");
    }
}
