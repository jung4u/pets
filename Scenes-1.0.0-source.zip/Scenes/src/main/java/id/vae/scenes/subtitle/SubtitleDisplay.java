package id.vae.scenes.subtitle;

import java.util.UUID;

/** Shows subtitle text to a real player. */
public interface SubtitleDisplay {

    void show(UUID player, SubtitlePosition position, String miniMessage, long fadeInMillis, long stayMillis,
              long fadeOutMillis);

    /** Removes the subtitles of the given area, or everything when position is null. */
    void hide(UUID player, SubtitlePosition position);
}
