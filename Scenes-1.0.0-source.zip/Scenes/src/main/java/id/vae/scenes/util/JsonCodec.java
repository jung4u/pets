package id.vae.scenes.util;

import java.util.List;
import java.util.Map;

/** JSON helper for the JSON columns of the database. */
public final class JsonCodec {

    private JsonCodec() {
    }

    public static String toJson(Object value) {
        return Json.stringify(value);
    }

    /** Parses a JSON object; blank input gives an empty map. Throws IllegalArgumentException when invalid. */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> parseMap(String json) {
        if (json == null || json.isBlank()) {
            return Map.of();
        }
        try {
            Object parsed = Json.parse(json);
            if (parsed == null) {
                return Map.of();
            }
            if (!(parsed instanceof Map<?, ?>)) {
                throw new IllegalArgumentException("Invalid JSON object: not an object");
            }
            return (Map<String, Object>) parsed;
        } catch (Json.JsonException e) {
            throw new IllegalArgumentException("Invalid JSON object: " + e.getMessage(), e);
        }
    }

    /** Parses a JSON array of objects; blank input gives an empty list. */
    @SuppressWarnings("unchecked")
    public static List<Map<String, Object>> parseList(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            Object parsed = Json.parse(json);
            if (parsed == null) {
                return List.of();
            }
            if (!(parsed instanceof List<?> list)) {
                throw new IllegalArgumentException("Invalid JSON array: not an array");
            }
            for (Object item : list) {
                if (!(item instanceof Map<?, ?>)) {
                    throw new IllegalArgumentException("Invalid JSON array: items must be objects");
                }
            }
            return (List<Map<String, Object>>) parsed;
        } catch (Json.JsonException e) {
            throw new IllegalArgumentException("Invalid JSON array: " + e.getMessage(), e);
        }
    }
}
