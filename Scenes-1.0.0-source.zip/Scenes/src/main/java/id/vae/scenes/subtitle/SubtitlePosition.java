package id.vae.scenes.subtitle;

/** TOP uses the title line, CENTER the subtitle line, BOTTOM the action bar. */
public enum SubtitlePosition {
    TOP,
    CENTER,
    BOTTOM;

    /** TOP and CENTER share the on-screen title area; BOTTOM is separate. */
    public boolean sharesTitleArea() {
        return this != BOTTOM;
    }
}
