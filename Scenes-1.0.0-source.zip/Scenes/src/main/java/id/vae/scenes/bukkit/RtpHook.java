package id.vae.scenes.bukkit;

import id.vae.scenes.config.HookSettings;
import id.vae.scenes.core.Service;
import id.vae.scenes.rtp.RtpControl;
import id.vae.scenes.scene.SceneEngine;
import id.vae.scenes.scene.TriggerType;
import id.vae.scenes.trigger.TriggerEvent;
import id.vae.scenes.trigger.TriggerManager;
import id.vae.scenes.util.ScenesLogger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Hook for any random-teleport plugin, by command. A configured command (default /rtp, /wild, /randomtp)
 * is held back; the scene with trigger RTP_START plays; its RTP_EXECUTE action then runs the real command and
 * waits for the teleport. A teleport counts when the player moves to another world or at least
 * {@code rtp.min-distance} blocks within {@code rtp.timeout-ms}. If no RTP scene starts, the command simply
 * runs as usual. Unknown commands and commands the player may not use are never intercepted.
 */
public final class RtpHook implements Service, RtpControl, Listener {

    private static final class State {
        final String commandLine;
        Status status = Status.PENDING;
        BukkitTask timeout;

        State(String commandLine) {
            this.commandLine = commandLine;
        }
    }

    private final Plugin plugin;
    private final Supplier<HookSettings> settings;
    private final TriggerManager triggers;
    private final SceneEngine engine;
    private final ScenesLogger log;
    private final Map<UUID, State> states = new HashMap<>();
    private final Set<UUID> bypass = new HashSet<>();

    public RtpHook(Plugin plugin, Supplier<HookSettings> settings, TriggerManager triggers, SceneEngine engine,
                   ScenesLogger log) {
        this.plugin = plugin;
        this.settings = settings;
        this.triggers = triggers;
        this.engine = engine;
        this.log = log;
    }

    @Override
    public String name() {
        return "rtp-hook";
    }

    @Override
    public void start() {
        HookSettings s = settings.get();
        log.info("RTP hook " + (s.rtpEnabled() ? "watching " + s.rtpCommands() : "disabled") + ".");
    }

    @Override
    public void stop() {
        for (UUID id : new java.util.ArrayList<>(states.keySet())) {
            finish(id);
        }
    }

    // ------------------------------------------------------------------ RtpControl

    @Override
    public Status status(UUID player) {
        State state = states.get(player);
        return state == null ? Status.NONE : state.status;
    }

    @Override
    public boolean execute(UUID id) {
        State state = states.get(id);
        Player player = Bukkit.getPlayer(id);
        if (state == null || player == null) {
            return false;
        }
        if (state.status != Status.PENDING) {
            return state.status == Status.EXECUTING;
        }
        state.status = Status.EXECUTING;
        boolean dispatched;
        bypass.add(id);
        try {
            dispatched = Bukkit.dispatchCommand(player, state.commandLine);
        } finally {
            bypass.remove(id);
        }
        if (!dispatched) {
            state.status = Status.FAILED;
        } else if (state.status == Status.EXECUTING) {
            long ticks = Math.max(1, settings.get().rtpTimeoutMillis() / 50);
            state.timeout = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (state.status == Status.EXECUTING) {
                    state.status = Status.FAILED;
                    log.debug("RTP for " + id + " timed out.");
                }
            }, ticks);
        }
        return true;
    }

    @Override
    public void finish(UUID id) {
        State state = states.remove(id);
        if (state != null && state.timeout != null) {
            state.timeout.cancel();
        }
    }

    @Override
    public long timeoutMillis() {
        return settings.get().rtpTimeoutMillis();
    }

    // ------------------------------------------------------------------ events

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        HookSettings s = settings.get();
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        if (!s.rtpEnabled() || bypass.contains(id)) {
            return;
        }
        String message = event.getMessage();
        String line = message.startsWith("/") ? message.substring(1) : message;
        String label = line.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        int colon = label.indexOf(':');
        if (colon >= 0) {
            label = label.substring(colon + 1);
        }
        if (!s.rtpCommands().contains(label)) {
            return;
        }
        Command command = Bukkit.getCommandMap().getCommand(label);
        if (command == null || !command.testPermissionSilent(player)) {
            return;
        }
        if (states.containsKey(id)) {
            event.setCancelled(true);
            return;
        }
        if (engine.isRunning(id)) {
            return;
        }

        event.setCancelled(true);
        states.put(id, new State(line));
        boolean started = triggers.fire(TriggerEvent.of(TriggerType.RTP_START, id, player.getWorld().getName()))
                .stream().anyMatch(f -> f.result() == SceneEngine.StartResult.STARTED);
        if (!started) {
            states.remove(id);
            bypass.add(id);
            try {
                Bukkit.dispatchCommand(player, line);
            } finally {
                bypass.remove(id);
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        State state = states.get(id);
        if (state == null || state.status != Status.EXECUTING) {
            return;
        }
        PlayerTeleportEvent.TeleportCause cause = event.getCause();
        if (cause != PlayerTeleportEvent.TeleportCause.COMMAND && cause != PlayerTeleportEvent.TeleportCause.PLUGIN
                && cause != PlayerTeleportEvent.TeleportCause.UNKNOWN) {
            return;
        }
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) {
            return;
        }
        boolean far = from.getWorld() != to.getWorld() || from.distance(to) >= settings.get().rtpMinDistance();
        if (!far) {
            return;
        }
        state.status = Status.SUCCEEDED;
        if (state.timeout != null) {
            state.timeout.cancel();
        }
        String world = to.getWorld() == null ? "" : to.getWorld().getName();
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline()) {
                triggers.fire(TriggerEvent.of(TriggerType.RTP_SUCCESS, id, world));
            }
        });
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        finish(event.getPlayer().getUniqueId());
    }
}
