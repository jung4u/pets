package id.vae.scenes.database;

import id.vae.scenes.scene.ActionDefinition;
import id.vae.scenes.scene.ConditionSpec;
import id.vae.scenes.scene.SceneDefinition;
import id.vae.scenes.scene.TriggerSpec;
import id.vae.scenes.scene.TriggerType;
import id.vae.scenes.scene.ConfigValues;
import id.vae.scenes.util.Easing;
import id.vae.scenes.util.JsonCodec;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Persists scenes and their actions. Corrupt rows are reported, never fatal. */
public final class SceneRepository {

    public record LoadResult(List<SceneDefinition> scenes, List<String> errors) {
    }

    private record SceneRow(String id, String name, String description, boolean enabled, int priority,
                            long cooldownMs, String triggerJson, String conditionsJson, String dataJson) {
    }

    private final DatabaseManager db;

    public SceneRepository(DatabaseManager db) {
        this.db = db;
    }

    public LoadResult loadAll() throws SQLException {
        return db.query(c -> {
            Map<String, SceneRow> rows = new LinkedHashMap<>();
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT id, name, description, enabled, priority, cooldown_ms, trigger_json, "
                            + "conditions_json, data_json FROM scenes ORDER BY id");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.put(rs.getString(1), new SceneRow(rs.getString(1), rs.getString(2), rs.getString(3),
                            rs.getInt(4) != 0, rs.getInt(5), rs.getLong(6), rs.getString(7), rs.getString(8),
                            rs.getString(9)));
                }
            }

            Map<String, List<ActionDefinition>> actions = new LinkedHashMap<>();
            List<String> errors = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT id, scene_id, type, ord, delay_ms, duration_ms, easing, enabled, conditions_json, "
                            + "config_json FROM scene_actions ORDER BY scene_id, ord");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String sceneId = rs.getString(2);
                    try {
                        actions.computeIfAbsent(sceneId, k -> new ArrayList<>()).add(new ActionDefinition(
                                rs.getString(1), rs.getString(3), rs.getInt(4), rs.getLong(5), rs.getLong(6),
                                Easing.parse(rs.getString(7), Easing.LINEAR), rs.getInt(8) != 0,
                                parseConditions(rs.getString(9)), JsonCodec.parseMap(rs.getString(10))));
                    } catch (IllegalArgumentException e) {
                        errors.add("scene '" + sceneId + "' action '" + rs.getString(1) + "': " + e.getMessage());
                    }
                }
            }

            List<SceneDefinition> scenes = new ArrayList<>();
            for (SceneRow row : rows.values()) {
                try {
                    scenes.add(toScene(row, actions.getOrDefault(row.id(), List.of())));
                } catch (IllegalArgumentException e) {
                    errors.add("scene '" + row.id() + "': " + e.getMessage());
                }
            }
            return new LoadResult(scenes, errors);
        });
    }

    /** Inserts or replaces a scene together with all its actions, atomically. */
    public void save(SceneDefinition scene, long nowMillis) throws SQLException {
        db.transaction(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO scenes(id, name, description, enabled, priority, cooldown_ms, trigger_json, "
                            + "conditions_json, data_json, created_at, updated_at) "
                            + "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
                            + "ON CONFLICT(id) DO UPDATE SET name = excluded.name, "
                            + "description = excluded.description, enabled = excluded.enabled, "
                            + "priority = excluded.priority, cooldown_ms = excluded.cooldown_ms, "
                            + "trigger_json = excluded.trigger_json, conditions_json = excluded.conditions_json, "
                            + "data_json = excluded.data_json, updated_at = excluded.updated_at")) {
                ps.setString(1, scene.id());
                ps.setString(2, scene.name());
                ps.setString(3, scene.description());
                ps.setInt(4, scene.enabled() ? 1 : 0);
                ps.setInt(5, scene.priority());
                ps.setLong(6, scene.cooldownMillis());
                ps.setString(7, JsonCodec.toJson(triggerToMap(scene.trigger())));
                ps.setString(8, JsonCodec.toJson(conditionsToList(scene.conditions())));
                ps.setString(9, JsonCodec.toJson(Map.of("durationMillis", scene.durationMillis())));
                ps.setLong(10, nowMillis);
                ps.setLong(11, nowMillis);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM scene_actions WHERE scene_id = ?")) {
                ps.setString(1, scene.id());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO scene_actions(id, scene_id, type, ord, delay_ms, duration_ms, easing, enabled, "
                            + "conditions_json, config_json) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                for (ActionDefinition a : scene.actions()) {
                    ps.setString(1, a.id());
                    ps.setString(2, scene.id());
                    ps.setString(3, a.type());
                    ps.setInt(4, a.order());
                    ps.setLong(5, a.delayMillis());
                    ps.setLong(6, a.durationMillis());
                    ps.setString(7, a.easing().name());
                    ps.setInt(8, a.enabled() ? 1 : 0);
                    ps.setString(9, JsonCodec.toJson(conditionsToList(a.conditions())));
                    ps.setString(10, JsonCodec.toJson(a.config()));
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            return null;
        });
    }

    public boolean delete(String id) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM scenes WHERE id = ?")) {
                ps.setString(1, id);
                return ps.executeUpdate() > 0;
            }
        });
    }

    private static SceneDefinition toScene(SceneRow row, List<ActionDefinition> actions) {
        Map<String, Object> trigger = JsonCodec.parseMap(row.triggerJson());
        Map<String, Object> data = JsonCodec.parseMap(row.dataJson());
        String typeName = ConfigValues.string(trigger, "type", "MANUAL").trim().toUpperCase(Locale.ROOT);
        TriggerType type;
        try {
            type = TriggerType.valueOf(typeName);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("unknown trigger type '" + typeName + "'");
        }
        TriggerSpec spec = new TriggerSpec(type, ConfigValues.bool(trigger, "oncePerPlayer", false),
                ConfigValues.string(trigger, "permission", ""), ConfigValues.string(trigger, "world", ""),
                ConfigValues.string(trigger, "argument", ""));
        return new SceneDefinition(row.id(), row.name(), row.description(), row.enabled(), spec, row.priority(),
                row.cooldownMs(), ConfigValues.longValue(data, "durationMillis", 0),
                parseConditions(row.conditionsJson()), actions);
    }

    private static Map<String, Object> triggerToMap(TriggerSpec t) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("type", t.type().name());
        m.put("oncePerPlayer", t.oncePerPlayer());
        m.put("permission", t.permission());
        m.put("world", t.world());
        m.put("argument", t.argument());
        return m;
    }

    private static List<Map<String, Object>> conditionsToList(List<ConditionSpec> conditions) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (ConditionSpec c : conditions) {
            out.add(c.toMap());
        }
        return out;
    }

    private static List<ConditionSpec> parseConditions(String json) {
        List<ConditionSpec> out = new ArrayList<>();
        for (Map<String, Object> raw : JsonCodec.parseList(json)) {
            out.add(ConditionSpec.fromMap(raw));
        }
        return out;
    }
}
