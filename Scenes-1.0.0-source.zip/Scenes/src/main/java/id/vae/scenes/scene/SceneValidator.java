package id.vae.scenes.scene;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/** Checks a scene before it is saved or loaded. Nothing invalid is ever applied. */
public final class SceneValidator {

    public static final Pattern SCENE_ID = Pattern.compile("[a-z0-9_]{1,64}");
    public static final Pattern ACTION_ID = Pattern.compile("[A-Za-z0-9_-]{1,64}");
    public static final long MAX_MILLIS = 86_400_000L;

    private final ActionRegistry actions;
    private final ConditionEvaluator conditions;

    public SceneValidator(ActionRegistry actions, ConditionEvaluator conditions) {
        this.actions = actions;
        this.conditions = conditions;
    }

    /** Returns every problem found; an empty list means the scene is valid. */
    public List<String> validate(SceneDefinition scene) {
        List<String> errors = new ArrayList<>();
        if (!SCENE_ID.matcher(scene.id()).matches()) {
            errors.add("scene id must be 1-64 characters of a-z, 0-9 and underscore");
        }
        if (scene.name().isBlank()) {
            errors.add("scene name must not be empty");
        }
        if (scene.cooldownMillis() < 0 || scene.cooldownMillis() > MAX_MILLIS * 365) {
            errors.add("cooldown is out of range");
        }
        if (scene.durationMillis() < 0 || scene.durationMillis() > MAX_MILLIS) {
            errors.add("scene duration is out of range");
        }
        for (ConditionSpec condition : scene.conditions()) {
            conditions.validate(condition).forEach(e -> errors.add("scene condition: " + e));
        }

        Set<String> ids = new HashSet<>();
        for (ActionDefinition action : scene.actions()) {
            String label = "action '" + action.id() + "'";
            if (!ACTION_ID.matcher(action.id()).matches()) {
                errors.add(label + ": id must be 1-64 characters of letters, digits, underscore or dash");
            } else if (!ids.add(action.id())) {
                errors.add(label + ": duplicate action id");
            }
            if (action.delayMillis() < 0 || action.delayMillis() > MAX_MILLIS) {
                errors.add(label + ": delay is out of range");
            }
            if (action.durationMillis() < 0 || action.durationMillis() > MAX_MILLIS) {
                errors.add(label + ": duration is out of range");
            }
            for (ConditionSpec condition : action.conditions()) {
                conditions.validate(condition).forEach(e -> errors.add(label + ": " + e));
            }
            ActionHandler handler = actions.get(action.type()).orElse(null);
            if (handler == null) {
                errors.add(label + ": unknown action type '" + action.type() + "'");
            } else {
                handler.validate(action).forEach(e -> errors.add(label + ": " + e));
            }
        }
        return errors;
    }
}
