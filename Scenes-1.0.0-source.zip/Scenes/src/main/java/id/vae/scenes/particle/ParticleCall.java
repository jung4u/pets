package id.vae.scenes.particle;

/** One call to the server's particle API. With count 0 the offset is a direction and speed its strength. */
public record ParticleCall(String type, double x, double y, double z, int count, double offsetX, double offsetY,
                           double offsetZ, double speed, String color) {
}
