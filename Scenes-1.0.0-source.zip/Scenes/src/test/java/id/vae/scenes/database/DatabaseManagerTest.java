package id.vae.scenes.database;

import id.vae.scenes.util.ScenesLogger;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

class DatabaseManagerTest {

    private final ScenesLogger log = new ScenesLogger(Logger.getLogger("test"), false);
    private DatabaseManager db;

    @BeforeEach
    void setUp() throws Exception {
        db = DatabaseManager.inMemory(log);
        db.start();
    }

    @AfterEach
    void tearDown() {
        db.stop();
    }

    @Test
    void migrationsCreateAllRequiredTables() throws Exception {
        Set<String> tables = db.query(c -> {
            Set<String> names = new HashSet<>();
            try (PreparedStatement ps = c.prepareStatement("SELECT name FROM sqlite_master WHERE type = 'table'");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    names.add(rs.getString(1));
                }
            }
            return names;
        });

        assertTrue(tables.containsAll(List.of("players", "player_progress", "scenes", "scene_actions",
                "web_admins", "web_sessions", "activity_logs", "settings", "schema_version")));
    }

    @Test
    void migrationsAreIdempotent() throws Exception {
        int applied = db.query(c -> new MigrationRunner(c, log).migrate());
        assertEquals(0, applied);
        assertTrue(db.isHealthy());
    }

    @Test
    void failedTransactionRollsBack() throws Exception {
        SettingsRepository settings = new SettingsRepository(db);

        assertThrows(SQLException.class, () -> db.transaction(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO settings(key, value, updated_at) VALUES('k', 'v', 1)")) {
                ps.executeUpdate();
            }
            throw new SQLException("boom");
        }));

        assertTrue(settings.get("k").isEmpty());
    }

    @Test
    void settingsRoundTrip() throws Exception {
        SettingsRepository settings = new SettingsRepository(db);
        settings.set("theme", "dark", 1L);
        settings.set("theme", "purple", 2L);

        assertEquals("purple", settings.get("theme").orElseThrow());
        assertTrue(settings.delete("theme"));
        assertTrue(settings.get("theme").isEmpty());
    }

    @Test
    void fileDatabaseBackupKeepsOnlyNewestCopies(@TempDir Path dir) throws Exception {
        DatabaseManager fileDb = new DatabaseManager(() -> dir.resolve("data/scenes.db"), log);
        fileDb.start();
        try {
            new SettingsRepository(fileDb).set("k", "v", 1L);
            Path backups = dir.resolve("backups");

            Path last = null;
            for (int i = 0; i < 3; i++) {
                last = fileDb.backup(backups, 2);
                Thread.sleep(15);
            }

            try (Stream<Path> files = Files.list(backups)) {
                assertEquals(2, files.count());
            }
            assertTrue(Files.size(last) > 0);
        } finally {
            fileDb.stop();
        }
    }

    @Test
    void inMemoryDatabaseCannotBeBackedUp(@TempDir Path dir) {
        assertThrows(IllegalStateException.class, () -> db.backup(dir, 1));
    }
}
