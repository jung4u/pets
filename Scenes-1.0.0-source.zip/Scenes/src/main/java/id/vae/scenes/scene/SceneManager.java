package id.vae.scenes.scene;

import id.vae.scenes.core.Service;
import id.vae.scenes.database.SceneRepository;
import id.vae.scenes.util.ScenesLogger;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Holds the live scenes and applies edits. Every change is validated first, written to the
 * database, and only then swapped in, so scenes can be edited without restarting the server.
 */
public final class SceneManager implements Service, SceneCatalog {

    private final SceneRepository repository;
    private final SceneValidator validator;
    private final ScenesLogger log;
    private final Map<String, SceneDefinition> scenes = new ConcurrentHashMap<>();

    public SceneManager(SceneRepository repository, SceneValidator validator, ScenesLogger log) {
        this.repository = repository;
        this.validator = validator;
        this.log = log;
    }

    @Override
    public String name() {
        return "scene-manager";
    }

    @Override
    public void start() throws Exception {
        reload();
    }

    @Override
    public void stop() {
        scenes.clear();
    }

    /** Reloads all scenes from the database. Invalid scenes are skipped and logged. */
    public synchronized List<String> reload() throws SQLException {
        SceneRepository.LoadResult loaded = repository.loadAll();
        List<String> problems = new ArrayList<>(loaded.errors());
        Map<String, SceneDefinition> fresh = new ConcurrentHashMap<>();
        for (SceneDefinition scene : loaded.scenes()) {
            List<String> errors = validator.validate(scene);
            if (errors.isEmpty()) {
                fresh.put(scene.id(), scene);
            } else {
                problems.add("scene '" + scene.id() + "': " + String.join("; ", errors));
            }
        }
        problems.forEach(p -> log.warn("Scene not loaded: " + p));
        scenes.clear();
        scenes.putAll(fresh);
        log.info("Loaded " + scenes.size() + " scenes.");
        return problems;
    }

    @Override
    public Optional<SceneDefinition> find(String id) {
        return Optional.ofNullable(scenes.get(id));
    }

    @Override
    public List<SceneDefinition> all() {
        return scenes.values().stream().sorted(Comparator.comparing(SceneDefinition::id)).toList();
    }

    public synchronized SceneResult create(SceneDefinition scene) {
        if (scenes.containsKey(scene.id())) {
            return SceneResult.failure("a scene with id '" + scene.id() + "' already exists");
        }
        return store(scene);
    }

    /** Replaces an existing scene with an edited version. */
    public synchronized SceneResult update(SceneDefinition scene) {
        if (!scenes.containsKey(scene.id())) {
            return SceneResult.failure("scene '" + scene.id() + "' does not exist");
        }
        return store(scene);
    }

    public synchronized SceneResult delete(String id) {
        if (!scenes.containsKey(id)) {
            return SceneResult.failure("scene '" + id + "' does not exist");
        }
        try {
            repository.delete(id);
        } catch (SQLException e) {
            return databaseFailure(e);
        }
        return SceneResult.success(scenes.remove(id));
    }

    public synchronized SceneResult duplicate(String id, String newId) {
        SceneDefinition source = scenes.get(id);
        if (source == null) {
            return SceneResult.failure("scene '" + id + "' does not exist");
        }
        if (scenes.containsKey(newId)) {
            return SceneResult.failure("a scene with id '" + newId + "' already exists");
        }
        return store(source.withId(newId).withName(source.name() + " (copy)"));
    }

    public synchronized SceneResult rename(String id, String newName) {
        return edit(id, s -> s.withName(newName));
    }

    public synchronized SceneResult setEnabled(String id, boolean enabled) {
        return edit(id, s -> s.withEnabled(enabled));
    }

    public synchronized SceneResult setPriority(String id, int priority) {
        return edit(id, s -> s.withPriority(priority));
    }

    public synchronized SceneResult setTrigger(String id, TriggerSpec trigger) {
        return edit(id, s -> s.withTrigger(trigger));
    }

    public synchronized SceneResult setCooldown(String id, long cooldownMillis) {
        return edit(id, s -> s.withCooldown(cooldownMillis));
    }

    /** Reorders actions; the list must contain every existing action id exactly once. */
    public synchronized SceneResult reorderActions(String id, List<String> orderedActionIds) {
        SceneDefinition scene = scenes.get(id);
        if (scene == null) {
            return SceneResult.failure("scene '" + id + "' does not exist");
        }
        Set<String> existing = new HashSet<>();
        scene.actions().forEach(a -> existing.add(a.id()));
        if (orderedActionIds.size() != existing.size() || !existing.equals(new HashSet<>(orderedActionIds))) {
            return SceneResult.failure("the new order must list every action of the scene exactly once");
        }
        Map<String, ActionDefinition> byId = new ConcurrentHashMap<>();
        scene.actions().forEach(a -> byId.put(a.id(), a));
        List<ActionDefinition> reordered = new ArrayList<>();
        for (int i = 0; i < orderedActionIds.size(); i++) {
            reordered.add(byId.get(orderedActionIds.get(i)).withOrder(i));
        }
        return store(scene.withActions(reordered));
    }

    public Collection<String> actionTypes(ActionRegistry registry) {
        return registry.types();
    }

    private SceneResult edit(String id, java.util.function.UnaryOperator<SceneDefinition> change) {
        SceneDefinition scene = scenes.get(id);
        if (scene == null) {
            return SceneResult.failure("scene '" + id + "' does not exist");
        }
        return store(change.apply(scene));
    }

    private SceneResult store(SceneDefinition scene) {
        List<String> errors = validator.validate(scene);
        if (!errors.isEmpty()) {
            return SceneResult.failure(errors);
        }
        try {
            repository.save(scene, System.currentTimeMillis());
        } catch (SQLException e) {
            return databaseFailure(e);
        }
        scenes.put(scene.id(), scene);
        return SceneResult.success(scene);
    }

    private SceneResult databaseFailure(SQLException e) {
        log.error("Database error while saving scene", e);
        return SceneResult.failure("database error: " + e.getMessage());
    }
}
