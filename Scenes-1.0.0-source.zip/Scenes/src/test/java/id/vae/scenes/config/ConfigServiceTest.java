package id.vae.scenes.config;

import id.vae.scenes.util.ScenesLogger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ConfigServiceTest {

    @TempDir
    Path dir;

    private ConfigService config;

    @BeforeEach
    void setUp() {
        config = new ConfigService(dir, name -> getClass().getResourceAsStream("/" + name),
                new ScenesLogger(Logger.getLogger("test"), false));
    }

    @Test
    void defaultsAreCopiedAndLoaded() throws Exception {
        config.start();

        assertTrue(Files.exists(dir.resolve("config.yml")));
        assertTrue(Files.exists(dir.resolve("database.yml")));
        assertFalse(config.general().debug());
        assertEquals(10, config.general().maxConcurrentScenes());
        assertEquals(10, config.general().maxCameraSessions());
        assertEquals("data/scenes.db", config.database().file());
        assertEquals(10, config.database().backupKeep());
        assertEquals("AUTO", config.camera().backend());
        assertEquals("NONE", config.camera().bedrockBackend());
        assertEquals(96.0, config.camera().maxDistance(), 1e-9);
        assertTrue(config.hooks().authMe());
        assertEquals(40, config.hooks().spawnDelayTicks());
        assertTrue(config.hooks().rtpEnabled());
        assertEquals(List.of("rtp", "wild", "randomtp"), config.hooks().rtpCommands());
        assertEquals(15_000, config.hooks().rtpTimeoutMillis());
        assertEquals(16, config.hooks().rtpMinDistance());
    }

    @Test
    void invalidReloadKeepsPreviousSettingsAndAdminFile() throws Exception {
        config.start();
        Files.writeString(dir.resolve("config.yml"), "limits:\n  max-concurrent-scenes: 0\n");

        ConfigService.ReloadResult result = config.reload();

        assertFalse(result.ok());
        assertFalse(result.errors().isEmpty());
        assertEquals(10, config.general().maxConcurrentScenes());
        assertEquals("limits:\n  max-concurrent-scenes: 0\n", Files.readString(dir.resolve("config.yml")));
    }

    @Test
    void validReloadAppliesAdminChanges() throws Exception {
        config.start();
        Files.writeString(dir.resolve("config.yml"), "limits:\n  max-concurrent-scenes: 3\n");

        assertTrue(config.reload().ok());
        assertEquals(3, config.general().maxConcurrentScenes());
    }

    @Test
    void databasePathMustStayInsidePluginFolder() throws Exception {
        config.start();
        Files.writeString(dir.resolve("database.yml"), "file: ../outside.db\n");

        assertFalse(config.reload().ok());
        assertEquals("data/scenes.db", config.database().file());
    }

    @Test
    void theCameraBackendMustBeKnown() throws Exception {
        config.start();
        Files.writeString(dir.resolve("config.yml"), "camera:\n  backend: HOLOGRAM\n");

        assertFalse(config.reload().ok());
        assertEquals("AUTO", config.camera().backend());

        Files.writeString(dir.resolve("config.yml"), "camera:\n  backend: spectator\n  bedrock-backend: spectator\n");
        assertTrue(config.reload().ok());
        assertEquals("SPECTATOR", config.camera().backend());
        assertEquals("SPECTATOR", config.camera().bedrockBackend());
    }

    @Test
    void rtpCommandsAreNormalisedAndValidated() throws Exception {
        config.start();
        Files.writeString(dir.resolve("config.yml"), "rtp:\n  commands: ['/RTP', wild]\n");
        assertTrue(config.reload().ok());
        assertEquals(List.of("rtp", "wild"), config.hooks().rtpCommands());

        Files.writeString(dir.resolve("config.yml"), "rtp:\n  commands: ['not a command!']\n");
        assertFalse(config.reload().ok());
        assertEquals(List.of("rtp", "wild"), config.hooks().rtpCommands());
    }

    @Test
    void startFailsOnInvalidConfiguration() throws Exception {
        Files.createDirectories(dir);
        Files.writeString(dir.resolve("database.yml"), "backup:\n  keep: 0\n");

        assertThrows(IllegalStateException.class, config::start);
    }

    @Test
    void settingsAreUnavailableBeforeStart() {
        assertThrows(IllegalStateException.class, config::general);
    }
}
