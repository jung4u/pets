package id.vae.scenes.particle;

import java.util.UUID;

public interface ParticleControl {

    /** Starts an effect for the player. The tag lets PARTICLE_STOP end it later. */
    void start(UUID player, ParticleSpec spec, String tag);

    /** Stops effects with the tag, or every effect of the player when the tag is null. */
    void stop(UUID player, String tagOrNull);

    /** Stops everything for the player. Call when a scene run ends. */
    void endScene(UUID player);
}
