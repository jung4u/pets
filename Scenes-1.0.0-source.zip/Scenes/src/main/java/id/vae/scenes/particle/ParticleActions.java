package id.vae.scenes.particle;

import id.vae.scenes.camera.Vec3;
import id.vae.scenes.scene.ActionContext;
import id.vae.scenes.scene.ActionDefinition;
import id.vae.scenes.scene.ActionHandler;
import id.vae.scenes.scene.ActionHandlers;
import id.vae.scenes.scene.ActionRegistry;
import id.vae.scenes.scene.ActionResult;
import id.vae.scenes.scene.ConfigValues;
import id.vae.scenes.scene.PresetLibrary;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * PARTICLE_SPAWN, PARTICLE_FOLLOW and PARTICLE_STOP.
 *
 * <p>Settings: preset or type, shape (POINT, RING, SPHERE, SPIRAL), amount, offset {x, y, z}, speed, radius,
 * height, direction {x, y, z}, color (hex, DUST and ENTITY_EFFECT), interval-ms (default 250), anchor
 * (PLAYER, CAMERA, WORLD with position {x, y, z}), follow, audience (PLAYER or NEARBY), tag (for
 * PARTICLE_STOP). The action duration is how long the effect lasts; 0 emits once.
 * PARTICLE_FOLLOW is PARTICLE_SPAWN with follow on by default.
 */
public final class ParticleActions {

    private static final Pattern TYPE = Pattern.compile("[A-Z][A-Z0-9_]*");
    private static final String CLEANUP_KEY = "particle.cleanup";

    private ParticleActions() {
    }

    public static void registerAll(ActionRegistry registry, ParticleControl particles, PresetLibrary library) {
        registry.register(new Spawn("PARTICLE_SPAWN", false, particles, library));
        registry.register(new Spawn("PARTICLE_FOLLOW", true, particles, library));
        registry.register(new Stop(particles));
    }

    private static boolean hasPoint(Map<String, Object> m) {
        return m.get("x") instanceof Number && m.get("y") instanceof Number && m.get("z") instanceof Number;
    }

    private static Vec3 point(Map<String, Object> m) {
        return new Vec3(ConfigValues.doubleValue(m, "x", 0), ConfigValues.doubleValue(m, "y", 0),
                ConfigValues.doubleValue(m, "z", 0));
    }

    private static final class Spawn implements ActionHandler {
        private final String type;
        private final boolean followByDefault;
        private final ParticleControl particles;
        private final PresetLibrary library;

        Spawn(String type, boolean followByDefault, ParticleControl particles, PresetLibrary library) {
            this.type = type;
            this.followByDefault = followByDefault;
            this.particles = particles;
            this.library = library;
        }

        @Override
        public String type() {
            return type;
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            List<String> errors = new ArrayList<>();
            String preset = ConfigValues.string(action.config(), "preset", "");
            if (!preset.isEmpty() && !library.has(preset)) {
                errors.add("unknown particle preset '" + preset + "'");
            }
            Map<String, Object> cfg = library.resolve(action.config());
            String particle = ConfigValues.string(cfg, "type", "").toUpperCase(Locale.ROOT);
            if (particle.isEmpty()) {
                errors.add(type + " needs a 'type' or a 'preset'");
            } else if (!TYPE.matcher(particle).matches()) {
                errors.add("invalid particle type '" + particle + "'");
            }
            if (!List.of("POINT", "RING", "SPHERE", "SPIRAL")
                    .contains(ConfigValues.string(cfg, "shape", "POINT").toUpperCase(Locale.ROOT))) {
                errors.add("'shape' must be POINT, RING, SPHERE or SPIRAL");
            }
            String anchor = ConfigValues.string(cfg, "anchor", "PLAYER").toUpperCase(Locale.ROOT);
            if (!List.of("PLAYER", "CAMERA", "WORLD").contains(anchor)) {
                errors.add("'anchor' must be PLAYER, CAMERA or WORLD");
            } else if (anchor.equals("WORLD") && !hasPoint(ConfigValues.map(cfg, "position"))) {
                errors.add("anchor WORLD needs a 'position' with x, y and z");
            }
            long amount = ConfigValues.longValue(cfg, "amount", 10);
            if (amount < 1 || amount > 10_000) {
                errors.add("'amount' must be between 1 and 10000");
            }
            if (ConfigValues.doubleValue(cfg, "radius", 1.0) < 0) {
                errors.add("'radius' must not be negative");
            }
            if (ConfigValues.longValue(cfg, "interval-ms", 250) < 50) {
                errors.add("'interval-ms' must be at least 50");
            }
            String color = ConfigValues.string(cfg, "color", "");
            if (!color.isEmpty() && !ActionHandlers.validHex(color)) {
                errors.add("'color' must be a hex colour like #a855f7");
            }
            String audience = ConfigValues.string(cfg, "audience", "PLAYER").toUpperCase(Locale.ROOT);
            if (!audience.equals("PLAYER") && !audience.equals("NEARBY")) {
                errors.add("'audience' must be PLAYER or NEARBY");
            }
            return errors;
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            Map<String, Object> cfg = library.resolve(action.config());
            Map<String, Object> position = ConfigValues.map(cfg, "position");
            Map<String, Object> offset = ConfigValues.map(cfg, "offset");
            Map<String, Object> direction = ConfigValues.map(cfg, "direction");
            String color = ConfigValues.string(cfg, "color", "");
            ParticleSpec spec = new ParticleSpec(
                    ConfigValues.string(cfg, "type", ""),
                    ParticleSpec.Shape.valueOf(ConfigValues.string(cfg, "shape", "POINT").toUpperCase(Locale.ROOT)),
                    (int) ConfigValues.longValue(cfg, "amount", 10),
                    hasPoint(offset) ? point(offset) : null,
                    ConfigValues.doubleValue(cfg, "speed", 0),
                    ConfigValues.doubleValue(cfg, "radius", 1.0),
                    ConfigValues.doubleValue(cfg, "height", 1.0),
                    hasPoint(direction) ? point(direction) : null,
                    ActionHandlers.validHex(color) ? ActionHandlers.normalizeHex(color) : "",
                    ParticleSpec.Anchor.valueOf(ConfigValues.string(cfg, "anchor", "PLAYER").toUpperCase(Locale.ROOT)),
                    hasPoint(position) ? point(position) : null,
                    ConfigValues.bool(cfg, "follow", followByDefault),
                    "NEARBY".equalsIgnoreCase(ConfigValues.string(cfg, "audience", "PLAYER")),
                    action.durationMillis(),
                    ConfigValues.longValue(cfg, "interval-ms", 250));
            var player = ctx.player();
            ActionHandlers.cleanupOnce(ctx, CLEANUP_KEY, () -> particles.endScene(player));
            particles.start(player, spec, ConfigValues.string(cfg, "tag", action.id()));
            return ActionResult.done();
        }
    }

    private static final class Stop implements ActionHandler {
        private final ParticleControl particles;

        Stop(ParticleControl particles) {
            this.particles = particles;
        }

        @Override
        public String type() {
            return "PARTICLE_STOP";
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            String tag = ConfigValues.string(action.config(), "tag", "all");
            particles.stop(ctx.player(), tag.equalsIgnoreCase("all") ? null : tag);
            return ActionResult.done();
        }
    }
}
