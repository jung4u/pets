package id.vae.scenes.scene;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.BooleanSupplier;

/**
 * Built-in flow-control actions: DELAY, WAIT_FOR_CONDITION, END_SCENE, SKIP, BRANCH, SET_VARIABLE.
 * A "condition" setting is a map such as {type: WORLD, world: world_nether}.
 */
public final class ControlActions {

    private ControlActions() {
    }

    public static void registerAll(ActionRegistry registry) {
        registry.register(new Delay());
        registry.register(new WaitForCondition());
        registry.register(new EndScene());
        registry.register(new Skip());
        registry.register(new Branch());
        registry.register(new SetVariable());
    }

    private static ConditionSpec condition(ActionDefinition action) {
        return ConditionSpec.fromMap(ConfigValues.map(action.config(), "condition"));
    }

    private static List<String> validateCondition(ActionDefinition action, ConditionEvaluator evaluator) {
        Map<String, Object> raw = ConfigValues.map(action.config(), "condition");
        if (raw.isEmpty()) {
            return List.of(action.type() + " needs a 'condition'");
        }
        return evaluator.validate(ConditionSpec.fromMap(raw));
    }

    /** Pauses the timeline for the action's duration. */
    static final class Delay implements ActionHandler {
        @Override
        public String type() {
            return "DELAY";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            return action.durationMillis() > 0 ? List.of() : List.of("DELAY needs a duration greater than 0");
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            return ActionResult.waitFor(() -> false, action.durationMillis(), 50, false);
        }
    }

    /** Pauses until a condition holds. Settings: condition, timeout-ms (default 10000), on-timeout (continue|abort). */
    static final class WaitForCondition implements ActionHandler {
        private final ConditionEvaluator validator = new ConditionEvaluator(new NoPlayers());

        @Override
        public String type() {
            return "WAIT_FOR_CONDITION";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            List<String> errors = new ArrayList<>(validateCondition(action, validator));
            String onTimeout = ConfigValues.string(action.config(), "on-timeout", "continue");
            if (!onTimeout.equalsIgnoreCase("continue") && !onTimeout.equalsIgnoreCase("abort")) {
                errors.add("WAIT_FOR_CONDITION 'on-timeout' must be continue or abort");
            }
            return errors;
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            ConditionSpec spec = condition(action);
            UUID player = ctx.player();
            BooleanSupplier ready = () -> ctx.conditions().matches(spec, player, ctx.variables());
            long timeout = ConfigValues.longValue(action.config(), "timeout-ms", 10_000);
            long poll = ConfigValues.longValue(action.config(), "poll-ms", 100);
            boolean abort = "abort".equalsIgnoreCase(ConfigValues.string(action.config(), "on-timeout", "continue"));
            return ActionResult.waitFor(ready, timeout, poll, abort);
        }
    }

    static final class EndScene implements ActionHandler {
        @Override
        public String type() {
            return "END_SCENE";
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            return ActionResult.endScene();
        }
    }

    /** Skips the actions listed in the 'actions' setting. */
    static final class Skip implements ActionHandler {
        @Override
        public String type() {
            return "SKIP";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            return ConfigValues.stringList(action.config(), "actions").isEmpty()
                    ? List.of("SKIP needs a non-empty 'actions' list")
                    : List.of();
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            ConfigValues.stringList(action.config(), "actions").forEach(ctx::skip);
            return ActionResult.done();
        }
    }

    /** Evaluates 'condition' and skips the actions in 'then-skip' or 'else-skip'; 'then-end' ends the scene. */
    static final class Branch implements ActionHandler {
        private final ConditionEvaluator validator = new ConditionEvaluator(new NoPlayers());

        @Override
        public String type() {
            return "BRANCH";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            return validateCondition(action, validator);
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            boolean matched = ctx.conditions().matches(condition(action), ctx.player(), ctx.variables());
            if (matched) {
                ConfigValues.stringList(action.config(), "then-skip").forEach(ctx::skip);
                if (ConfigValues.bool(action.config(), "then-end", false)) {
                    return ActionResult.endScene();
                }
            } else {
                ConfigValues.stringList(action.config(), "else-skip").forEach(ctx::skip);
                if (ConfigValues.bool(action.config(), "else-end", false)) {
                    return ActionResult.endScene();
                }
            }
            return ActionResult.done();
        }
    }

    /** Stores a variable (settings: key, value) that conditions can read. */
    static final class SetVariable implements ActionHandler {
        @Override
        public String type() {
            return "SET_VARIABLE";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            return ConfigValues.string(action.config(), "key", "").isBlank()
                    ? List.of("SET_VARIABLE needs 'key'")
                    : List.of();
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            Object value = action.config().get("value");
            ctx.variables().put(ConfigValues.string(action.config(), "key", ""), value == null ? "" : value);
            return ActionResult.done();
        }
    }

    /** Player gateway used only to validate conditions, never to evaluate them. */
    private static final class NoPlayers implements PlayerGateway {
        @Override
        public boolean isOnline(UUID player) {
            return false;
        }

        @Override
        public boolean hasPermission(UUID player, String permission) {
            return false;
        }

        @Override
        public String worldOf(UUID player) {
            return null;
        }

        @Override
        public String nameOf(UUID player) {
            return null;
        }
    }
}
