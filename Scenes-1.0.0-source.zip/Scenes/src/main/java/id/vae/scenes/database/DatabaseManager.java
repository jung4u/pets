package id.vae.scenes.database;

import id.vae.scenes.core.Service;
import id.vae.scenes.util.ScenesLogger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Supplier;
import java.util.stream.Stream;

/**
 * Owns the single SQLite connection. All access is serialized by a lock;
 * use {@link #async} to keep database work off the server main thread.
 */
public final class DatabaseManager implements Service {

    private static final DateTimeFormatter BACKUP_FORMAT =
            DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS").withZone(ZoneId.systemDefault());

    private final Supplier<Path> fileSupplier;
    private final ScenesLogger log;
    private final ReentrantLock lock = new ReentrantLock();
    private Connection connection;
    private volatile ExecutorService executor;

    /** The supplier returns the database file, or null for an in-memory database (tests). */
    public DatabaseManager(Supplier<Path> fileSupplier, ScenesLogger log) {
        this.fileSupplier = fileSupplier;
        this.log = log;
    }

    public static DatabaseManager inMemory(ScenesLogger log) {
        return new DatabaseManager(() -> null, log);
    }

    @Override
    public String name() {
        return "database";
    }

    @Override
    public void start() throws Exception {
        lock.lock();
        try {
            if (connection != null) {
                return;
            }
            Path file = fileSupplier.get();
            String url;
            if (file == null) {
                url = "jdbc:sqlite::memory:";
            } else {
                Path absolute = file.toAbsolutePath();
                Files.createDirectories(absolute.getParent());
                url = "jdbc:sqlite:" + absolute;
            }
            try {
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException e) {
                throw new SQLException("SQLite JDBC driver not found on the classpath", e);
            }
            Connection opened = DriverManager.getConnection(url);
            try {
                try (Statement st = opened.createStatement()) {
                    st.execute("PRAGMA foreign_keys=ON");
                    st.execute("PRAGMA busy_timeout=5000");
                    if (file != null) {
                        st.execute("PRAGMA journal_mode=WAL");
                        st.execute("PRAGMA synchronous=NORMAL");
                    }
                }
                new MigrationRunner(opened, log).migrate();
            } catch (SQLException e) {
                try {
                    opened.close();
                } catch (SQLException closeError) {
                    e.addSuppressed(closeError);
                }
                throw e;
            }
            connection = opened;
            executor = Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "Scenes-DB");
                t.setDaemon(true);
                return t;
            });
            log.info("SQLite connected.");
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void stop() {
        ExecutorService ex = executor;
        executor = null;
        if (ex != null) {
            ex.shutdown();
            try {
                if (!ex.awaitTermination(5, TimeUnit.SECONDS)) {
                    ex.shutdownNow();
                }
            } catch (InterruptedException e) {
                ex.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
        lock.lock();
        try {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    log.error("Failed to close SQLite connection", e);
                }
                connection = null;
                log.info("SQLite connection closed.");
            }
        } finally {
            lock.unlock();
        }
    }

    /** Runs work on the connection while holding the lock (autocommit mode). */
    public <R> R query(SqlFunction<Connection, R> work) throws SQLException {
        lock.lock();
        try {
            return work.apply(requireOpen());
        } finally {
            lock.unlock();
        }
    }

    /** Runs work in a transaction; commits on success and rolls back on any failure. */
    public <R> R transaction(SqlFunction<Connection, R> work) throws SQLException {
        lock.lock();
        try {
            Connection c = requireOpen();
            boolean previous = c.getAutoCommit();
            c.setAutoCommit(false);
            try {
                R result = work.apply(c);
                c.commit();
                return result;
            } catch (SQLException | RuntimeException e) {
                try {
                    c.rollback();
                } catch (SQLException rollbackError) {
                    e.addSuppressed(rollbackError);
                }
                throw e;
            } finally {
                c.setAutoCommit(previous);
            }
        } finally {
            lock.unlock();
        }
    }

    /** Runs work on the dedicated database thread. */
    public <R> CompletableFuture<R> async(SqlFunction<Connection, R> work) {
        ExecutorService ex = executor;
        if (ex == null) {
            return CompletableFuture.failedFuture(new IllegalStateException("Database is not running"));
        }
        try {
            return CompletableFuture.supplyAsync(() -> {
                try {
                    return query(work);
                } catch (SQLException e) {
                    throw new CompletionException(e);
                }
            }, ex);
        } catch (RejectedExecutionException e) {
            return CompletableFuture.failedFuture(e);
        }
    }

    public boolean isHealthy() {
        try {
            return query(c -> {
                try (Statement st = c.createStatement()) {
                    st.execute("SELECT 1");
                    return true;
                }
            });
        } catch (SQLException e) {
            return false;
        }
    }

    /** Writes a consistent copy of the database to the directory and prunes old copies. */
    public Path backup(Path directory, int keep) throws SQLException, IOException {
        lock.lock();
        try {
            Connection c = requireOpen();
            if (fileSupplier.get() == null) {
                throw new IllegalStateException("An in-memory database cannot be backed up");
            }
            Files.createDirectories(directory);
            Path target = directory.resolve("scenes-" + BACKUP_FORMAT.format(Instant.now()) + ".db")
                    .toAbsolutePath();
            if (Files.exists(target)) {
                throw new IOException("Backup target already exists: " + target);
            }
            try (Statement st = c.createStatement()) {
                st.execute("VACUUM INTO '" + target.toString().replace("'", "''") + "'");
            }
            pruneBackups(directory, keep);
            return target;
        } finally {
            lock.unlock();
        }
    }

    private void pruneBackups(Path directory, int keep) throws IOException {
        List<Path> backups;
        try (Stream<Path> files = Files.list(directory)) {
            backups = files
                    .filter(p -> {
                        String n = p.getFileName().toString();
                        return n.startsWith("scenes-") && n.endsWith(".db");
                    })
                    .sorted(Comparator.comparing((Path p) -> p.getFileName().toString()).reversed())
                    .toList();
        }
        for (int i = Math.max(keep, 1); i < backups.size(); i++) {
            try {
                Files.deleteIfExists(backups.get(i));
            } catch (IOException e) {
                log.warn("Could not delete old backup " + backups.get(i).getFileName() + ": " + e.getMessage());
            }
        }
    }

    private Connection requireOpen() throws SQLException {
        Connection c = connection;
        if (c == null) {
            throw new SQLException("Database is not connected");
        }
        return c;
    }
}
