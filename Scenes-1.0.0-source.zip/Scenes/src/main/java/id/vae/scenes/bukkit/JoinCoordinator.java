package id.vae.scenes.bukkit;

import id.vae.scenes.config.HookSettings;
import id.vae.scenes.core.Service;
import id.vae.scenes.database.DatabaseManager;
import id.vae.scenes.database.PlayerRepository;
import id.vae.scenes.database.SettingsRepository;
import id.vae.scenes.scene.TriggerType;
import id.vae.scenes.trigger.TriggerEvent;
import id.vae.scenes.trigger.TriggerManager;
import id.vae.scenes.util.ScenesLogger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Fires the first-join, login and register triggers.
 *
 * <p>With AuthMe installed (and enabled in config.yml) nothing starts until AuthMe reports a login or
 * register, so no scene ever plays while the player is still on the login screen. Without AuthMe the
 * triggers fire a few ticks after the player joined. A player is "new" when the server has never seen
 * them; that is remembered in the database until the first-join scene has been completed, so a player
 * who disconnects in the middle of it gets it again next time.
 */
public final class JoinCoordinator implements Service, Listener {

    private static final String KEY_PREFIX = "first_join.";
    private static final long DUPLICATE_WINDOW_MILLIS = 2000;

    private final Plugin plugin;
    private final Supplier<HookSettings> settings;
    private final TriggerManager triggers;
    private final DatabaseManager db;
    private final PlayerRepository players;
    private final SettingsRepository kv;
    private final ScenesLogger log;
    private final Set<UUID> pendingFirst = new HashSet<>();
    private final Map<UUID, Long> lastAuth = new HashMap<>();
    private boolean authMeActive;

    public JoinCoordinator(Plugin plugin, Supplier<HookSettings> settings, TriggerManager triggers,
                           DatabaseManager db, PlayerRepository players, SettingsRepository kv, ScenesLogger log) {
        this.plugin = plugin;
        this.settings = settings;
        this.triggers = triggers;
        this.db = db;
        this.players = players;
        this.kv = kv;
        this.log = log;
    }

    @Override
    public String name() {
        return "join";
    }

    @Override
    public void start() {
        PluginManager manager = plugin.getServer().getPluginManager();
        authMeActive = settings.get().authMe() && manager.isPluginEnabled("AuthMe");
        if (authMeActive) {
            register(manager, "fr.xephi.authme.events.LoginEvent", id -> later(() -> authenticated(id)));
            register(manager, "fr.xephi.authme.events.RegisterEvent", id -> later(() -> registered(id)));
        }
        log.info("Join hooks ready (AuthMe " + (authMeActive ? "active" : "not used") + ").");
    }

    @Override
    public void stop() {
        pendingFirst.clear();
        lastAuth.clear();
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        String name = player.getName();
        boolean fresh = !player.hasPlayedBefore();
        if (fresh) {
            pendingFirst.add(id);
        }
        db.async(c -> {
            long now = System.currentTimeMillis();
            players.upsert(id, name, now);
            if (fresh) {
                kv.set(KEY_PREFIX + id, "1", now);
            }
            return null;
        }).exceptionally(error -> {
            log.error("Could not record the join of " + name, error);
            return null;
        });
        if (!authMeActive) {
            later(() -> authenticated(id));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        pendingFirst.remove(id);
        lastAuth.remove(id);
    }

    private void later(Runnable action) {
        Bukkit.getScheduler().runTaskLater(plugin, action, settings.get().spawnDelayTicks());
    }

    /** Main thread. The player is in the game and, with AuthMe, logged in. */
    private void authenticated(UUID id) {
        Player player = Bukkit.getPlayer(id);
        if (player == null || !player.isOnline()) {
            return;
        }
        long now = System.currentTimeMillis();
        Long last = lastAuth.get(id);
        if (last != null && now - last < DUPLICATE_WINDOW_MILLIS) {
            return;
        }
        lastAuth.put(id, now);
        boolean pendingInMemory = pendingFirst.contains(id);
        db.async(c -> pendingInMemory || kv.get(KEY_PREFIX + id).isPresent())
                .whenComplete((first, error) -> Bukkit.getScheduler().runTask(plugin,
                        () -> fire(id, error == null && Boolean.TRUE.equals(first))));
    }

    private void fire(UUID id, boolean first) {
        Player player = Bukkit.getPlayer(id);
        if (player == null || !player.isOnline()) {
            return;
        }
        String world = player.getWorld().getName();
        if (first) {
            triggers.fire(TriggerEvent.of(TriggerType.FIRST_JOIN, id, world));
        }
        triggers.fire(TriggerEvent.of(TriggerType.LOGIN_SUCCESS, id, world));
    }

    private void registered(UUID id) {
        Player player = Bukkit.getPlayer(id);
        if (player != null && player.isOnline()) {
            triggers.fire(TriggerEvent.of(TriggerType.REGISTER_SUCCESS, id, player.getWorld().getName()));
        }
    }

    /** Listens to an AuthMe event by class name, so Scenes needs no AuthMe dependency to build or load. */
    @SuppressWarnings("unchecked")
    private void register(PluginManager manager, String className, Consumer<UUID> handler) {
        try {
            Class<? extends Event> type = (Class<? extends Event>) Class.forName(className);
            Method getPlayer = type.getMethod("getPlayer");
            manager.registerEvent(type, this, EventPriority.MONITOR, (listener, event) -> {
                if (!type.isInstance(event)) {
                    return;
                }
                try {
                    Player player = (Player) getPlayer.invoke(event);
                    handler.accept(player.getUniqueId());
                } catch (ReflectiveOperationException | ClassCastException e) {
                    log.error("Could not read the player of " + className, e);
                }
            }, plugin);
        } catch (ReflectiveOperationException | ClassCastException e) {
            log.warn("AuthMe event " + className + " is not available (" + e.getMessage()
                    + "); login scenes will use the plain join instead.");
            authMeActive = false;
        }
    }
}
