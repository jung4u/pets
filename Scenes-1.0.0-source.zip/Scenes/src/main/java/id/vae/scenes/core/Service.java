package id.vae.scenes.core;

/** A plugin component with an explicit lifecycle. */
public interface Service {

    /** Short name used in logs. */
    String name();

    /** Starts the service. Throwing aborts plugin startup. */
    void start() throws Exception;

    /** Stops the service. Must be safe to call even after a partial start. */
    void stop();
}
