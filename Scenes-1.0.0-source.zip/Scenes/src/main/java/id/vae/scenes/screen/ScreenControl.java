package id.vae.scenes.screen;

import java.util.UUID;

/** What screen actions need from the screen engine. */
public interface ScreenControl {

    /** Starts the effect, replacing the one that is running. */
    void play(UUID player, ScreenPlan plan);

    /** Removes every screen effect and restores what the player had before. Safe to call anytime. */
    void clear(UUID player);
}
