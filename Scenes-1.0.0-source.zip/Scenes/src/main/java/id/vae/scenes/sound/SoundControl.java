package id.vae.scenes.sound;

import java.util.UUID;

/** What sound actions need from the sound engine. */
public interface SoundControl {

    void play(UUID player, SoundSpec spec);

    /** Stops one sound key started by scenes for this player; null stops every sound a scene started. */
    void stop(UUID player, String keyOrNull);

    /** Cancels pending repeats and stops sounds marked stop-on-end. Call when a scene run ends. */
    void endScene(UUID player);
}
