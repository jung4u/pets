package id.vae.scenes.config;

import java.util.List;

/** Settings for the join, AuthMe and RTP hooks. */
public record HookSettings(
        boolean authMe,
        int spawnDelayTicks,
        boolean rtpEnabled,
        List<String> rtpCommands,
        long rtpTimeoutMillis,
        int rtpMinDistance) {
}
