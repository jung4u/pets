package id.vae.scenes.subtitle;

import java.util.List;

/**
 * A subtitle line. The text is MiniMessage and may contain %player_name%, %player_world% and
 * PlaceholderAPI placeholders. The duration includes the fades.
 *
 * @param delayMillis wait before showing (used inside a queue)
 * @param repeat      extra showings after the first
 */
public record SubtitleSpec(String text, String color, List<String> gradient, boolean bold, boolean italic,
                           boolean underline, SubtitlePosition position, long durationMillis, long fadeInMillis,
                           long fadeOutMillis, long delayMillis, int priority, int order, int repeat,
                           long repeatIntervalMillis, boolean enabled, String soundKey, float volume, float pitch) {

    public SubtitleSpec {
        text = text == null ? "" : text;
        color = color == null ? "" : color;
        gradient = gradient == null ? List.of() : List.copyOf(gradient);
        position = position == null ? SubtitlePosition.CENTER : position;
        soundKey = soundKey == null ? "" : soundKey;
        repeat = Math.max(0, repeat);
    }

    public static SubtitleSpec plain(String text, long durationMillis) {
        return new SubtitleSpec(text, "", List.of(), false, false, false, SubtitlePosition.CENTER, durationMillis,
                250, 250, 0, 0, 0, 0, 0, true, "", 1f, 1f);
    }
}
