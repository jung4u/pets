package id.vae.scenes.bukkit;

import id.vae.scenes.scene.SceneScheduler;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

/** Runs scene work on the Paper main thread (one tick is 50 ms). */
public final class BukkitSceneScheduler implements SceneScheduler {

    private final Plugin plugin;

    public BukkitSceneScheduler(Plugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public long nowMillis() {
        return System.currentTimeMillis();
    }

    @Override
    public Task runLater(long delayMillis, Runnable runnable) {
        long ticks = Math.max(1L, (delayMillis + 49L) / 50L);
        BukkitTask task = plugin.getServer().getScheduler().runTaskLater(plugin, runnable, ticks);
        return task::cancel;
    }
}
