# Commands and permissions

## /scene (permission `scenes.play`)

| Command | Permission | What it does |
| --- | --- | --- |
| `/scene list` | `scenes.play` | lists the scenes with their trigger and whether they are enabled |
| `/scene start <player> <scene>` | `scenes.play` | plays a scene for an online player (ignores cooldown, play-once and conditions) |
| `/scene stop <player>` | `scenes.stop` | stops the player's scene and restores everything it changed |
| `/scene stopall` | `scenes.stop` | stops every running scene |
| `/scene reset <player or uuid> [scene]` | `scenes.manage` | forgets that the player has seen a scene (or all scenes), so play-once scenes can play again |

## /scenes (permission `scenes.admin`)

| Command | Permission | What it does |
| --- | --- | --- |
| `/scenes reload` | `scenes.reload` | re-reads the config and preset files and imports new scene files; invalid files are reported and ignored |
| `/scenes enable <scene>` | `scenes.manage` | enables a scene |
| `/scenes disable <scene>` | `scenes.manage` | disables a scene |
| `/scenes delete <scene> confirm` | `scenes.manage` | deletes a scene (export it first if you want a copy) |
| `/scenes export <scene> [overwrite]` | `scenes.manage` | writes `scenes/<scene>.yml` so you can edit it |
| `/scenes import <file> [replace]` | `scenes.manage` | imports `scenes/<file>.yml`; `replace` overwrites a scene with the same id |

## Permissions

| Permission | Default | Meaning |
| --- | --- | --- |
| `scenes.admin` | op | everything below |
| `scenes.reload` | op | `/scenes reload` |
| `scenes.manage` | op | enable, disable, delete, import, export, reset |
| `scenes.play` | op | `/scene list`, `/scene start` |
| `scenes.stop` | op | `/scene stop`, `/scene stopall` |

Players without permission do not see these commands or their arguments in tab completion. A scene
can also require a permission of the player in its trigger (`trigger.permission`) or in a condition.

Grant `scenes.play` together with `scenes.stop` to anyone who should stop scenes: the `/scene` command is
hidden from players who do not have `scenes.play`.
