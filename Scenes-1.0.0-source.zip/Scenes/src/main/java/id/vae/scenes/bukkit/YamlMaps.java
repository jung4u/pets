package id.vae.scenes.bukkit;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** Reads YAML into plain maps, so the scene code never sees Bukkit configuration types. */
public final class YamlMaps {

    private YamlMaps() {
    }

    public static Map<String, Object> load(Path path) throws IOException, InvalidConfigurationException {
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            return read(reader);
        }
    }

    public static Map<String, Object> load(InputStream in) throws IOException, InvalidConfigurationException {
        try (Reader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
            return read(reader);
        }
    }

    private static Map<String, Object> read(Reader reader) throws IOException, InvalidConfigurationException {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.load(reader);
        return toMap(yaml);
    }

    /** Writes a map as YAML text (keys must not contain dots). */
    public static String toYaml(Map<String, Object> map) {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            yaml.set(entry.getKey(), entry.getValue());
        }
        return yaml.saveToString();
    }

    public static Map<String, Object> toMap(ConfigurationSection section) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (String key : section.getKeys(false)) {
            Object value = section.get(key);
            out.put(key, value instanceof ConfigurationSection nested ? toMap(nested) : value);
        }
        return out;
    }
}
