package id.vae.scenes.bukkit;

import id.vae.scenes.camera.CameraPose;
import id.vae.scenes.camera.CameraShake;
import id.vae.scenes.camera.PoseSource;
import org.bukkit.entity.ArmorStand;

import java.util.UUID;

/** Runtime state of one player's camera. Touched only on the main thread. */
final class CameraSession {

    final UUID player;
    final ArmorStand entity;
    final CameraBackend backend;

    CameraPose basePose;
    PoseSource source;
    long sourceStart;
    CameraShake shake;
    long shakeStart;

    CameraSession(UUID player, ArmorStand entity, CameraBackend backend, CameraPose start) {
        this.player = player;
        this.entity = entity;
        this.backend = backend;
        this.basePose = start;
    }
}
