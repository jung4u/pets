package id.vae.scenes.screen;

/** Effects on different channels run together; a new effect replaces the running one on its own channel. */
public enum ScreenChannel {
    BLACK,
    DARKNESS,
    VIGNETTE,
    BLUR,
    FLASH
}
