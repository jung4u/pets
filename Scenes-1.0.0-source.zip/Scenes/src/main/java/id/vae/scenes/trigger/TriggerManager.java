package id.vae.scenes.trigger;

import id.vae.scenes.core.Service;
import id.vae.scenes.scene.PlayerGateway;
import id.vae.scenes.scene.SceneCatalog;
import id.vae.scenes.scene.SceneDefinition;
import id.vae.scenes.scene.SceneEngine;
import id.vae.scenes.scene.TriggerSpec;
import id.vae.scenes.util.ScenesLogger;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Matches trigger events to scenes (type, world, permission, argument), orders them by priority
 * and hands them to the scene engine, which enforces play-once, cooldown and conflicts.
 */
public final class TriggerManager implements Service {

    public record Fired(String sceneId, SceneEngine.StartResult result) {
    }

    private final SceneCatalog catalog;
    private final SceneEngine engine;
    private final PlayerGateway players;
    private final ScenesLogger log;

    public TriggerManager(SceneCatalog catalog, SceneEngine engine, PlayerGateway players, ScenesLogger log) {
        this.catalog = catalog;
        this.engine = engine;
        this.players = players;
        this.log = log;
    }

    @Override
    public String name() {
        return "triggers";
    }

    @Override
    public void start() {
        // Stateless.
    }

    @Override
    public void stop() {
        // Stateless.
    }

    /** Fires an event and returns what happened for every scene that matched. */
    public List<Fired> fire(TriggerEvent event) {
        List<SceneDefinition> matching = catalog.all().stream()
                .filter(scene -> matches(scene, event))
                .sorted(Comparator.comparingInt(SceneDefinition::priority).reversed()
                        .thenComparing(SceneDefinition::id))
                .toList();

        List<Fired> fired = new ArrayList<>();
        for (SceneDefinition scene : matching) {
            SceneEngine.StartResult result;
            try {
                result = engine.start(event.player(), scene.id(), false);
            } catch (RuntimeException e) {
                log.sceneError(scene.id(), "trigger", String.valueOf(e.getMessage()), e);
                continue;
            }
            fired.add(new Fired(scene.id(), result));
            log.debug("Trigger " + event.type() + " -> scene " + scene.id() + ": " + result);
        }
        return fired;
    }

    private boolean matches(SceneDefinition scene, TriggerEvent event) {
        TriggerSpec trigger = scene.trigger();
        if (!scene.enabled() || trigger.type() != event.type()) {
            return false;
        }
        if (!trigger.world().isEmpty() && !trigger.world().equalsIgnoreCase(event.world())) {
            return false;
        }
        if (!trigger.argument().isEmpty() && !trigger.argument().equalsIgnoreCase(event.argument())) {
            return false;
        }
        return trigger.permission().isEmpty() || players.hasPermission(event.player(), trigger.permission());
    }
}
