package id.vae.scenes.camera;

import java.util.Optional;
import java.util.UUID;

/** What camera actions need from the camera engine, kept free of Bukkit so it can be tested. */
public interface CameraControl {

    /** Starts a camera session at the pose. Returns false when no camera backend is usable for the player. */
    boolean begin(UUID player, CameraPose start);

    boolean isActive(UUID player);

    /** Last pose of the camera, without shake. */
    Optional<CameraPose> currentPose(UUID player);

    /** Replaces the running movement. The camera holds the final pose when it ends. */
    void play(UUID player, PoseSource source);

    void shake(UUID player, CameraShake shake);

    /** Ends the session and restores the player. Safe to call when no session exists. */
    void end(UUID player);

    /** The player's eye position and facing. */
    Optional<CameraPose> playerEyePose(UUID player);

    Optional<String> playerWorld(UUID player);

    /** Farthest allowed distance between the player and any waypoint, in blocks. */
    double maxDistance();
}
