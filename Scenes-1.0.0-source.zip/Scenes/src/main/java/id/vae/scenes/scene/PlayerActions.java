package id.vae.scenes.scene;

import java.util.List;
import java.util.UUID;

/** PLAYER_LOCK and PLAYER_UNLOCK. A lock taken by a scene is always released when the scene ends. */
public final class PlayerActions {

    static final String LOCK_KEY = "player.lock";

    private PlayerActions() {
    }

    public static void registerAll(ActionRegistry registry, PlayerLocks locks) {
        registry.register(new Lock(locks));
        registry.register(new Unlock(locks));
    }

    static final class Lock implements ActionHandler {
        private final PlayerLocks locks;

        Lock(PlayerLocks locks) {
            this.locks = locks;
        }

        @Override
        public String type() {
            return "PLAYER_LOCK";
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            if (ctx.variables().putIfAbsent(LOCK_KEY, Boolean.TRUE) == null) {
                UUID player = ctx.player();
                locks.lock(player);
                ctx.addCleanup(() -> {
                    if (ctx.variables().remove(LOCK_KEY) != null) {
                        locks.unlock(player);
                    }
                });
            }
            return ActionResult.done();
        }
    }

    static final class Unlock implements ActionHandler {
        private final PlayerLocks locks;

        Unlock(PlayerLocks locks) {
            this.locks = locks;
        }

        @Override
        public String type() {
            return "PLAYER_UNLOCK";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            return List.of();
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            if (ctx.variables().remove(LOCK_KEY) != null) {
                locks.unlock(ctx.player());
            }
            return ActionResult.done();
        }
    }
}
