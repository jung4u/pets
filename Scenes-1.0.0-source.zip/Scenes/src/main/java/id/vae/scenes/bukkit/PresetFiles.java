package id.vae.scenes.bukkit;

import id.vae.scenes.config.ConfigService;
import id.vae.scenes.core.Service;
import id.vae.scenes.scene.PresetLibrary;
import id.vae.scenes.util.ScenesLogger;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Loads sounds/presets.yml and particles/presets.yml. Missing files are created from the bundled
 * defaults; admin edits are never overwritten. A broken file keeps the previous presets.
 */
public final class PresetFiles implements Service {

    private static final String SOUNDS = "sounds/presets.yml";
    private static final String PARTICLES = "particles/presets.yml";

    private final Path dataFolder;
    private final ConfigService.ResourceLoader resources;
    private final ScenesLogger log;
    private final PresetLibrary sounds;
    private final PresetLibrary particles;

    public PresetFiles(Path dataFolder, ConfigService.ResourceLoader resources, ScenesLogger log,
                       PresetLibrary sounds, PresetLibrary particles) {
        this.dataFolder = dataFolder;
        this.resources = resources;
        this.log = log;
        this.sounds = sounds;
        this.particles = particles;
    }

    @Override
    public String name() {
        return "presets";
    }

    @Override
    public void start() throws Exception {
        copyDefault(SOUNDS);
        copyDefault(PARTICLES);
        List<String> errors = reload();
        if (errors.isEmpty()) {
            log.info("Loaded " + sounds.names().size() + " sound presets and " + particles.names().size()
                    + " particle presets.");
        }
    }

    @Override
    public void stop() {
        // Nothing to release.
    }

    /** Re-reads both files and returns the problems found. */
    public List<String> reload() {
        List<String> errors = new ArrayList<>();
        load(SOUNDS, sounds, errors);
        load(PARTICLES, particles, errors);
        errors.forEach(e -> log.warn("Preset file problem: " + e));
        return errors;
    }

    private void copyDefault(String name) throws IOException {
        Path target = dataFolder.resolve(name);
        if (Files.exists(target)) {
            return;
        }
        Files.createDirectories(target.getParent());
        try (InputStream in = resources.open(name)) {
            if (in == null) {
                throw new IOException("Missing bundled resource: " + name);
            }
            Files.copy(in, target);
        }
    }

    private void load(String name, PresetLibrary library, List<String> errors) {
        Path path = dataFolder.resolve(name);
        try {
            if (Files.notExists(path)) {
                copyDefault(name);
            }
            YamlConfiguration yaml = new YamlConfiguration();
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                yaml.load(reader);
            }
            ConfigurationSection section = yaml.getConfigurationSection("presets");
            Map<String, Map<String, Object>> presets = new LinkedHashMap<>();
            if (section != null) {
                for (String key : section.getKeys(false)) {
                    ConfigurationSection preset = section.getConfigurationSection(key);
                    if (preset == null) {
                        errors.add(name + ": preset '" + key + "' must be a section");
                    } else {
                        presets.put(key, toMap(preset));
                    }
                }
            }
            library.replace(presets);
        } catch (IOException | org.bukkit.configuration.InvalidConfigurationException e) {
            errors.add(name + ": " + e.getMessage());
        }
    }

    private static Map<String, Object> toMap(ConfigurationSection section) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (String key : section.getKeys(false)) {
            Object value = section.get(key);
            out.put(key, value instanceof ConfigurationSection nested ? toMap(nested) : value);
        }
        return out;
    }
}
