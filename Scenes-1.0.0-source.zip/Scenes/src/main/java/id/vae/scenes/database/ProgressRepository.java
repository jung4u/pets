package id.vae.scenes.database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Per-player scene progress (the "play once per UUID" bookkeeping). */
public final class ProgressRepository {

    public record ProgressEntry(String sceneId, int completedCount, long firstCompleted, long lastPlayed) {
    }

    private final DatabaseManager db;

    public ProgressRepository(DatabaseManager db) {
        this.db = db;
    }

    public boolean hasCompleted(UUID uuid, String sceneId) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT 1 FROM player_progress WHERE uuid = ? AND scene_id = ? AND completed_count > 0")) {
                ps.setString(1, uuid.toString());
                ps.setString(2, sceneId);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next();
                }
            }
        });
    }

    /** Records a completed run. Creates a placeholder player row if the player is unknown. */
    public void markCompleted(UUID uuid, String sceneId, long nowMillis) throws SQLException {
        db.transaction(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT OR IGNORE INTO players(uuid, name, first_seen, last_seen) VALUES(?, 'unknown', ?, ?)")) {
                ps.setString(1, uuid.toString());
                ps.setLong(2, nowMillis);
                ps.setLong(3, nowMillis);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO player_progress(uuid, scene_id, completed_count, first_completed, last_played) "
                            + "VALUES(?, ?, 1, ?, ?) "
                            + "ON CONFLICT(uuid, scene_id) DO UPDATE SET "
                            + "completed_count = completed_count + 1, last_played = excluded.last_played")) {
                ps.setString(1, uuid.toString());
                ps.setString(2, sceneId);
                ps.setLong(3, nowMillis);
                ps.setLong(4, nowMillis);
                ps.executeUpdate();
            }
            return null;
        });
    }

    public List<ProgressEntry> forPlayer(UUID uuid) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT scene_id, completed_count, first_completed, last_played "
                            + "FROM player_progress WHERE uuid = ? ORDER BY last_played DESC")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    List<ProgressEntry> out = new ArrayList<>();
                    while (rs.next()) {
                        out.add(new ProgressEntry(rs.getString(1), rs.getInt(2), rs.getLong(3), rs.getLong(4)));
                    }
                    return out;
                }
            }
        });
    }

    public int totalCompleted(UUID uuid) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT COALESCE(SUM(completed_count), 0) FROM player_progress WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? rs.getInt(1) : 0;
                }
            }
        });
    }

    public Optional<String> lastScene(UUID uuid) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT scene_id FROM player_progress WHERE uuid = ? ORDER BY last_played DESC LIMIT 1")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? Optional.of(rs.getString(1)) : Optional.<String>empty();
                }
            }
        });
    }

    public int resetScene(UUID uuid, String sceneId) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "DELETE FROM player_progress WHERE uuid = ? AND scene_id = ?")) {
                ps.setString(1, uuid.toString());
                ps.setString(2, sceneId);
                return ps.executeUpdate();
            }
        });
    }

    public int resetPlayer(UUID uuid) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM player_progress WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                return ps.executeUpdate();
            }
        });
    }

    public int resetSceneForAll(String sceneId) throws SQLException {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM player_progress WHERE scene_id = ?")) {
                ps.setString(1, sceneId);
                return ps.executeUpdate();
            }
        });
    }

    public int resetAll() throws SQLException {
        return db.query(c -> {
            try (Statement st = c.createStatement()) {
                return st.executeUpdate("DELETE FROM player_progress");
            }
        });
    }
}
