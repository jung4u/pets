package id.vae.scenes.scene;

import id.vae.scenes.util.ScenesLogger;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * One running scene for one player. Actions start at their delay offset from the start of the
 * scene; waits push later actions back. A failing action is logged and the scene continues.
 */
final class SceneRun {

    interface FinishListener {
        void finished(SceneRun run, boolean completed, String reason);
    }

    private final SceneDefinition scene;
    private final UUID player;
    private final ActionContext context;
    private final ActionRegistry registry;
    private final SceneScheduler scheduler;
    private final ScenesLogger log;
    private final FinishListener listener;
    private final List<ActionDefinition> timeline;

    private int index;
    private long startTime;
    private long shift;
    private long endAt;
    private boolean finished;
    private SceneScheduler.Task pending;
    private ActionResult waiting;
    private long waitStart;

    SceneRun(SceneDefinition scene, UUID player, ActionContext context, ActionRegistry registry,
             SceneScheduler scheduler, ScenesLogger log, FinishListener listener) {
        this.scene = scene;
        this.player = player;
        this.context = context;
        this.registry = registry;
        this.scheduler = scheduler;
        this.log = log;
        this.listener = listener;
        this.timeline = scene.actions().stream()
                .filter(ActionDefinition::enabled)
                .sorted(Comparator.comparingLong(ActionDefinition::delayMillis)
                        .thenComparingInt(ActionDefinition::order))
                .toList();
    }

    SceneDefinition scene() {
        return scene;
    }

    UUID player() {
        return player;
    }

    synchronized boolean isFinished() {
        return finished;
    }

    synchronized void start() {
        startTime = scheduler.nowMillis();
        endAt = startTime;
        advance();
    }

    synchronized void cancel(String reason) {
        if (!finished) {
            finish(false, reason);
        }
    }

    private void advance() {
        while (!finished) {
            if (index >= timeline.size()) {
                scheduleFinish();
                return;
            }
            ActionDefinition next = timeline.get(index);
            long wait = startTime + shift + next.delayMillis() - scheduler.nowMillis();
            if (wait > 0) {
                pending = scheduler.runLater(wait, this::onTimer);
                return;
            }
            if (!execute(next)) {
                return;
            }
        }
    }

    private synchronized void onTimer() {
        pending = null;
        advance();
    }

    /** Runs one action; returns true when the timeline may continue immediately. */
    private boolean execute(ActionDefinition action) {
        long now = scheduler.nowMillis();
        index++;
        if (context.isSkipped(action.id())
                || !context.conditions().allMatch(action.conditions(), player, context.variables())) {
            return true;
        }
        endAt = Math.max(endAt, now + action.durationMillis());

        ActionHandler handler = registry.get(action.type()).orElse(null);
        if (handler == null) {
            log.sceneError(scene.id(), action.id(), "unknown action type " + action.type(), null);
            return true;
        }

        ActionResult result;
        try {
            result = handler.execute(context, action);
        } catch (Exception e) {
            log.sceneError(scene.id(), action.id(), String.valueOf(e.getMessage()), e);
            return true;
        }
        if (result == null) {
            return true;
        }
        switch (result.kind()) {
            case END_SCENE -> {
                finish(true, "ended by action " + action.id());
                return false;
            }
            case WAIT -> {
                waiting = result;
                waitStart = now;
                poll();
                return false;
            }
            default -> {
                return true;
            }
        }
    }

    private synchronized void poll() {
        pending = null;
        if (finished || waiting == null) {
            return;
        }
        long now = scheduler.nowMillis();
        long waited = now - waitStart;
        boolean ready;
        try {
            ready = waiting.ready().getAsBoolean();
        } catch (RuntimeException e) {
            log.sceneError(scene.id(), "wait", String.valueOf(e.getMessage()), e);
            ready = true;
        }
        if (ready) {
            shift += waited;
            waiting = null;
            advance();
            return;
        }
        if (waited >= waiting.timeoutMillis()) {
            boolean abort = waiting.abortOnTimeout();
            shift += waited;
            waiting = null;
            if (abort) {
                finish(false, "wait timed out");
            } else {
                advance();
            }
            return;
        }
        long next = Math.max(1, Math.min(waiting.pollMillis(), waiting.timeoutMillis() - waited));
        pending = scheduler.runLater(next, this::poll);
    }

    private void scheduleFinish() {
        // endAt already holds the real end of every action that ran; only the scene's minimum length shifts.
        long finishAt = Math.max(endAt, startTime + shift + scene.durationMillis());
        long wait = finishAt - scheduler.nowMillis();
        if (wait <= 0) {
            finish(true, "completed");
        } else {
            pending = scheduler.runLater(wait, () -> {
                synchronized (SceneRun.this) {
                    pending = null;
                    if (!finished) {
                        finish(true, "completed");
                    }
                }
            });
        }
    }

    private void finish(boolean completed, String reason) {
        finished = true;
        waiting = null;
        if (pending != null) {
            pending.cancel();
            pending = null;
        }
        context.runCleanups();
        listener.finished(this, completed, reason);
    }
}
