package id.vae.scenes.bukkit;

import id.vae.scenes.scene.DatabaseProgressTracker;
import id.vae.scenes.scene.SceneEngine;
import id.vae.scenes.scene.TriggerType;
import id.vae.scenes.trigger.TriggerEvent;
import id.vae.scenes.trigger.TriggerManager;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.Plugin;

/**
 * Translates Bukkit events into trigger events. Login and first-join triggers arrive with the
 * AuthMe-aware hooks in a later phase.
 */
public final class BukkitTriggerListener implements Listener {

    private final Plugin plugin;
    private final TriggerManager triggers;
    private final SceneEngine engine;
    private final DatabaseProgressTracker progress;

    public BukkitTriggerListener(Plugin plugin, TriggerManager triggers, SceneEngine engine,
                                 DatabaseProgressTracker progress) {
        this.plugin = plugin;
        this.triggers = triggers;
        this.engine = engine;
        this.progress = progress;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        progress.preload(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        engine.onPlayerQuit(event.getPlayer().getUniqueId());
        progress.invalidate(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        World world = player.getWorld();
        triggers.fire(TriggerEvent.of(TriggerType.WORLD_CHANGE, player.getUniqueId(), world.getName()));
        if (world.getEnvironment() == World.Environment.NETHER) {
            triggers.fire(TriggerEvent.of(TriggerType.NETHER_ENTER, player.getUniqueId(), world.getName()));
        } else if (world.getEnvironment() == World.Environment.THE_END) {
            triggers.fire(TriggerEvent.of(TriggerType.END_ENTER, player.getUniqueId(), world.getName()));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        // A scene never carries on over a death: restore everything first.
        engine.stop(player.getUniqueId(), "player died");
        triggers.fire(TriggerEvent.of(TriggerType.PLAYER_DEATH, player.getUniqueId(), player.getWorld().getName()));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        // One tick later the player is fully respawned at the final location, and other plugins have finished.
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline() && !player.isDead()) {
                triggers.fire(TriggerEvent.of(TriggerType.PLAYER_RESPAWN, player.getUniqueId(),
                        player.getWorld().getName()));
            }
        });
    }
}
