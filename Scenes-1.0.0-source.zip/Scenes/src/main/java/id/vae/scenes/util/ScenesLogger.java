package id.vae.scenes.util;

import java.util.logging.Level;
import java.util.logging.Logger;

/** Thin logging wrapper with a runtime-switchable debug mode. */
public final class ScenesLogger {

    private final Logger logger;
    private volatile boolean debug;

    public ScenesLogger(Logger logger, boolean debug) {
        this.logger = logger;
        this.debug = debug;
    }

    public void setDebug(boolean debug) {
        this.debug = debug;
    }

    public boolean isDebug() {
        return debug;
    }

    public void info(String message) {
        logger.info(message);
    }

    public void warn(String message) {
        logger.warning(message);
    }

    public void error(String message, Throwable cause) {
        if (cause == null) {
            logger.severe(message);
        } else {
            logger.log(Level.SEVERE, message, cause);
        }
    }

    public void debug(String message) {
        if (debug) {
            logger.info("[DEBUG] " + message);
        }
    }

    /** Error that always names the scene, the action and the cause. */
    public void sceneError(String scene, String action, String cause, Throwable throwable) {
        error("Scene '" + scene + "' action '" + action + "' failed: " + cause, throwable);
    }
}
