# Scenes by Vae

A cinematic scene engine for Paper 1.21.11. Scenes are timelines of actions: camera moves, screen effects,
subtitles, sounds and particles, played to a player when something happens (first join, entering the Nether
or The End, a random teleport, dying and coming back) or when you start one by command.

- Plugin: Scenes 1.0.0, author Vae
- Package `id.vae.scenes`, main class `id.vae.scenes.ScenesPlugin`
- Paper 1.21.11, Java 21, built with Apache Maven 3.9.x, storage in SQLite
- No resource pack needed

## What it does

- **Cinematic camera.** A hidden camera entity shows the world from somewhere else while the player stays where they are,
  with their game mode, inventory and health untouched. Static, dolly, pan, orbit, follow and multi-waypoint paths, easing,
  look-at targets, shake. Uses ProtocolLib when installed, otherwise a temporary spectator camera that is always undone.
- **Screen effects.** Fade, black screen, eyes opening and closing, blinks, flash, blur and vignette (simulations, not shaders),
  darkness.
- **Subtitles** with MiniMessage, gradients, styles, three positions, queues, priority and placeholders.
- **Sounds and particles** with preset libraries.
- **Five built-in scenes:** first join, Nether, The End, random teleport, death and resurrection.
- **Hooks** for AuthMe (wait for login), any RTP plugin (by command), PlaceholderAPI, ProtocolLib and Geyser/Floodgate, all optional.
- **Safe by design.** A failing action never stops a scene; every scene restores what it changed when it ends, is stopped,
  or the player leaves; if the server crashes in the middle of a spectator camera the player is restored when they join again.
  Nothing runs per tick unless a camera or effect is active, scenes and cameras and particles are limited, and player
  progress is cached so a running scene does not wait on the database.

## Quick start

    mvn clean test
    mvn clean package          # target/Scenes-1.0.0.jar

Copy the jar to `plugins/`, start the server, then `/scene start <you> first_join`.

| Read | For |
| --- | --- |
| INSTALLATION.md | building on Termux, installing, troubleshooting |
| COMMANDS.md | every command and permission |
| CONFIGURATION.md | config files, the scene format, every action and setting, the built-in scenes |

## How it was checked

- 169 automated tests of the scene logic, camera maths, effects, subtitles, sounds, particles, triggers, RTP flow,
  the SQLite layer (migrations, repositories, backups, scene storage) and crash-recovery files ran and passed.
- The five built-in scenes were parsed from their YAML, validated against every action, and played through to the end with cleanup.
- The code that talks to Paper (commands, listeners, the camera, screen and sound output, the AuthMe and RTP hooks) compiles
  against hand-written stand-ins for the Paper API, which only checks that the code is consistent with itself.
  **It has not been run on a real server.** `mvn clean test` and `mvn clean package` also have not been run here
  (the build tools cannot download Paper's API in the environment this was written in). Please run them and try the scenes
  on your server; see INSTALLATION.md.

## Known limits

- With ProtocolLib the camera can only show places within `camera.max-distance` of the player (the client has no other chunks).
- Blur and vignette are simulations (a light nausea wobble, and a red screen-edge tint). Screen colour other than the flash colour needs a resource pack.
- No dragon entity is spawned in The End scene, so the boss fight is never disturbed.
- The death screen cannot be changed; the death scene starts after respawn.
- The RTP hook works by command and has not been tried with a specific RTP plugin.
