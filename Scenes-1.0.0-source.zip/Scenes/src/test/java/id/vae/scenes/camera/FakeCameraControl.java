package id.vae.scenes.camera;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/** A camera control that records calls and lets tests move the player's eyes. */
public final class FakeCameraControl implements CameraControl {

    public final Set<UUID> active = new HashSet<>();
    public final Map<UUID, CameraPose> pose = new HashMap<>();
    public final List<String> calls = new ArrayList<>();
    public CameraPose eye = new CameraPose(0, 65.62, 0, 0, 0);
    public PoseSource lastSource;

    @Override
    public boolean begin(UUID player, CameraPose start) {
        calls.add("begin");
        active.add(player);
        pose.put(player, start);
        return true;
    }

    @Override
    public boolean isActive(UUID player) {
        return active.contains(player);
    }

    @Override
    public Optional<CameraPose> currentPose(UUID player) {
        return Optional.ofNullable(pose.get(player));
    }

    @Override
    public void play(UUID player, PoseSource source) {
        calls.add("play");
        lastSource = source;
    }

    @Override
    public void shake(UUID player, CameraShake shake) {
        calls.add("shake");
    }

    @Override
    public void end(UUID player) {
        if (active.remove(player)) {
            calls.add("end");
        }
    }

    @Override
    public Optional<CameraPose> playerEyePose(UUID player) {
        return Optional.of(eye);
    }

    @Override
    public Optional<String> playerWorld(UUID player) {
        return Optional.of("world");
    }

    @Override
    public double maxDistance() {
        return 96;
    }
}
