package id.vae.scenes.scene;

import java.util.List;

/** Helpers for building action handlers. */
public final class ActionHandlers {

    private ActionHandlers() {
    }

    /** Exposes an existing handler under another action type. */
    public static ActionHandler alias(String type, ActionHandler delegate) {
        return new ActionHandler() {
            @Override
            public String type() {
                return type;
            }

            @Override
            public List<String> validate(ActionDefinition action) {
                return delegate.validate(action);
            }

            @Override
            public ActionResult execute(ActionContext context, ActionDefinition action) throws Exception {
                return delegate.execute(context, action);
            }
        };
    }

    /** Registers the cleanup only the first time a scene run uses a module. */
    public static void cleanupOnce(ActionContext ctx, String key, Runnable cleanup) {
        if (ctx.variables().putIfAbsent(key, Boolean.TRUE) == null) {
            ctx.addCleanup(cleanup);
        }
    }

    public static boolean validHex(String value) {
        return value != null && value.matches("#?[0-9a-fA-F]{6}");
    }

    public static String normalizeHex(String value) {
        String v = value.trim();
        return v.startsWith("#") ? v.toLowerCase() : "#" + v.toLowerCase();
    }
}
