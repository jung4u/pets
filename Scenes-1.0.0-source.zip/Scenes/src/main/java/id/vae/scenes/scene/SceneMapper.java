package id.vae.scenes.scene;

import id.vae.scenes.util.Easing;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Converts scenes to and from plain maps (the shape of the scenes/*.yml files). Reading never throws:
 * problems come back as a list so one bad file cannot stop the plugin.
 *
 * <pre>
 * id, name, description, enabled, priority, cooldown-ms, duration-ms
 * trigger: {type, once-per-player, permission, world, argument}
 * conditions: [{type, ...}]
 * actions: [{id, type, delay-ms, duration-ms, easing, enabled, conditions, config: {...}}]
 * </pre>
 */
public final class SceneMapper {

    public record Parsed(SceneDefinition scene, List<String> errors) {
        public boolean ok() {
            return errors.isEmpty() && scene != null;
        }
    }

    private SceneMapper() {
    }

    public static Parsed fromMap(Map<String, Object> m) {
        List<String> errors = new ArrayList<>();

        Map<String, Object> triggerMap = ConfigValues.map(m, "trigger");
        String triggerName = ConfigValues.string(triggerMap, "type", "MANUAL").trim().toUpperCase(Locale.ROOT);
        TriggerType triggerType = TriggerType.MANUAL;
        try {
            triggerType = TriggerType.valueOf(triggerName);
        } catch (IllegalArgumentException e) {
            errors.add("unknown trigger type '" + triggerName + "'");
        }
        TriggerSpec trigger = new TriggerSpec(triggerType, ConfigValues.bool(triggerMap, "once-per-player", false),
                ConfigValues.string(triggerMap, "permission", ""), ConfigValues.string(triggerMap, "world", ""),
                ConfigValues.string(triggerMap, "argument", ""));

        List<ActionDefinition> actions = new ArrayList<>();
        Object rawActions = m.get("actions");
        if (rawActions instanceof List<?> list) {
            int index = 0;
            for (Object entry : list) {
                if (!(entry instanceof Map<?, ?>)) {
                    errors.add("action " + (index + 1) + " must be a section");
                    index++;
                    continue;
                }
                Map<String, Object> a = ConfigValues.mapList(Map.of("l", List.of(entry)), "l").get(0);
                String easingName = ConfigValues.string(a, "easing", "LINEAR");
                Easing easing = Easing.parse(easingName, null);
                if (easing == null) {
                    errors.add("action '" + ConfigValues.string(a, "id", "#" + (index + 1))
                            + "': unknown easing '" + easingName + "'");
                    easing = Easing.LINEAR;
                }
                actions.add(new ActionDefinition(ConfigValues.string(a, "id", ""), ConfigValues.string(a, "type", ""),
                        index, ConfigValues.longValue(a, "delay-ms", 0), ConfigValues.longValue(a, "duration-ms", 0),
                        easing, ConfigValues.bool(a, "enabled", true), conditions(a.get("conditions")),
                        ConfigValues.map(a, "config")));
                index++;
            }
        } else if (rawActions != null) {
            errors.add("'actions' must be a list");
        }

        SceneDefinition scene = new SceneDefinition(ConfigValues.string(m, "id", ""),
                ConfigValues.string(m, "name", ""), ConfigValues.string(m, "description", ""),
                ConfigValues.bool(m, "enabled", true), trigger, (int) ConfigValues.longValue(m, "priority", 0),
                ConfigValues.longValue(m, "cooldown-ms", 0), ConfigValues.longValue(m, "duration-ms", 0),
                conditions(m.get("conditions")), actions);
        return new Parsed(scene, errors);
    }

    public static Map<String, Object> toMap(SceneDefinition scene) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("id", scene.id());
        out.put("name", scene.name());
        out.put("description", scene.description());
        out.put("enabled", scene.enabled());
        out.put("priority", scene.priority());
        out.put("cooldown-ms", scene.cooldownMillis());
        out.put("duration-ms", scene.durationMillis());
        Map<String, Object> trigger = new LinkedHashMap<>();
        trigger.put("type", scene.trigger().type().name());
        trigger.put("once-per-player", scene.trigger().oncePerPlayer());
        trigger.put("permission", scene.trigger().permission());
        trigger.put("world", scene.trigger().world());
        trigger.put("argument", scene.trigger().argument());
        out.put("trigger", trigger);
        out.put("conditions", scene.conditions().stream().map(ConditionSpec::toMap).toList());
        List<Map<String, Object>> actions = new ArrayList<>();
        for (ActionDefinition a : scene.actions()) {
            Map<String, Object> am = new LinkedHashMap<>();
            am.put("id", a.id());
            am.put("type", a.type());
            am.put("delay-ms", a.delayMillis());
            am.put("duration-ms", a.durationMillis());
            am.put("easing", a.easing().name());
            am.put("enabled", a.enabled());
            am.put("conditions", a.conditions().stream().map(ConditionSpec::toMap).toList());
            am.put("config", a.config());
            actions.add(am);
        }
        out.put("actions", actions);
        return out;
    }

    private static List<ConditionSpec> conditions(Object raw) {
        List<ConditionSpec> out = new ArrayList<>();
        if (raw instanceof List<?> list) {
            for (Object entry : list) {
                if (entry instanceof Map<?, ?>) {
                    out.add(ConditionSpec.fromMap(ConfigValues.mapList(Map.of("l", List.of(entry)), "l").get(0)));
                }
            }
        }
        return out;
    }
}
