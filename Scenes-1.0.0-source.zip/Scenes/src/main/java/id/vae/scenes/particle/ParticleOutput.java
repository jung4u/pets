package id.vae.scenes.particle;

import java.util.UUID;

/** Spawns particles in the world of a real player. */
public interface ParticleOutput {

    void spawn(UUID player, ParticleCall call, boolean nearby);
}
