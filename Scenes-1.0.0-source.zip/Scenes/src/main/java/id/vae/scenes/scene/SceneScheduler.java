package id.vae.scenes.scene;

/** Schedules work on the server main thread. */
public interface SceneScheduler {

    interface Task {
        void cancel();
    }

    long nowMillis();

    Task runLater(long delayMillis, Runnable runnable);
}
