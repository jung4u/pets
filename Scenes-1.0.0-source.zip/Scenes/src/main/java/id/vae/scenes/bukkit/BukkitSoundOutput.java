package id.vae.scenes.bukkit;

import id.vae.scenes.camera.Vec3;
import id.vae.scenes.sound.SoundOutput;
import id.vae.scenes.sound.SoundSpec;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;

import java.util.UUID;

/** Plays sounds by key, so vanilla and resource pack sounds both work. */
public final class BukkitSoundOutput implements SoundOutput {

    @Override
    public void play(UUID id, SoundSpec spec, Vec3 position) {
        Player player = Bukkit.getPlayer(id);
        if (player == null) {
            return;
        }
        Location at = position == null ? player.getLocation()
                : new Location(player.getWorld(), position.x(), position.y(), position.z());
        SoundCategory category = category(spec.category());
        if (spec.nearby()) {
            player.getWorld().playSound(at, spec.key(), category, spec.volume(), spec.pitch());
        } else {
            player.playSound(at, spec.key(), category, spec.volume(), spec.pitch());
        }
    }

    @Override
    public void stop(UUID id, String key, String category) {
        Player player = Bukkit.getPlayer(id);
        if (player != null) {
            player.stopSound(key, category(category));
        }
    }

    private static SoundCategory category(String name) {
        try {
            return SoundCategory.valueOf(name);
        } catch (IllegalArgumentException e) {
            return SoundCategory.MASTER;
        }
    }
}
