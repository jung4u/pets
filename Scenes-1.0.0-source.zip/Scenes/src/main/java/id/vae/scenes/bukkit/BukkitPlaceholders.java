package id.vae.scenes.bukkit;

import id.vae.scenes.subtitle.PlaceholderResolver;
import id.vae.scenes.subtitle.SubtitleFormatter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Resolves %player_name% and %player_world% itself (escaped, so a value can never inject MiniMessage tags)
 * and hands the rest to PlaceholderAPI when it is installed. PlaceholderAPI is reached by reflection.
 */
public final class BukkitPlaceholders implements PlaceholderResolver {

    private final Plugin plugin;
    private Method setPlaceholders;
    private boolean lookedUp;

    public BukkitPlaceholders(Plugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String apply(UUID id, String text) {
        Player player = Bukkit.getPlayer(id);
        if (player == null) {
            return text;
        }
        String result = text
                .replace("%player_name%", SubtitleFormatter.escape(player.getName()))
                .replace("%player_world%", SubtitleFormatter.escape(player.getWorld().getName()));
        if (result.indexOf('%') >= 0) {
            result = papi(player, result);
        }
        return result;
    }

    private String papi(Player player, String text) {
        if (!lookedUp) {
            lookedUp = true;
            if (plugin.getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
                try {
                    setPlaceholders = Class.forName("me.clip.placeholderapi.PlaceholderAPI")
                            .getMethod("setPlaceholders", Class.forName("org.bukkit.OfflinePlayer"), String.class);
                } catch (ReflectiveOperationException e) {
                    setPlaceholders = null;
                }
            }
        }
        if (setPlaceholders == null) {
            return text;
        }
        try {
            return (String) setPlaceholders.invoke(null, player, text);
        } catch (ReflectiveOperationException | RuntimeException e) {
            return text;
        }
    }
}
