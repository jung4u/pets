package id.vae.scenes.scene;

import java.util.UUID;

/** Freezes and releases a player's movement. Calls are counted, so nested locks are safe. */
public interface PlayerLocks {

    void lock(UUID player);

    void unlock(UUID player);
}
