package id.vae.scenes.scene;

import id.vae.scenes.database.DatabaseManager;
import id.vae.scenes.database.SceneRepository;
import id.vae.scenes.scene.TestSupport.FakePlayers;
import id.vae.scenes.scene.TestSupport.ManualScheduler;
import id.vae.scenes.scene.TestSupport.Marker;
import id.vae.scenes.util.ScenesLogger;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static id.vae.scenes.scene.TestSupport.action;
import static id.vae.scenes.scene.TestSupport.mark;
import static id.vae.scenes.scene.TestSupport.scene;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SceneManagerTest {

    private final ScenesLogger log = new ScenesLogger(Logger.getLogger("test"), false);
    private DatabaseManager db;
    private SceneManager manager;

    @BeforeEach
    void setUp() throws Exception {
        db = DatabaseManager.inMemory(log);
        db.start();
        ActionRegistry registry = new ActionRegistry();
        ControlActions.registerAll(registry);
        registry.register(new Marker(new ArrayList<>(), new ManualScheduler()));
        SceneValidator validator = new SceneValidator(registry, new ConditionEvaluator(new FakePlayers()));
        manager = new SceneManager(new SceneRepository(db), validator, log);
        manager.start();
    }

    @AfterEach
    void tearDown() {
        db.stop();
    }

    @Test
    void createdScenesSurviveAReload() throws Exception {
        SceneDefinition original = new SceneDefinition("nether", "Nether Intro", "desc", true,
                new TriggerSpec(TriggerType.NETHER_ENTER, true, "perm.x", "world_nether", ""), 7, 1500, 4000,
                List.of(new ConditionSpec("WORLD", Map.of("world", "world_nether"))),
                List.of(mark("a", 0), action("b", "MARK", 500, 250, Map.of("fail", false, "n", 3))));

        assertTrue(manager.create(original).ok());
        assertEquals(List.of(), manager.reload());

        SceneDefinition loaded = manager.find("nether").orElseThrow();
        assertEquals("Nether Intro", loaded.name());
        assertEquals(TriggerType.NETHER_ENTER, loaded.trigger().type());
        assertTrue(loaded.trigger().oncePerPlayer());
        assertEquals("world_nether", loaded.trigger().world());
        assertEquals(7, loaded.priority());
        assertEquals(1500, loaded.cooldownMillis());
        assertEquals(4000, loaded.durationMillis());
        assertEquals(1, loaded.conditions().size());
        assertEquals(2, loaded.actions().size());
        assertEquals(500, loaded.actions().get(1).delayMillis());
        assertEquals(250, loaded.actions().get(1).durationMillis());
    }

    @Test
    void invalidScenesAreRejectedAndNothingIsStored() throws Exception {
        SceneResult result = manager.create(scene("Bad Id", 0, mark("a", 0)));

        assertFalse(result.ok());
        assertTrue(manager.all().isEmpty());
        assertEquals(0, new SceneRepository(db).loadAll().scenes().size());
    }

    @Test
    void duplicateIdsAreRejected() {
        assertTrue(manager.create(scene("intro", 0, mark("a", 0))).ok());
        assertFalse(manager.create(scene("intro", 0, mark("a", 0))).ok());
    }

    @Test
    void editsApplyImmediatelyAndPersist() throws Exception {
        manager.create(scene("intro", 0, mark("a", 0)));

        assertTrue(manager.rename("intro", "New Name").ok());
        assertTrue(manager.setEnabled("intro", false).ok());
        assertTrue(manager.setPriority("intro", 4).ok());
        assertTrue(manager.setCooldown("intro", 900).ok());
        assertTrue(manager.setTrigger("intro", TriggerSpec.of(TriggerType.END_ENTER, true)).ok());
        manager.reload();

        SceneDefinition scene = manager.find("intro").orElseThrow();
        assertEquals("New Name", scene.name());
        assertFalse(scene.enabled());
        assertEquals(4, scene.priority());
        assertEquals(900, scene.cooldownMillis());
        assertEquals(TriggerType.END_ENTER, scene.trigger().type());
    }

    @Test
    void duplicateCopiesActionsUnderANewId() throws Exception {
        manager.create(scene("intro", 0, mark("a", 0), mark("b", 100)));

        assertTrue(manager.duplicate("intro", "intro_copy").ok());
        manager.reload();

        assertEquals(2, manager.find("intro_copy").orElseThrow().actions().size());
        assertEquals(2, manager.find("intro").orElseThrow().actions().size());
        assertFalse(manager.duplicate("intro", "intro_copy").ok());
    }

    @Test
    void reorderRequiresEveryActionExactlyOnce() throws Exception {
        manager.create(scene("intro", 0, mark("a", 0), mark("b", 100), mark("c", 200)));

        assertFalse(manager.reorderActions("intro", List.of("a", "b")).ok());
        assertTrue(manager.reorderActions("intro", List.of("c", "a", "b")).ok());
        manager.reload();

        List<String> ids = manager.find("intro").orElseThrow().actions().stream().map(ActionDefinition::id).toList();
        assertEquals(List.of("c", "a", "b"), ids);
    }

    @Test
    void deleteRemovesTheSceneAndItsActions() throws Exception {
        manager.create(scene("intro", 0, mark("a", 0)));

        assertTrue(manager.delete("intro").ok());
        manager.reload();

        assertTrue(manager.find("intro").isEmpty());
        assertFalse(manager.delete("intro").ok());
    }

    @Test
    void sameActionIdsInDifferentScenesDoNotCollide() throws Exception {
        assertTrue(manager.create(scene("one", 0, mark("lock", 0))).ok());
        assertTrue(manager.create(scene("two", 0, mark("lock", 0))).ok());
        manager.reload();

        assertEquals(2, manager.all().size());
    }
}
