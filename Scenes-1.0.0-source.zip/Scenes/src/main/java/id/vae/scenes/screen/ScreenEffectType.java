package id.vae.scenes.screen;

public enum ScreenEffectType {
    FADE_IN,
    FADE_OUT,
    BLACK_SCREEN,
    EYE_CLOSE,
    EYE_OPEN,
    BLINK,
    DOUBLE_BLINK,
    TRIPLE_BLINK,
    FLASH,
    BLUR,
    VIGNETTE,
    DARKNESS
}
