package id.vae.scenes.camera;

import id.vae.scenes.camera.CameraActions.Relative;
import id.vae.scenes.scene.EngineHarness;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static id.vae.scenes.scene.TestSupport.action;
import static id.vae.scenes.scene.TestSupport.scene;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CameraRelativeTest {

    private static final CameraPose EYE_NORTH = new CameraPose(100, 65, 200, 0, 0);

    private static void assertVec(double x, double y, double z, Vec3 actual) {
        assertEquals(x, actual.x(), 1e-6);
        assertEquals(y, actual.y(), 1e-6);
        assertEquals(z, actual.z(), 1e-6);
    }

    @Test
    void facingOffsetsFollowTheDirectionThePlayerLooks() {
        // yaw 0 looks along +Z, with the player's right hand towards -X.
        assertVec(100, 65, 205, CameraActions.toWorld(new Vec3(0, 0, 5), EYE_NORTH, Relative.FACING));
        assertVec(99, 65, 200, CameraActions.toWorld(new Vec3(1, 0, 0), EYE_NORTH, Relative.FACING));
        assertVec(100, 70, 200, CameraActions.toWorld(new Vec3(0, 5, 0), EYE_NORTH, Relative.FACING));

        // yaw -90 looks along +X, with the right hand towards +Z.
        CameraPose east = new CameraPose(100, 65, 200, -90, 0);
        assertVec(105, 65, 200, CameraActions.toWorld(new Vec3(0, 0, 5), east, Relative.FACING));
        assertVec(100, 65, 201, CameraActions.toWorld(new Vec3(1, 0, 0), east, Relative.FACING));

        // yaw 90 looks along -X.
        CameraPose west = new CameraPose(100, 65, 200, 90, 0);
        assertVec(95, 65, 200, CameraActions.toWorld(new Vec3(0, 0, 5), west, Relative.FACING));
    }

    @Test
    void worldOffsetsIgnoreWhereThePlayerLooksAndNoneIsUntouched() {
        CameraPose east = new CameraPose(100, 65, 200, -90, 0);

        assertVec(103, 67, 195, CameraActions.toWorld(new Vec3(3, 2, -5), east, Relative.WORLD));
        assertVec(3, 2, -5, CameraActions.toWorld(new Vec3(3, 2, -5), east, Relative.NONE));
    }

    private EngineHarness h;
    private FakeCameraControl camera;

    @BeforeEach
    void setUp() {
        h = new EngineHarness();
        camera = new FakeCameraControl();
        camera.eye = new CameraPose(10, 65.62, 10, 90, 0);
        CameraActions.registerAll(h.registry, camera);
    }

    @Test
    void relativeWaypointsBecomeWorldPositionsAndTurnWithThePlayer() {
        h.run(scene("intro", 0, action("move", "CAMERA_MOVE", 0, 1000, Map.of("relative", "FACING", "waypoints",
                List.of(Map.of("x", 0, "y", 8, "z", -5, "yaw", 0, "pitch", 10, "duration-ms", 1000))))));

        CameraPose end = camera.lastSource.poseAt(1000);

        // Looking towards -X (yaw 90): five blocks behind the player is +X.
        assertEquals(15.0, end.x(), 1e-6);
        assertEquals(73.62, end.y(), 1e-6);
        assertEquals(10.0, end.z(), 1e-6);
        assertEquals(90.0, end.yaw(), 1e-4);
        assertEquals(10.0, end.pitch(), 1e-4);
    }

    @Test
    void aRelativeSpawnLooksBackAtThePlayer() {
        h.run(scene("intro", 0, action("spawn", "CAMERA_SPAWN", 0, 0, Map.of("relative", "FACING",
                "position", Map.of("x", 0, "y", 2, "z", 3), "look-at", Map.of("x", 0, "y", -1, "z", 0)))));

        CameraPose start = camera.pose.get(h.alice);
        Vec3 target = new Vec3(10, 64.62, 10);
        CameraPose expected = CameraPose.lookAt(start.position(), target);

        assertEquals(7.0, start.x(), 1e-6);
        assertEquals(67.62, start.y(), 1e-6);
        assertEquals(expected.yaw(), start.yaw(), 1e-4);
        assertEquals(expected.pitch(), start.pitch(), 1e-4);
        assertTrue(start.pitch() > 0);
    }

    @Test
    void relativeOrbitCentersAndFocusTargetsFollowThePlayer() {
        h.run(scene("intro", 0,
                action("orbit", "CAMERA_MOVE", 0, 2000, Map.of("mode", "ORBIT", "relative", "WORLD",
                        "center", Map.of("x", 0, "y", -1, "z", 0), "radius", 4)),
                action("focus", "CAMERA_FOCUS", 100, 500, Map.of("relative", "WORLD",
                        "look-at", Map.of("x", 0, "y", -1, "z", 5)))));

        h.clock.advance(100);
        assertEquals(List.of("begin", "play", "play"), camera.calls);
        CameraPose focused = camera.lastSource.poseAt(500);
        CameraPose expected = CameraPose.lookAt(focused.position(), new Vec3(10, 64.62, 15));
        assertEquals(expected.yaw(), focused.yaw(), 1e-3);
    }

    @Test
    void anInvalidRelativeValueIsRejected() {
        assertTrue(h.errors(action("a", "CAMERA_MOVE", 0, 1000, Map.of("relative", "sideways", "waypoints",
                List.of(Map.of("x", 1, "y", 2, "z", 3, "duration-ms", 1000))))).contains("relative"));
        assertTrue(h.errors(action("a", "CAMERA_FOCUS", 0, 500, Map.of("relative", "x",
                "look-at", Map.of("x", 1, "y", 2, "z", 3)))).contains("relative"));
        assertEquals("", h.errors(action("a", "CAMERA_MOVE", 0, 1000, Map.of("relative", "FACING", "waypoints",
                List.of(Map.of("x", 1, "y", 2, "z", 3, "duration-ms", 1000))))));
        assertEquals("", h.errors(action("a", "CAMERA_MOVE", 0, 1000, Map.of("relative", true, "waypoints",
                List.of(Map.of("x", 1, "y", 2, "z", 3, "duration-ms", 1000))))));
    }
}
