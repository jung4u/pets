package id.vae.scenes.screen;

import java.util.function.LongFunction;

/** A timed screen effect. After it ends the screen either keeps its last look (hold) or clears. */
public final class ScreenPlan {

    private final ScreenChannel channel;
    private final long duration;
    private final boolean hold;
    private final ScreenFrame finalFrame;
    private final String flashColor;
    private final LongFunction<ScreenFrame> frames;

    public ScreenPlan(ScreenChannel channel, long duration, boolean hold, ScreenFrame finalFrame, String flashColor,
                      LongFunction<ScreenFrame> frames) {
        this.channel = channel;
        this.duration = Math.max(0, duration);
        this.hold = hold;
        this.finalFrame = finalFrame;
        this.flashColor = flashColor == null ? "" : flashColor;
        this.frames = frames;
    }

    public ScreenChannel channel() {
        return channel;
    }

    public long durationMillis() {
        return duration;
    }

    /** True when the last frame stays on screen until it is replaced or cleared. */
    public boolean holdsFinalFrame() {
        return hold;
    }

    public ScreenFrame finalFrame() {
        return hold ? finalFrame : ScreenFrame.ZERO;
    }

    /** Hex colour of the flash, empty for white. */
    public String flashColor() {
        return flashColor;
    }

    public ScreenFrame frameAt(long elapsedMillis) {
        if (elapsedMillis >= duration) {
            return finalFrame();
        }
        return frames.apply(Math.max(0, elapsedMillis));
    }

    public ScreenPlan withFlashColor(String color) {
        return new ScreenPlan(channel, duration, hold, finalFrame, color, frames);
    }
}
