package id.vae.scenes.scene;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * Named presets (sounds, particles). An action can say {@code preset: name} and override any value.
 * The library can be replaced at runtime when the preset files are reloaded.
 */
public final class PresetLibrary {

    private volatile Map<String, Map<String, Object>> presets = Map.of();

    public PresetLibrary() {
    }

    public PresetLibrary(Map<String, Map<String, Object>> presets) {
        replace(presets);
    }

    public void replace(Map<String, Map<String, Object>> newPresets) {
        Map<String, Map<String, Object>> copy = new LinkedHashMap<>();
        newPresets.forEach((name, values) -> copy.put(name.toLowerCase(), Collections.unmodifiableMap(
                new LinkedHashMap<>(values))));
        presets = Collections.unmodifiableMap(copy);
    }

    public boolean has(String name) {
        return name != null && presets.containsKey(name.toLowerCase());
    }

    public Set<String> names() {
        return new TreeSet<>(presets.keySet());
    }

    /** The action config on top of its preset (if any). The 'preset' key itself is kept out of the result. */
    public Map<String, Object> resolve(Map<String, Object> config) {
        Map<String, Object> merged = new LinkedHashMap<>();
        String name = ConfigValues.string(config, "preset", "");
        if (!name.isEmpty() && has(name)) {
            merged.putAll(presets.get(name.toLowerCase()));
        }
        config.forEach((k, v) -> {
            if (!k.equals("preset")) {
                merged.put(k, v);
            }
        });
        return merged;
    }
}
