package id.vae.scenes.scene;

import id.vae.scenes.bukkit.YamlMaps;
import id.vae.scenes.camera.CameraActions;
import id.vae.scenes.camera.FakeCameraControl;
import id.vae.scenes.particle.ParticleActions;
import id.vae.scenes.particle.ParticleControl;
import id.vae.scenes.particle.ParticleSpec;
import id.vae.scenes.rtp.RtpActions;
import id.vae.scenes.rtp.RtpControl;
import id.vae.scenes.screen.ScreenActions;
import id.vae.scenes.screen.ScreenControl;
import id.vae.scenes.screen.ScreenPlan;
import id.vae.scenes.sound.SoundActions;
import id.vae.scenes.sound.SoundControl;
import id.vae.scenes.sound.SoundSpec;
import id.vae.scenes.subtitle.SubtitleActions;
import id.vae.scenes.subtitle.SubtitleControl;
import id.vae.scenes.subtitle.SubtitleSpec;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** The bundled scenes must parse, validate against every action, and play through to the end. */
class PresetScenesTest {

    private static final List<String> FILES = List.of("first_join", "nether", "the_end", "rtp", "death");

    private static Map<String, Object> resource(String path) throws Exception {
        try (InputStream in = PresetScenesTest.class.getResourceAsStream("/" + path)) {
            assertNotNull(in, "missing resource " + path);
            return YamlMaps.load(in);
        }
    }

    @SuppressWarnings("unchecked")
    private static PresetLibrary library(String path) throws Exception {
        Map<String, Object> presets = (Map<String, Object>) resource(path).get("presets");
        Map<String, Map<String, Object>> out = new LinkedHashMap<>();
        presets.forEach((name, values) -> out.put(name, (Map<String, Object>) values));
        return new PresetLibrary(out);
    }

    @Test
    void everyBundledSceneIsValidAndPlaysToTheEndWithCleanup() throws Exception {
        PresetLibrary sounds = library("sounds/presets.yml");
        PresetLibrary particles = library("particles/presets.yml");

        for (String file : FILES) {
            EngineHarness h = new EngineHarness();
            FakeCameraControl camera = new FakeCameraControl();
            int[] locks = {0, 0};
            CameraActions.registerAll(h.registry, camera);
            PlayerActions.registerAll(h.registry, new PlayerLocks() {
                public void lock(UUID p) {
                    locks[0]++;
                }

                public void unlock(UUID p) {
                    locks[1]++;
                }
            });
            ScreenActions.registerAll(h.registry, new ScreenControl() {
                public void play(UUID p, ScreenPlan plan) {
                }

                public void clear(UUID p) {
                }
            }, camera);
            SoundActions.registerAll(h.registry, new SoundControl() {
                public void play(UUID p, SoundSpec s) {
                }

                public void stop(UUID p, String k) {
                }

                public void endScene(UUID p) {
                }
            }, sounds);
            SubtitleActions.registerAll(h.registry, new SubtitleControl() {
                public void show(UUID p, SubtitleSpec s) {
                }

                public void queue(UUID p, List<SubtitleSpec> l) {
                }

                public void hide(UUID p) {
                }

                public void clear(UUID p) {
                }
            });
            ParticleActions.registerAll(h.registry, new ParticleControl() {
                public void start(UUID p, ParticleSpec s, String t) {
                }

                public void stop(UUID p, String t) {
                }

                public void endScene(UUID p) {
                }
            }, particles);
            RtpActions.registerAll(h.registry, new RtpControl() {
                public Status status(UUID p) {
                    return Status.SUCCEEDED;
                }

                public boolean execute(UUID p) {
                    return true;
                }

                public void finish(UUID p) {
                }

                public long timeoutMillis() {
                    return 15_000;
                }
            });

            SceneMapper.Parsed parsed = SceneMapper.fromMap(resource("scenes/" + file + ".yml"));
            assertEquals(List.of(), parsed.errors(), file);
            assertEquals(List.of(), h.validator.validate(parsed.scene()), file);

            h.catalog.add(parsed.scene());
            assertEquals(SceneEngine.StartResult.STARTED, h.engine.start(h.alice, parsed.scene().id(), true), file);
            h.clock.advance(30_000);

            assertFalse(h.engine.isRunning(h.alice), file);
            assertFalse(camera.isActive(h.alice), file);
            assertEquals(1, locks[0], file);
            assertEquals(1, locks[1], file);
        }
    }

    @Test
    void theTriggersMatchTheDocumentedBehaviour() throws Exception {
        Map<String, TriggerType> expected = Map.of("first_join", TriggerType.FIRST_JOIN, "nether", TriggerType.NETHER_ENTER,
                "the_end", TriggerType.END_ENTER, "rtp", TriggerType.RTP_START, "death", TriggerType.PLAYER_RESPAWN);
        for (String file : FILES) {
            SceneDefinition scene = SceneMapper.fromMap(resource("scenes/" + file + ".yml")).scene();
            assertEquals(expected.get(file), scene.trigger().type(), file);
        }
        assertTrue(SceneMapper.fromMap(resource("scenes/first_join.yml")).scene().trigger().oncePerPlayer());
        assertFalse(SceneMapper.fromMap(resource("scenes/rtp.yml")).scene().trigger().oncePerPlayer());
    }
}
