package id.vae.scenes.camera;

/**
 * Camera shake: a decaying, deterministic wobble. Intensity 1.0 is about one degree of rotation and
 * a twentieth of a block of movement at the start.
 */
public record CameraShake(double intensity, long durationMillis, double frequencyHz) {

    public CameraPose apply(CameraPose base, long elapsedMillis) {
        if (durationMillis <= 0 || elapsedMillis < 0 || elapsedMillis >= durationMillis) {
            return base;
        }
        double decay = 1.0 - (double) elapsedMillis / durationMillis;
        double phase = elapsedMillis / 1000.0 * frequencyHz * 2 * Math.PI;
        double amplitude = intensity * decay;
        return new CameraPose(
                base.x() + 0.05 * amplitude * Math.sin(phase * 1.3 + 0.4),
                base.y() + 0.05 * amplitude * Math.sin(phase * 1.9 + 1.1),
                base.z() + 0.05 * amplitude * Math.sin(phase * 1.1 + 2.3),
                (float) (base.yaw() + amplitude * Math.sin(phase * 1.7)),
                (float) (base.pitch() + amplitude * Math.sin(phase * 2.3 + 0.7)));
    }
}
