package id.vae.scenes.util;

import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class JsonTest {

    @Test
    void valuesRoundTrip() {
        Map<String, Object> original = new LinkedHashMap<>();
        original.put("text", "line1\nline2 \"quoted\" \\ / tab\t");
        original.put("int", 42L);
        original.put("negative", -7L);
        original.put("double", 1.5);
        original.put("yes", true);
        original.put("no", false);
        original.put("nothing", null);
        original.put("list", List.of(1L, "two", List.of(), Map.of()));
        original.put("nested", Map.of("a", Map.of("b", List.of(true))));

        assertEquals(original, Json.parse(Json.stringify(original)));
    }

    @Test
    void numbersKeepTheirKind() {
        assertEquals(5L, Json.parse("5"));
        assertEquals(-12L, Json.parse("-12"));
        assertEquals(1.25, Json.parse("1.25"));
        assertEquals(1000.0, Json.parse("1e3"));
        assertEquals(0.0, Json.parse("0.0"));
        assertTrue(Json.parse("99999999999999999999") instanceof Double);
    }

    @Test
    void unicodeAndEscapesAreDecoded() {
        assertEquals("A\u00e9\u20ac", Json.parse("\"A\\u00e9\\u20ac\""));
        assertEquals("\ud83d\ude00", Json.parse("\"\\ud83d\\ude00\""));
        assertEquals("a/b", Json.parse("\"a\\/b\""));
        assertEquals("\u00e9", Json.parse("\"\u00e9\""));
    }

    @Test
    void outputIsSafeToEmbedInHtml() {
        String json = Json.stringify(Map.of("x", "</script><b>&"));

        assertTrue(!json.contains("<") && !json.contains(">") && !json.contains("&"));
        assertEquals(Map.of("x", "</script><b>&"), Json.parse(json));
        assertEquals("\"\\u0001\"", Json.stringify("\u0001"));
    }

    @Test
    void invalidJsonIsRejected() {
        for (String bad : List.of("", "{", "[1,]", "{\"a\":}", "{'a':1}", "[1 2]", "01", "1.", "-", "tru", "\"abc",
                "\"a\nb\"", "{\"a\":1} extra", "[\"\\x\"]", "{1:2}", "\"\\u12G4\"", "nul")) {
            assertThrows(Json.JsonException.class, () -> Json.parse(bad), "should reject: " + bad);
        }
    }

    @Test
    void deepNestingIsRejected() {
        String deep = "[".repeat(100) + "]".repeat(100);

        assertThrows(Json.JsonException.class, () -> Json.parse(deep));
        assertEquals(List.of(List.of(List.of())), Json.parse("[[[]]]"));
    }

    @Test
    void whitespaceAndEmptyContainersAreAccepted() {
        assertEquals(Map.of(), Json.parse(" { } "));
        assertEquals(List.of(), Json.parse("\n[ ]\t"));
        assertEquals(Map.of("a", List.of(1L, 2L)), Json.parse("{ \"a\" : [ 1 , 2 ] }"));
    }

    @Test
    void nonFiniteNumbersBecomeNull() {
        assertEquals("null", Json.stringify(Double.NaN));
        assertEquals("[1,2.5]", Json.stringify(List.of(1, 2.5)));
    }
}
