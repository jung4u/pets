package id.vae.scenes.sound;

import id.vae.scenes.camera.CameraControl;
import id.vae.scenes.camera.CameraPose;
import id.vae.scenes.camera.Vec3;
import id.vae.scenes.core.Service;
import id.vae.scenes.scene.SceneScheduler;
import id.vae.scenes.util.ScenesLogger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Plays sounds, runs their repeats and remembers what to stop when a scene ends. Main thread only. */
public final class SoundService implements Service, SoundControl {

    private static final class State {
        final List<SceneScheduler.Task> tasks = new ArrayList<>();
        final Map<String, String> started = new HashMap<>();
        final Set<String> stopOnEnd = new HashSet<>();
    }

    private final SoundOutput output;
    private final CameraControl camera;
    private final SceneScheduler scheduler;
    private final ScenesLogger log;
    private final Map<UUID, State> states = new HashMap<>();

    public SoundService(SoundOutput output, CameraControl camera, SceneScheduler scheduler, ScenesLogger log) {
        this.output = output;
        this.camera = camera;
        this.scheduler = scheduler;
        this.log = log;
    }

    @Override
    public String name() {
        return "sound";
    }

    @Override
    public void start() {
        // Nothing to start.
    }

    @Override
    public void stop() {
        for (UUID player : new ArrayList<>(states.keySet())) {
            endScene(player);
        }
    }

    @Override
    public void play(UUID player, SoundSpec spec) {
        State state = states.computeIfAbsent(player, k -> new State());
        playOnce(player, spec, state);
        for (int i = 1; i <= spec.repeat(); i++) {
            state.tasks.add(scheduler.runLater(spec.repeatIntervalMillis() * i, () -> playOnce(player, spec, state)));
        }
    }

    private void playOnce(UUID player, SoundSpec spec, State state) {
        try {
            output.play(player, spec, resolve(player, spec));
            state.started.put(spec.key(), spec.category());
            if (spec.stopOnEnd()) {
                state.stopOnEnd.add(spec.key());
            }
        } catch (RuntimeException e) {
            log.error("Could not play sound " + spec.key(), e);
        }
    }

    private Vec3 resolve(UUID player, SoundSpec spec) {
        return switch (spec.location()) {
            case WORLD -> spec.point();
            case CAMERA -> camera.currentPose(player).map(CameraPose::position).orElse(null);
            case PLAYER -> null;
        };
    }

    @Override
    public void stop(UUID player, String keyOrNull) {
        State state = states.get(player);
        if (state == null) {
            return;
        }
        if (keyOrNull == null) {
            state.tasks.forEach(SceneScheduler.Task::cancel);
            state.tasks.clear();
            state.started.forEach((key, category) -> stopQuietly(player, key, category));
            state.started.clear();
            state.stopOnEnd.clear();
        } else {
            String category = state.started.remove(keyOrNull);
            state.stopOnEnd.remove(keyOrNull);
            stopQuietly(player, keyOrNull, category == null ? "MASTER" : category);
        }
    }

    @Override
    public void endScene(UUID player) {
        State state = states.remove(player);
        if (state == null) {
            return;
        }
        state.tasks.forEach(SceneScheduler.Task::cancel);
        for (String key : state.stopOnEnd) {
            stopQuietly(player, key, state.started.getOrDefault(key, "MASTER"));
        }
    }

    private void stopQuietly(UUID player, String key, String category) {
        try {
            output.stop(player, key, category);
        } catch (RuntimeException e) {
            log.error("Could not stop sound " + key, e);
        }
    }
}
