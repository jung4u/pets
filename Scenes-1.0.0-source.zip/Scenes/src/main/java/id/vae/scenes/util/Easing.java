package id.vae.scenes.util;

import java.util.Locale;

/** Interpolation curves shared by camera, screen and particle animations. */
public enum Easing {
    LINEAR {
        @Override
        double curve(double t) {
            return t;
        }
    },
    EASE_IN {
        @Override
        double curve(double t) {
            return t * t;
        }
    },
    EASE_OUT {
        @Override
        double curve(double t) {
            return 1 - (1 - t) * (1 - t);
        }
    },
    EASE_IN_OUT {
        @Override
        double curve(double t) {
            return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
        }
    },
    SMOOTHSTEP {
        @Override
        double curve(double t) {
            return t * t * (3 - 2 * t);
        }
    },
    CUBIC {
        @Override
        double curve(double t) {
            return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
        }
    },
    SINE {
        @Override
        double curve(double t) {
            return -(Math.cos(Math.PI * t) - 1) / 2;
        }
    };

    abstract double curve(double t);

    /** Maps progress t (clamped to 0..1) to eased progress in 0..1. */
    public double apply(double t) {
        if (t <= 0) {
            return 0;
        }
        if (t >= 1) {
            return 1;
        }
        return curve(t);
    }

    public static Easing parse(String value, Easing fallback) {
        if (value == null) {
            return fallback;
        }
        try {
            return valueOf(value.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }
}
