package id.vae.scenes.sound;

import id.vae.scenes.camera.Vec3;

/**
 * One sound to play.
 *
 * @param category   Minecraft sound category such as PLAYERS or AMBIENT
 * @param location   where it plays; PLAYER and CAMERA follow the viewer at the moment it plays
 * @param point      fixed position when location is WORLD, otherwise null
 * @param nearby     true to let other players near the sound hear it, false for the viewer only
 * @param repeat     extra plays after the first one
 * @param stopOnEnd  stop this sound when the scene ends
 */
public record SoundSpec(String key, float volume, float pitch, String category, Location location, Vec3 point,
                        boolean nearby, int repeat, long repeatIntervalMillis, boolean stopOnEnd) {

    public enum Location { PLAYER, CAMERA, WORLD }

    public SoundSpec {
        category = category == null || category.isBlank() ? "MASTER" : category.trim().toUpperCase();
        location = location == null ? Location.PLAYER : location;
        repeat = Math.max(0, repeat);
        repeatIntervalMillis = Math.max(0, repeatIntervalMillis);
    }

    public static SoundSpec simple(String key, float volume, float pitch) {
        return new SoundSpec(key, volume, pitch, "MASTER", Location.PLAYER, null, false, 0, 0, false);
    }
}
