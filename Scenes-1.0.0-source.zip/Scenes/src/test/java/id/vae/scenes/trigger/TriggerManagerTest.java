package id.vae.scenes.trigger;

import id.vae.scenes.core.ServiceRegistry;
import id.vae.scenes.scene.ActionRegistry;
import id.vae.scenes.scene.ConditionEvaluator;
import id.vae.scenes.scene.ControlActions;
import id.vae.scenes.scene.SceneDefinition;
import id.vae.scenes.scene.SceneEngine;
import id.vae.scenes.scene.SceneEngine.StartResult;
import id.vae.scenes.scene.TestSupport.FakePlayers;
import id.vae.scenes.scene.TestSupport.ManualScheduler;
import id.vae.scenes.scene.TestSupport.MapCatalog;
import id.vae.scenes.scene.TestSupport.Marker;
import id.vae.scenes.scene.TestSupport.MemoryProgress;
import id.vae.scenes.scene.TriggerSpec;
import id.vae.scenes.scene.TriggerType;
import id.vae.scenes.util.ScenesLogger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import static id.vae.scenes.scene.TestSupport.mark;
import static id.vae.scenes.scene.TestSupport.scene;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TriggerManagerTest {

    private final ScenesLogger log = new ScenesLogger(Logger.getLogger("test"), false);
    private ManualScheduler clock;
    private FakePlayers players;
    private MapCatalog catalog;
    private SceneEngine engine;
    private TriggerManager triggers;
    private UUID alice;

    @BeforeEach
    void setUp() {
        clock = new ManualScheduler();
        players = new FakePlayers();
        catalog = new MapCatalog();
        ActionRegistry registry = new ActionRegistry();
        ControlActions.registerAll(registry);
        registry.register(new Marker(new ArrayList<>(), clock));
        engine = new SceneEngine(catalog, registry, clock, players, new MemoryProgress(), new ServiceRegistry(log),
                new ConditionEvaluator(players), () -> 10, log);
        triggers = new TriggerManager(catalog, engine, players, log);
        alice = players.join("world_nether");
    }

    private SceneDefinition on(String id, int priority, TriggerSpec trigger) {
        return scene(id, priority, mark("a", 0), mark("b", 5000)).withTrigger(trigger);
    }

    @Test
    void onlyScenesWithTheMatchingTriggerTypeStart() {
        catalog.add(on("nether", 0, TriggerSpec.of(TriggerType.NETHER_ENTER, false)));
        catalog.add(on("end", 0, TriggerSpec.of(TriggerType.END_ENTER, false)));

        List<TriggerManager.Fired> fired =
                triggers.fire(TriggerEvent.of(TriggerType.NETHER_ENTER, alice, "world_nether"));

        assertEquals(1, fired.size());
        assertEquals("nether", fired.get(0).sceneId());
        assertEquals(StartResult.STARTED, fired.get(0).result());
    }

    @Test
    void worldFilterIsRespected() {
        catalog.add(on("only_end", 0, new TriggerSpec(TriggerType.WORLD_CHANGE, false, "", "world_the_end", "")));

        assertTrue(triggers.fire(TriggerEvent.of(TriggerType.WORLD_CHANGE, alice, "world_nether")).isEmpty());
        assertEquals(1, triggers.fire(TriggerEvent.of(TriggerType.WORLD_CHANGE, alice, "world_the_end")).size());
    }

    @Test
    void permissionFilterIsRespected() {
        catalog.add(on("vip", 0, new TriggerSpec(TriggerType.PLAYER_DEATH, false, "scenes.vip", "", "")));

        assertTrue(triggers.fire(TriggerEvent.of(TriggerType.PLAYER_DEATH, alice, "world")).isEmpty());

        players.grant(alice, "scenes.vip");
        assertEquals(1, triggers.fire(TriggerEvent.of(TriggerType.PLAYER_DEATH, alice, "world")).size());
    }

    @Test
    void higherPriorityStartsFirstAndBlocksLowerOnes() {
        catalog.add(on("low", 1, TriggerSpec.of(TriggerType.PLAYER_RESPAWN, false)));
        catalog.add(on("high", 9, TriggerSpec.of(TriggerType.PLAYER_RESPAWN, false)));

        List<TriggerManager.Fired> fired = triggers.fire(TriggerEvent.of(TriggerType.PLAYER_RESPAWN, alice, "world"));

        assertEquals("high", fired.get(0).sceneId());
        assertEquals(StartResult.STARTED, fired.get(0).result());
        assertEquals("low", fired.get(1).sceneId());
        assertEquals(StartResult.ALREADY_RUNNING, fired.get(1).result());
    }

    @Test
    void disabledScenesAndArgumentMismatchesAreIgnored() {
        catalog.add(on("off", 0, TriggerSpec.of(TriggerType.CUSTOM, false)).withEnabled(false));
        catalog.add(on("named", 0, new TriggerSpec(TriggerType.CUSTOM, false, "", "", "boss_dead")));

        assertTrue(triggers.fire(new TriggerEvent(TriggerType.CUSTOM, alice, "world", "other")).isEmpty());
        assertEquals(1, triggers.fire(new TriggerEvent(TriggerType.CUSTOM, alice, "world", "BOSS_DEAD")).size());
    }
}
