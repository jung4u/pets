package id.vae.scenes.scene;

import id.vae.scenes.scene.TestSupport.FakePlayers;
import id.vae.scenes.scene.TestSupport.ManualScheduler;
import id.vae.scenes.scene.TestSupport.Marker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static id.vae.scenes.scene.TestSupport.action;
import static id.vae.scenes.scene.TestSupport.mark;
import static id.vae.scenes.scene.TestSupport.scene;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SceneValidatorTest {

    private SceneValidator validator;

    @BeforeEach
    void setUp() {
        ActionRegistry registry = new ActionRegistry();
        ControlActions.registerAll(registry);
        registry.register(new Marker(new ArrayList<>(), new ManualScheduler()));
        validator = new SceneValidator(registry, new ConditionEvaluator(new FakePlayers()));
    }

    private boolean mentions(List<String> errors, String text) {
        return errors.stream().anyMatch(e -> e.contains(text));
    }

    @Test
    void validSceneHasNoErrors() {
        assertEquals(List.of(), validator.validate(scene("first_join", 0, mark("a", 0), mark("b", 500))));
    }

    @Test
    void badSceneIdAndEmptyNameAreRejected() {
        SceneDefinition bad = scene("Bad Id!", 0, mark("a", 0)).withName(" ");

        List<String> errors = validator.validate(bad);

        assertTrue(mentions(errors, "scene id"));
        assertTrue(mentions(errors, "name"));
    }

    @Test
    void duplicateActionIdsAreRejected() {
        assertTrue(mentions(validator.validate(scene("s", 0, mark("a", 0), mark("a", 100))), "duplicate"));
    }

    @Test
    void unknownActionTypeIsRejected() {
        assertTrue(mentions(validator.validate(scene("s", 0, action("x", "TELEPORT_MOON", 0, 0, Map.of()))),
                "unknown action type"));
    }

    @Test
    void negativeTimingsAreRejected() {
        assertTrue(mentions(validator.validate(scene("s", 0, action("x", "MARK", -1, 0, Map.of()))), "delay"));
        assertTrue(mentions(validator.validate(scene("s", 0, action("x", "MARK", 0, -5, Map.of()))), "duration"));
    }

    @Test
    void controlActionsValidateTheirOwnSettings() {
        assertTrue(mentions(validator.validate(scene("s", 0, action("d", "DELAY", 0, 0, Map.of()))), "DELAY"));
        assertTrue(mentions(validator.validate(scene("s", 0, action("b", "BRANCH", 0, 0, Map.of()))), "condition"));
        assertTrue(mentions(validator.validate(scene("s", 0, action("k", "SKIP", 0, 0, Map.of()))), "SKIP"));
        assertTrue(mentions(validator.validate(scene("s", 0, action("v", "SET_VARIABLE", 0, 0, Map.of()))),
                "SET_VARIABLE"));
    }

    @Test
    void unknownConditionTypeIsRejected() {
        SceneDefinition withCondition = new SceneDefinition("s", "s", "", true, TriggerSpec.manual(), 0, 0, 0,
                List.of(new ConditionSpec("MOON_PHASE", Map.of())), List.of(mark("a", 0)));

        assertTrue(mentions(validator.validate(withCondition), "condition"));
    }
}
