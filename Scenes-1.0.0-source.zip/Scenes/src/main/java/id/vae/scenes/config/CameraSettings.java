package id.vae.scenes.config;

public record CameraSettings(String backend, String bedrockBackend, double maxDistance, double eyeHeight) {
}
