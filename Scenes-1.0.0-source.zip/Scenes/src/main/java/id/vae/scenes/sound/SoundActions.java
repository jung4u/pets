package id.vae.scenes.sound;

import id.vae.scenes.camera.Vec3;
import id.vae.scenes.scene.ActionContext;
import id.vae.scenes.scene.ActionDefinition;
import id.vae.scenes.scene.ActionHandler;
import id.vae.scenes.scene.ActionHandlers;
import id.vae.scenes.scene.ActionRegistry;
import id.vae.scenes.scene.ActionResult;
import id.vae.scenes.scene.ConfigValues;
import id.vae.scenes.scene.PresetLibrary;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * SOUND_PLAY (alias PLAYER_PLAY_SOUND) and SOUND_STOP.
 *
 * <p>SOUND_PLAY settings: preset or key, volume (0-10, default 1), pitch (0-2, default 1), category,
 * location (PLAYER, CAMERA or WORLD with position {x, y, z}), audience (PLAYER or NEARBY), repeat,
 * repeat-interval-ms, stop-on-end. Keys may be vanilla or custom resource pack sounds.
 */
public final class SoundActions {

    public static final Pattern KEY = Pattern.compile("(?:[a-z0-9_.-]+:)?[a-z0-9_./-]+");
    static final Set<String> CATEGORIES = Set.of("MASTER", "MUSIC", "RECORDS", "WEATHER", "BLOCKS", "HOSTILE",
            "NEUTRAL", "PLAYERS", "AMBIENT", "VOICE");
    private static final String CLEANUP_KEY = "sound.cleanup";

    private SoundActions() {
    }

    public static void registerAll(ActionRegistry registry, SoundControl sounds, PresetLibrary library) {
        Play play = new Play(sounds, library);
        registry.register(play);
        registry.register(ActionHandlers.alias("PLAYER_PLAY_SOUND", play));
        registry.register(new Stop(sounds));
    }

    /** Returns problems with a sound configuration; empty when valid. */
    public static List<String> validate(Map<String, Object> raw, PresetLibrary library) {
        List<String> errors = new ArrayList<>();
        String preset = ConfigValues.string(raw, "preset", "");
        if (!preset.isEmpty() && !library.has(preset)) {
            errors.add("unknown sound preset '" + preset + "'");
        }
        Map<String, Object> cfg = library.resolve(raw);
        String key = ConfigValues.string(cfg, "key", "");
        if (key.isEmpty()) {
            errors.add("a sound needs a 'key' or a 'preset'");
        } else if (!KEY.matcher(key).matches()) {
            errors.add("invalid sound key '" + key + "'");
        }
        double volume = ConfigValues.doubleValue(cfg, "volume", 1.0);
        if (volume < 0 || volume > 10) {
            errors.add("'volume' must be between 0 and 10");
        }
        double pitch = ConfigValues.doubleValue(cfg, "pitch", 1.0);
        if (pitch < 0 || pitch > 2) {
            errors.add("'pitch' must be between 0 and 2");
        }
        if (!CATEGORIES.contains(ConfigValues.string(cfg, "category", "MASTER").toUpperCase(Locale.ROOT))) {
            errors.add("unknown sound category");
        }
        String location = ConfigValues.string(cfg, "location", "PLAYER").toUpperCase(Locale.ROOT);
        if (!Set.of("PLAYER", "CAMERA", "WORLD").contains(location)) {
            errors.add("'location' must be PLAYER, CAMERA or WORLD");
        } else if (location.equals("WORLD") && !hasPoint(ConfigValues.map(cfg, "position"))) {
            errors.add("location WORLD needs a 'position' with x, y and z");
        }
        String audience = ConfigValues.string(cfg, "audience", "PLAYER").toUpperCase(Locale.ROOT);
        if (!audience.equals("PLAYER") && !audience.equals("NEARBY")) {
            errors.add("'audience' must be PLAYER or NEARBY");
        }
        long repeat = ConfigValues.longValue(cfg, "repeat", 0);
        if (repeat < 0 || repeat > 100) {
            errors.add("'repeat' must be between 0 and 100");
        }
        if (repeat > 0 && ConfigValues.longValue(cfg, "repeat-interval-ms", 0) <= 0) {
            errors.add("'repeat-interval-ms' must be greater than 0 when repeating");
        }
        return errors;
    }

    /** Builds the sound described by the configuration (already validated). */
    public static SoundSpec spec(Map<String, Object> raw, PresetLibrary library) {
        Map<String, Object> cfg = library.resolve(raw);
        Map<String, Object> position = ConfigValues.map(cfg, "position");
        return new SoundSpec(ConfigValues.string(cfg, "key", ""),
                (float) ConfigValues.doubleValue(cfg, "volume", 1.0),
                (float) ConfigValues.doubleValue(cfg, "pitch", 1.0),
                ConfigValues.string(cfg, "category", "MASTER"),
                SoundSpec.Location.valueOf(ConfigValues.string(cfg, "location", "PLAYER").toUpperCase(Locale.ROOT)),
                hasPoint(position) ? new Vec3(ConfigValues.doubleValue(position, "x", 0),
                        ConfigValues.doubleValue(position, "y", 0), ConfigValues.doubleValue(position, "z", 0)) : null,
                "NEARBY".equalsIgnoreCase(ConfigValues.string(cfg, "audience", "PLAYER")),
                (int) ConfigValues.longValue(cfg, "repeat", 0), ConfigValues.longValue(cfg, "repeat-interval-ms", 0),
                ConfigValues.bool(cfg, "stop-on-end", false));
    }

    private static boolean hasPoint(Map<String, Object> m) {
        return m.get("x") instanceof Number && m.get("y") instanceof Number && m.get("z") instanceof Number;
    }

    private static final class Play implements ActionHandler {
        private final SoundControl sounds;
        private final PresetLibrary library;

        Play(SoundControl sounds, PresetLibrary library) {
            this.sounds = sounds;
            this.library = library;
        }

        @Override
        public String type() {
            return "SOUND_PLAY";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            return SoundActions.validate(action.config(), library);
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            var player = ctx.player();
            ActionHandlers.cleanupOnce(ctx, CLEANUP_KEY, () -> sounds.endScene(player));
            sounds.play(player, spec(action.config(), library));
            return ActionResult.done();
        }
    }

    private static final class Stop implements ActionHandler {
        private final SoundControl sounds;

        Stop(SoundControl sounds) {
            this.sounds = sounds;
        }

        @Override
        public String type() {
            return "SOUND_STOP";
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            String key = ConfigValues.string(action.config(), "key", "all");
            sounds.stop(ctx.player(), key.equalsIgnoreCase("all") ? null : key);
            return ActionResult.done();
        }
    }
}
