package id.vae.scenes.subtitle;

import java.util.List;
import java.util.UUID;

public interface SubtitleControl {

    void show(UUID player, SubtitleSpec spec);

    /** Shows the lines one after another (by order), each after its own delay. */
    void queue(UUID player, List<SubtitleSpec> lines);

    void hide(UUID player);

    /** Hides everything and cancels what is still scheduled. Call when a scene run ends. */
    void clear(UUID player);
}
