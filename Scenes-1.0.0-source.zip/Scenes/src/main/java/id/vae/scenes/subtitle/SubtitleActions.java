package id.vae.scenes.subtitle;

import id.vae.scenes.scene.ActionContext;
import id.vae.scenes.scene.ActionDefinition;
import id.vae.scenes.scene.ActionHandler;
import id.vae.scenes.scene.ActionHandlers;
import id.vae.scenes.scene.ActionRegistry;
import id.vae.scenes.scene.ActionResult;
import id.vae.scenes.scene.ConfigValues;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * SUBTITLE_SHOW, SUBTITLE_QUEUE and SUBTITLE_HIDE.
 *
 * <p>Settings: text (MiniMessage, required), color (hex), gradient (list of hex colours), bold, italic,
 * underline, position (TOP, CENTER, BOTTOM), fade-in-ms, fade-out-ms, priority, order, repeat,
 * repeat-interval-ms, enabled, sound (key), volume, pitch. The action duration is how long it shows
 * (default 3000 ms). SUBTITLE_QUEUE takes a 'lines' list of the same settings plus delay-ms and duration-ms.
 */
public final class SubtitleActions {

    private static final String CLEANUP_KEY = "subtitle.cleanup";
    private static final long DEFAULT_DURATION = 3000;

    private SubtitleActions() {
    }

    public static void registerAll(ActionRegistry registry, SubtitleControl subtitles) {
        registry.register(new Show(subtitles));
        registry.register(new Queue(subtitles));
        registry.register(new Hide(subtitles));
    }

    static List<String> validate(Map<String, Object> m, long duration, String label) {
        List<String> errors = new ArrayList<>();
        if (ConfigValues.string(m, "text", "").isBlank()) {
            errors.add(label + "needs 'text'");
        }
        String color = ConfigValues.string(m, "color", "");
        if (!color.isEmpty() && !ActionHandlers.validHex(color)) {
            errors.add(label + "'color' must be a hex colour like #a855f7");
        }
        List<String> gradient = ConfigValues.stringList(m, "gradient");
        if (!gradient.isEmpty() && (gradient.size() < 2 || !gradient.stream().allMatch(ActionHandlers::validHex))) {
            errors.add(label + "'gradient' needs at least two hex colours");
        }
        String position = ConfigValues.string(m, "position", "CENTER").toUpperCase(Locale.ROOT);
        if (!List.of("TOP", "CENTER", "BOTTOM").contains(position)) {
            errors.add(label + "'position' must be TOP, CENTER or BOTTOM");
        }
        long in = ConfigValues.longValue(m, "fade-in-ms", 250);
        long out = ConfigValues.longValue(m, "fade-out-ms", 250);
        if (in < 0 || out < 0 || in + out > duration) {
            errors.add(label + "fade times must not be negative or longer than the duration");
        }
        long repeat = ConfigValues.longValue(m, "repeat", 0);
        if (repeat < 0 || repeat > 20) {
            errors.add(label + "'repeat' must be between 0 and 20");
        }
        if (duration <= 0) {
            errors.add(label + "duration must be greater than 0");
        }
        String sound = ConfigValues.string(m, "sound", "");
        if (!sound.isEmpty() && !id.vae.scenes.sound.SoundActions.KEY.matcher(sound).matches()) {
            errors.add(label + "invalid sound key '" + sound + "'");
        }
        return errors;
    }

    static SubtitleSpec spec(Map<String, Object> m, long duration, int index) {
        String color = ConfigValues.string(m, "color", "");
        return new SubtitleSpec(ConfigValues.string(m, "text", ""), color, ConfigValues.stringList(m, "gradient"),
                ConfigValues.bool(m, "bold", false), ConfigValues.bool(m, "italic", false),
                ConfigValues.bool(m, "underline", false),
                SubtitlePosition.valueOf(ConfigValues.string(m, "position", "CENTER").toUpperCase(Locale.ROOT)),
                duration, ConfigValues.longValue(m, "fade-in-ms", 250), ConfigValues.longValue(m, "fade-out-ms", 250),
                ConfigValues.longValue(m, "delay-ms", 0), (int) ConfigValues.longValue(m, "priority", 0),
                (int) ConfigValues.longValue(m, "order", index), (int) ConfigValues.longValue(m, "repeat", 0),
                ConfigValues.longValue(m, "repeat-interval-ms", 0), ConfigValues.bool(m, "enabled", true),
                ConfigValues.string(m, "sound", ""), (float) ConfigValues.doubleValue(m, "volume", 1.0),
                (float) ConfigValues.doubleValue(m, "pitch", 1.0));
    }

    private static long duration(ActionDefinition action) {
        return action.durationMillis() > 0 ? action.durationMillis() : DEFAULT_DURATION;
    }

    private static final class Show implements ActionHandler {
        private final SubtitleControl subtitles;

        Show(SubtitleControl subtitles) {
            this.subtitles = subtitles;
        }

        @Override
        public String type() {
            return "SUBTITLE_SHOW";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            return SubtitleActions.validate(action.config(), duration(action), "SUBTITLE_SHOW ");
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            var player = ctx.player();
            ActionHandlers.cleanupOnce(ctx, CLEANUP_KEY, () -> subtitles.clear(player));
            subtitles.show(player, spec(action.config(), duration(action), 0));
            return ActionResult.done();
        }
    }

    private static final class Queue implements ActionHandler {
        private final SubtitleControl subtitles;

        Queue(SubtitleControl subtitles) {
            this.subtitles = subtitles;
        }

        @Override
        public String type() {
            return "SUBTITLE_QUEUE";
        }

        @Override
        public List<String> validate(ActionDefinition action) {
            List<Map<String, Object>> lines = ConfigValues.mapList(action.config(), "lines");
            if (lines.isEmpty()) {
                return List.of("SUBTITLE_QUEUE needs a non-empty 'lines' list");
            }
            List<String> errors = new ArrayList<>();
            for (int i = 0; i < lines.size(); i++) {
                errors.addAll(SubtitleActions.validate(lines.get(i),
                        ConfigValues.longValue(lines.get(i), "duration-ms", DEFAULT_DURATION), "line " + (i + 1) + " "));
            }
            return errors;
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            var player = ctx.player();
            ActionHandlers.cleanupOnce(ctx, CLEANUP_KEY, () -> subtitles.clear(player));
            List<SubtitleSpec> specs = new ArrayList<>();
            List<Map<String, Object>> lines = ConfigValues.mapList(action.config(), "lines");
            for (int i = 0; i < lines.size(); i++) {
                specs.add(spec(lines.get(i), ConfigValues.longValue(lines.get(i), "duration-ms", DEFAULT_DURATION), i));
            }
            subtitles.queue(player, specs);
            return ActionResult.done();
        }
    }

    private static final class Hide implements ActionHandler {
        private final SubtitleControl subtitles;

        Hide(SubtitleControl subtitles) {
            this.subtitles = subtitles;
        }

        @Override
        public String type() {
            return "SUBTITLE_HIDE";
        }

        @Override
        public ActionResult execute(ActionContext ctx, ActionDefinition action) {
            subtitles.hide(ctx.player());
            return ActionResult.done();
        }
    }
}
